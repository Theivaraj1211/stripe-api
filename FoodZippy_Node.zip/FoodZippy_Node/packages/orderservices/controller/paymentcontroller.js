const PaymentMethod = require('../../common/model/paymentmethodSchema');
const FoodOrder = require("../../common/model/orderSchema");
const user = require("../../common/model/userSchema");
const Restaurant = require("../../common/model/restaurantSchema");
const stripe = require('stripe')(process.env.STRIPE_SECRETKEYA);
const dotenv = require("dotenv");
const Joi = require('joi');
dotenv.config();
const paymentMethodSchema = Joi.object({
    user: Joi.string(),
    restaurant_id: Joi.string(),
    orderId: Joi.string(),
    amount: Joi.number(),
    type: Joi.string().valid('card', 'upi', 'netbanking', 'gpay', 'phonepay', 'applepay', 'other'),
    stripeCustomerId: Joi.string(),
    cardDetails: Joi.when('type', {
        is: 'card',
        then: Joi.object({
            cardholderName: Joi.string(),
            cardNumber: Joi.string(),
            expiryMonth: Joi.number().min(1).max(12),
            expiryYear: Joi.number().min(2023),
            cvv: Joi.string(),
        }),
        otherwise: Joi.forbidden(),
    }),
    upiDetails: Joi.when('type', {
        is: 'upi',
        then: Joi.object({
            virtualPaymentAddress: Joi.string(),
            vpaProvider: Joi.string().optional(),
        }),
        otherwise: Joi.forbidden(),
    }),
    netbankingDetails: Joi.when('type', {
        is: 'netbanking',
        then: Joi.object({
            bank: Joi.string(),
            accountNumber: Joi.string(),
            ifscCode: Joi.string(),
        }),
    }),
    isDefault: Joi.boolean().default(false),
    createdAt: Joi.date().default(Date.now),
    stripePaymentMethodId: Joi.string(),
    // Additional fields for India-specific requirements:
    ifscCode: Joi.string(),
    exportPurposeCode: Joi.string(),
    session_id: Joi.string(),
});
// Define three subscription plans
const plans = [
    {
        id: 'weekly-plan',
        name: 'Weekly Subscription',
        price: 499, // $4.99
        currency: 'usd',
        interval: 'week',
        features: ['Access for one week', 'Limited usage of advanced functionalities'],
    },
    {
        id: 'monthly-plan',
        name: 'Monthly Subscription',
        price: 1999, // $19.99
        currency: 'usd',
        interval: 'month',
        features: ['Full access for one month', 'No limitations on usage or access'],
    },
    {
        id: 'yearly-plan',
        name: 'Yearly Subscription',
        price: 19999, // $199.99
        currency: 'usd',
        interval: 'year',
        features: ['Full access for one year', 'Priority customer support', 'Exclusive or premium content'],
    },
];
// const createPaymentforuser = async (req, res) => {
//     try {
//         const validatedData = await paymentMethodSchema.validateAsync(req.body);
//         const userId = req.user.id;
//         const { orderId, type, cardDetails } = validatedData;

//         const userData = await user.findOne({ _id: userId });
//         if (!userData) {
//             return res.status(404).json({ error: 'User not found' });
//         }
//         // Create a customer in Stripe
//         const customer = await stripe.customers.create({
//             email: userData.email,
//             name: userData.firstName,
//         });

//         const foodOrderData = await FoodOrder.findOne({ orderId: orderId });
//         if (!foodOrderData) {
//             return res.status(404).json({ error: 'Food order not found' });
//         }

//         const restaurantId = foodOrderData.restaurant_id;
//         const totalAmount = foodOrderData.total_amount;

//         let paymentMethod;

//         switch (type) {
//             case 'card':
//                 paymentMethod = await stripe.paymentMethods.create({
//                     type: 'card',
//                     card: {
//                         number: cardDetails.cardNumber,
//                         exp_month: cardDetails.expiryMonth,
//                         exp_year: cardDetails.expiryYear,
//                         cvc: cardDetails.cvv,
//                     },
//                 });
//                 break;
//             // Handle other payment types accordingly

//             default:
//                 return res.status(400).json({ error: 'Invalid payment type' });
//         }

//         // Attach the payment method to the customer
//         await stripe.paymentMethods.attach(paymentMethod.id, {
//             customer: customer.id,
//         });
//         // Create a session for Checkout
//         const session = await stripe.checkout.sessions.create({
//             payment_method_types: ['card'],
//             line_items: [
//                 {
//                     price_data: {
//                         currency: 'inr',
//                         product_data: {
//                             name: `Order ${orderId} at ${restaurantId}`,
//                         },
//                         unit_amount: Math.round(totalAmount * 100), // Convert amount to cents
//                     },
//                     quantity: 1,
//                 },
//             ],
//             mode: 'payment',
//             success_url: 'http://localhost:3000/api/v1/success', // Redirect URL after successful payment
//             cancel_url: 'http://localhost:3000/api/v1/cancel', // Redirect URL after payment cancellation
//         });

//         // Store payment information in the database
//         // Assuming you have a Payment model or similar structure
//         const paymentData = new paymentMethod({
//             user: userId,
//             orderId: orderId,
//             amount: totalAmount,
//             paymentMethodId: paymentMethod.id,
//             session_id: session.id, // Add the Stripe session ID to your database
//             // Add other payment-related data as needed
//         });

//         await paymentData.save();

//         res.status(200).json({ success: true, session_id: session.id });

//     } catch (error) {
//         console.error('Error creating payment:', error);
//         res.status(500).json({ error: 'Internal Server Error' });
//     }
// }
const createPaymentforuser = async (req, res) => {
    try {
        const validatedData = await paymentMethodSchema.validateAsync(req.body);
        const userId = req.user.id;
        const { orderId, cardDetails } = validatedData;

        const userData = await user.findOne({ _id: userId });
        if (!userData) {
            return res.status(404).json({ error: 'User not found' });
        }

        const foodOrderData = await FoodOrder.findOne({ orderId: orderId });
        if (!foodOrderData) {
            return res.status(404).json({ error: 'Food order not found' });
        }

        const restaurantId = foodOrderData.restaurant_id;
        const totalAmount = foodOrderData.total_amount;
        const stripeCustomer = await stripe.customers.create({
            email: "theivaraj1211@gmail.com",
        });
        // Create a session for Checkout with a Payment Intent
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: [
                {
                    price_data: {
                        currency: 'inr',
                        product_data: {
                            name: `Order ${orderId} at ${restaurantId}`,
                        },
                        unit_amount: Math.round(totalAmount * 100), // Convert amount to cents
                    },
                    quantity: 1,
                },
            ],
            mode: 'payment',
            success_url: 'http://localhost:3000/api/v1/success', // Redirect URL after successful payment
            cancel_url: 'http://localhost:3000/api/v1/cancel', // Redirect URL after payment cancellation
            payment_intent_data: {
                description: `Payment for Order ${orderId} at ${restaurantId}`,
                // You can customize other Payment Intent data here
            },
        });

        // Store payment information in the database
        const paymentData = new PaymentMethod({
            user: userId,
            orderId: orderId,
            amount: totalAmount,
            restaurant_id: restaurantId,
            // paymentMethodId: 'paymentMethod.id', // Replace with the actual payment method ID
            session_id: session.id,
            stripeCustomerId: stripeCustomer.id,
            // Add other payment-related data as needed
        });

        await paymentData.save();

        res.status(200).json({ success: true, session_id: session });

    } catch (error) {
        console.error('Error creating payment:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};
const getPaymentInfo = async (req, res) => {
    try {
        const { sessionId } = req.body;

        if (!sessionId) {
            return res.status(400).json({ error: 'sessionId is required in the request body' });
        }

        // Retrieve payment status from Stripe
        const session = await stripe.checkout.sessions.retrieve(sessionId);
        const paymentStatus = session.payment_status;

        // Assuming you have a Payment model or similar structure in your database
        const paymentData = await PaymentMethod.findOne({ session_id: sessionId });

        if (!paymentData) {
            return res.status(404).json({ error: 'Payment data not found' });
        }

        const stripeCustomerId = paymentData.stripeCustomerId;
        const userId = paymentData.user;

        res.json({ sessionId, paymentStatus, stripeCustomerId, userId });
    } catch (error) {
        console.error('Error retrieving payment information:', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};
const createProductPlansSubscribeAndAttach = async (req, res) => {
    try {
        const { customerId, paymentMethodId, planDetails } = req.body;

        // Validate the incoming payload
        if (!customerId || !paymentMethodId || !planDetails) {
            return res.status(400).json({ success: false, error: 'Invalid payload. Missing required fields.' });
        }

        // Create product and plans
        const product = await stripe.products.create({
            name: 'Subscription Plan',
            type: 'service',
        });

        const plans = [
            {
                nickname: 'one day plan',
                interval: 'day',
                interval_count: 1,
                amount: 85.7,
                currency: 'usd',
            },
            // {
            //     nickname: 'Monthly Plan',
            //     interval: 'month',
            //     interval_count: 1,
            //     amount: 4999,
            //     currency: 'usd',
            // },
            // {
            //     nickname: 'Half-Yearly Plan',
            //     interval: 'month',
            //     interval_count: 6,
            //     amount: 24999,
            //     currency: 'usd',
            // },
            // {
            //     nickname: 'Yearly Plan',
            //     interval: 'year',
            //     interval_count: 1,
            //     amount: 89999,
            //     currency: 'usd',
            // }, // ... Your plans array
        ];

        const createdPlans = await Promise.all(
            plans.map(async (plan) => {
                return await stripe.plans.create({
                    product: product.id,
                    ...plan,
                });
            })
        );

        console.log('Created plans:', createdPlans);

        // Choose the plan based on provided details or default to the first plan
        const selectedPlan = planDetails.planId
            ? createdPlans.find((plan) => plan.id === planDetails.planId)
            : createdPlans[0];

        if (!selectedPlan) {
            return res.status(400).json({ success: false, error: 'Invalid plan ID.' });
        }

        // Attach payment method to customer
        await stripe.paymentMethods.attach(paymentMethodId, {
            customer: customerId,
        });

        console.log('Payment method attached successfully');

        // Subscribe customer to a plan
        const subscription = await stripe.subscriptions.create({
            customer: customerId,
            items: [{ plan: selectedPlan.id }],
        });

        console.log('Subscription created:', subscription);

        res.status(200).json({ success: true, createdPlans, subscription });
    } catch (error) {
        console.error('Error in overall process:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

const getAllPlans = async (req, res) => {
    try {
        const plans = await stripe.plans.list();
        console.log(plans);
        res.status(200).json({ message: plans });
    } catch (error) {
        res.status(500).json("internal server error")
    }
}

const createCustomerAndSubscription = async (req, res) => {
    try {
        // Create a token from card details
        const token = await stripe.tokens.create({
            card: {
                number: req.body.cardNumber,
                exp_month: req.body.cardExpMonth,
                exp_year: req.body.cardExpYear,
                cvc: req.body.cardCvc
            }
        });

        // Create a customer with the token and email
        const customer = await stripe.customers.create({
            source: token.id,
            email: req.body.customerEmail,
            metadata: {
                restaurant_id: req.body.restaurantId
            }
        });

        // Create a subscription for the customer
        const subscription = await stripe.subscriptions.create({
            customer: customer.id,
            items: [
                {
                    plan: req.body.planId
                }
            ],
            metadata: {
                restaurant_id: req.body.restaurantId
            }
        });

        // Log the successful subscription
        console.log(`Customer subscribed: ${subscription.id}`);

        // Respond with a success message
        res.status(200).json({ message: `Customer subscribed: ${subscription.id}` });
    } catch (error) {
        // Log and handle the error
        console.error(error);

        // Respond with an error message
        res.status(500).json({ message: "Internal server error" });
    }
};

const getAllProductsAndPlans = async (req, res) => {
    try {
        const [products, plans] = await Promise.all([
            stripe.products.list({}),
            stripe.plans.list({})
        ]);

        // Sort plans in ascending order of price (amount)
        const sortedPlans = plans.data.sort((a, b) => a.amount - b.amount);

        // Format plan price (amount) directly in the code
        const formattedPlans = sortedPlans.map(plan => ({
            ...plan,
            amount: `$${(plan.amount / 100).toFixed(2)} USD` // Format amount as per your requirement
        }));

        // Add plans to corresponding products
        products.data.forEach(product => {
            product.plans = formattedPlans.filter(plan => plan.product === product.id);
        });

        // Respond with the combined data
        res.status(200).json({ products: products.data });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal server error" });
    }
};

const createProduct = async (req, res) => {
    try {
        const product = await stripe.products.create({
            name: req.body.productName,
            type: 'service'
        });

        res.status(201).json({ product });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal server error" });
    }
};


module.exports = {
    createPaymentforuser,
    getPaymentInfo,
    createProductPlansSubscribeAndAttach,
    getAllPlans,
    createCustomerAndSubscription,
    createProduct,
    getAllProductsAndPlans,
}