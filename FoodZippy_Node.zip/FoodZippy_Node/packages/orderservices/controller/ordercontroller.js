const FoodOrder = require("../../common/model/orderSchema");
const WebSocket = require("ws");
const user = require("../../common/model/userSchema")
const Address = require("../../common/model/addressSchema");
const cart = require('../../common/model/addcartitemSchema');
const MenuItem = require("../../common/model/menuSchema");
const delivery = require("../../common/model/deliverypersonSchema");
const Restaurant = require("../../common/model/restaurantSchema");
const wss = require('../webscoket/websocket_sever');
const Joi = require("joi");
const { ObjectId } = require('mongodb');
const mongoose = require("mongoose")
const { v4: uuidv4 } = require("uuid");
const User = require("../../common/model/userSchema");
const { resendOTP } = require("../../userservices/controller/userController");
//let wss;

function setWebSocketServer(websocketServer) {
  wss = websocketServer;
}
// Define a Joi schema for validating the request body
const foodOrderJoiSchema = Joi.object({
  user: Joi.string(),
  cart_id: Joi.string(),
  delivery_id: Joi.string(),
  admin_id: Joi.string(),
  restaurant_id: Joi.string(),
  cash_on_delivery: Joi.boolean(),
  created_at: Joi.date(),
  updated_at: Joi.date(),
  status: Joi.string()
    .valid(
      "pending",
      "accepted",
      "preparing",
      "packing",
      "pickup",
      "on the way",
      "delivered",
      "cancel"
    )
    .default("pending"),
  comment: Joi.string(),
  is_active: Joi.boolean(),
  address_id: Joi.string(),
  payment_id: Joi.string(),
  total_amount: Joi.number(),
  userresponseforcancel: Joi.string().valid(
    "order taking too long",
    "placed order by mistake",
    "item is not available",
    "change by mind",
    "other",
  ),
  reason_for_cancel_byadmin: Joi.string().valid(
    "change in delivery address",
    "seller not able to entertain some request",
    "product is taking too long to be delivered",
    "cash not available for COD",
  ),
  reason_for_cancel_byDeliveryBoy:Joi.string(),
  created_by: Joi.string(),
  updated_by: Joi.string(),
  delivery_address_id: Joi.string(),
  quantity: Joi.number(),
  delivery_at: Joi.date(),
  preparationTime: Joi.string(),
  manualStatusUpdate: Joi.string().valid('accepted', 'preparing', 'packing', 'pickup', 'on the way', 'delivered', 'cancel').optional(),
});
const createOrder = async (req, res) => {
  try {
    // Generate orderId using UUID
    const orderId = uuidv4();
    // Retrieve user_id from the token (assuming it's stored in req.user)
    const userId = req.user.id; // Assuming user ID is available in the token payload
    // Fetch the delivery address ID from the addresses table based on the user_id
    const userAddress = await Address.findOne({
      user: userId,
      is_default: true,
    });
    if (!userAddress) {
      return res
        .status(404)
        .json({ error: "Delivery address not found for the user." });
    }
    // Update the cart with cart_id received in the request body to set _active to false
    const { cart_id } = req.body; // Assuming cart_id is provided in the request body
    if (!cart_id) {
      return res.status(404).json({ error: "Cart not found." });
    }
    // Validate cart_id in the FoodOrder table
    const existingOrderWithCartId = await FoodOrder.findOne({ cart_id });
    if (existingOrderWithCartId) {
      return res
        .status(400)
        .json({ error: "Order with this cart_id already exists." });
    }
    // Fetch the cart details including totalamount
    const cartDetails = await cart.findOne({ _id: cart_id });
    if (!cartDetails) {
      return res.status(404).json({ error: "Cart not found." });
    }
    let totalQuantity = 0;
    for (const item of cartDetails.items) {
      totalQuantity += item.quantity;
    }
    const menuItemIds = cartDetails.items.map(item => item.menu_item_id);
    const maximumPreparationTime = await MenuItem.aggregate([
      {
        $match: {
          _id: { $in: menuItemIds },
        },
      },
      {
        $group: {
          _id: null,
          maximumPreparationTime: { $max: "$preparationTime" },
        },
      },
    ]);
    // Extract the actual maximum preparation time (assuming it's the first element)
    const maxTime = maximumPreparationTime.length > 0 ? maximumPreparationTime[0].maximumPreparationTime : null;
    const restaurantId = cartDetails.restaurant_id;
    const totalAmount = cartDetails.tax_pack_totalamount;

    // Create the order object
    const orderData = {
      ...req.body,
      total_amount: totalAmount, // Assuming 'totalamount' is a field in your FoodOrder model
      restaurant_id: restaurantId,
    };
    const newOrder = new FoodOrder(orderData);

    // Set orderId, user_id obtained from token, and delivery_id obtained from the address table
    newOrder.orderId = orderId;
    newOrder.user = userId;
    newOrder.address_id = userAddress._id;
    newOrder.delivery_id = userAddress._id; // Assuming the address ID is stored in _id field
    newOrder.quantity = totalQuantity;
    newOrder.preparationTime = maxTime;
    // Save the new order
    const savedOrder = await newOrder.save();

    // Update the cart with cart_id received in the request body to set _active to false
    if (cart_id) {
      await cart.findOneAndUpdate({ _id: cart_id }, { is_active: false });
    }
    // Broadcast the order to all connected clients via WebSocket (if available)
    const orderMessage = JSON.stringify(savedOrder);
    if (wss) {
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          console.log(orderMessage, "kooooo");
          client.send(orderMessage);
        }
      });
    }
    // Modify the response to include totalamount and restaurant_id
    res.status(201).json({
      message: "Order created",
      order: savedOrder,
      total_amount: totalAmount,
      restaurant_id: restaurantId,
    });
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({ error: "Unable to create order." });
  }
};
// const updateOrderFromAdmin = async (req, res) => {
//   try {
//     const adminId = req.user.id; // Assuming admin ID is available in the token payload
//     const orderIdToUpdate = req.params.orderId; // Assuming the order ID is in the request URL parameters
//     const { delivery_id } = req.body; // Extracting delivery_id from the request body
//     // Find the order to update
//     const orderToUpdate = await FoodOrder.findOne({ orderId: orderIdToUpdate });

//     if (!orderToUpdate) {
//       return res.status(404).json({ error: "Order not found." });
//     }
//     // Update order status to 'accepted'
//     orderToUpdate.status = "accepted";
//     // Assign delivery_id if provided in the request body
//     if (delivery_id) {
//       orderToUpdate.delivery_id = delivery_id;
//     }
//     orderToUpdate.admin_id = adminId;
//     // Save the updated order
//     const updatedOrder = await orderToUpdate.save();
//     // Update the updated_at field
//     orderToUpdate.updated_at = new Date();
//     // Logic to update status in intervals (every minute) until status is 'delivered' or 'cancel'
//     const statuses = [
//       "preparing",
//       "packing",
//       "pickup",
//       "on the way",
//       "delivered",
//       "cancel",
//     ];
//     let currentIndex = 0;
//     const preparationtimes = updatedOrder.preparationTime
//     const updateStatusInterval = setInterval(async () => {
//       if (
//         currentIndex < statuses.length &&
//         orderToUpdate.status !== "delivered" &&
//         orderToUpdate.status !== "cancel"
//       ) {
//         orderToUpdate.status = statuses[currentIndex];

//         // If the status is "cancel," clear the interval immediately
//         if (orderToUpdate.status === "cancel") {
//           clearInterval(updateStatusInterval);
//         }

//         await orderToUpdate.save();

//         // Broadcast updated status to connected clients via WebSocket (if available)
//         const statusMessage = JSON.stringify({ status: orderToUpdate.status });
//         if (wss) {
//           wss.clients.forEach((client) => {
//             if (client.readyState === WebSocket.OPEN) {
//               console.log(statusMessage, "uiuiu");
//               client.send(statusMessage);
//             }
//           });
//         }

//         currentIndex++;
//       } else {
//         clearInterval(updateStatusInterval);
//       }
//     }, 60000); // Update status every 1 minute (60000 milliseconds)

//     res.status(200).json({ message: "Order updated", order: updatedOrder });
//   } catch (error) {
//     console.error("Error updating order:", error);
//     res.status(500).json({ error: "Unable to update order." });
//   }
// };
// const updateOrderFromAdmin = async (req, res) => {
//   try {
//     const adminId = req.user.id;
//     const orderIdToUpdate = req.params.orderId;

//     // Validate the request body using Joi schema
//     const { error } = foodOrderJoiSchema.validate(req.body);
//     if (error) {
//       return res.status(400).json({ error: error.details[0].message });
//     }

//     const { delivery_id, manualStatusUpdate } = req.body;

//     const orderToUpdate = await FoodOrder.findOne({ orderId: orderIdToUpdate });

//     if (!orderToUpdate) {
//       return res.status(404).json({ error: "Order not found." });
//     }

//     if (manualStatusUpdate) {
//       // Handle manual status update
//       orderToUpdate.status = manualStatusUpdate;

//       if (manualStatusUpdate === "cancel") {
//         // Clear the automatic status update interval if the status is 'cancel'
//         clearInterval(orderToUpdate.updateStatusInterval);
//       }
//     } else {
//       // Handle automatic status update
//       orderToUpdate.status = "accepted";
//     }

//     if (delivery_id) {
//       orderToUpdate.delivery_id = delivery_id;
//     }

//     orderToUpdate.admin_id = adminId;
//     const updatedOrder = await orderToUpdate.save();
//     orderToUpdate.updated_at = new Date();

//     // If there's an existing updateStatusInterval, clear it
//     if (orderToUpdate.updateStatusInterval) {
//       clearInterval(orderToUpdate.updateStatusInterval);
//     }

//     // Logic for updating status in intervals (every minute) until status is 'delivered' or 'cancel'
//     const statuses = ["preparing", "packing", "pickup", "on the way", "delivered", "cancel"];
//     let currentIndex = statuses.indexOf(orderToUpdate.status);
//     orderToUpdate.updateStatusInterval = setInterval(async () => {
//       if (
//         currentIndex < statuses.length &&
//         orderToUpdate.status !== "delivered" &&
//         orderToUpdate.status !== "cancel"
//       ) {
//         orderToUpdate.status = statuses[currentIndex];

//         if (orderToUpdate.status === "cancel") {
//           clearInterval(orderToUpdate.updateStatusInterval);
//         }

//         await orderToUpdate.save();

//         // Broadcast updated status to connected clients via WebSocket (if available)
//         const statusMessage = JSON.stringify({ status: orderToUpdate.status });
//         if (wss) {
//           wss.clients.forEach((client) => {
//             if (client.readyState === WebSocket.OPEN) {
//               console.log(statusMessage, "uiuiu");
//               client.send(statusMessage);
//             }
//           });
//         }

//         currentIndex++;
//       } else {
//         clearInterval(orderToUpdate.updateStatusInterval);
//       }
//     }, 60000);

//     res.status(200).json({ message: "Order updated", order: updatedOrder });
//   } catch (error) {
//     console.error("Error updating order:", error);
//     res.status(500).json({ error: "Unable to update order." });
//   }
// };
// const updateOrderFromAdmin = async (req, res) => {
//   try {
//     const adminId = req.user.id;
//     const orderIdToUpdate = req.params.orderId;

//     // Validate the request body using Joi schema
//     const { error } = foodOrderJoiSchema.validate(req.body);
//     if (error) {
//       return res.status(400).json({ error: error.details[0].message });
//     }

//     const { delivery_id, manualStatusUpdate } = req.body;

//     const orderToUpdate = await FoodOrder.findOne({ orderId: orderIdToUpdate });

//     if (!orderToUpdate) {
//       return res.status(404).json({ error: "Order not found." });
//     }

//     if (manualStatusUpdate !== undefined) {
//       // Handle manual status update
//       orderToUpdate.status = manualStatusUpdate;

//       if (manualStatusUpdate === "cancel") {
//         // Clear the automatic status update interval if the status is 'cancel'
//         if (orderToUpdate.updateStatusInterval) {
//           clearInterval(orderToUpdate.updateStatusInterval);
//           orderToUpdate.updateStatusInterval = null; // Ensure it's cleared
//         }
//       }
//     } else {
//       // Handle automatic status update or set a default status
//       orderToUpdate.status = "accepted"; // You can set a default status here
//     }

//     if (delivery_id) {
//       orderToUpdate.delivery_id = delivery_id;
//     }

//     orderToUpdate.admin_id = adminId;
//     orderToUpdate.updated_at = new Date();

//     // Save the updated order
//     const updatedOrder = await orderToUpdate.save();

//     // If there's an existing updateStatusInterval, clear it
//     if (orderToUpdate.updateStatusInterval) {
//       clearInterval(orderToUpdate.updateStatusInterval);
//       orderToUpdate.updateStatusInterval = null; // Ensure it's cleared
//     }

//     // Logic for updating status in intervals (every minute) until status is 'delivered' or 'cancel'
//     const statuses = ["preparing", "packing", "pickup", "on the way", "delivered", "cancel"];
//     let currentIndex = statuses.indexOf(orderToUpdate.status);

//     // Set the interval after the initial status update and save
//     orderToUpdate.updateStatusInterval = setInterval(async () => {
//       if (
//         currentIndex < statuses.length &&
//         orderToUpdate.status !== "delivered" &&
//         orderToUpdate.status !== "cancel"
//       ) {
//         orderToUpdate.status = statuses[currentIndex];

//         if (orderToUpdate.status === "cancel") {
//           clearInterval(orderToUpdate.updateStatusInterval);
//           orderToUpdate.updateStatusInterval = null; // Ensure it's cleared
//         }

//         await orderToUpdate.save();

//         // Broadcast updated status to connected clients via WebSocket (if available)
//         // const statusMessage = JSON.stringify({ status: orderToUpdate.status });
//         // if (wss) {
//         //   wss.clients.forEach((client) => {
//         //     if (client.readyState === WebSocket.OPEN) {
//         //       console.log(statusMessage, "uiuiu");
//         //       client.send(statusMessage);
//         //     }
//         //   });
//         // }

//         currentIndex++;
//       } else {
//         clearInterval(orderToUpdate.updateStatusInterval);
//         orderToUpdate.updateStatusInterval = null; // Ensure it's cleared
//       }
//     }, 60000);

//     res.status(200).json({ message: "Order updated", order: updatedOrder });
//   } catch (error) {
//     console.error("Error updating order:", error);
//     res.status(500).json({ error: "Unable to update order." });
//   }
// };
const updateOrderFromAdmin = async (req, res) => {
  try {
    const adminId = req.user.id;
    const orderIdToUpdate = req.params.orderId;

    // Validate the request body using Joi schema
    const { error } = foodOrderJoiSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { delivery_id, manualStatusUpdate } = req.body;

    const orderToUpdate = await FoodOrder.findOne({ orderId: orderIdToUpdate });

    if (!orderToUpdate) {
      return res.status(404).json({ error: "Order not found." });
    }

    if (manualStatusUpdate !== undefined) {
      // Handle manual status update
      orderToUpdate.status = manualStatusUpdate;

      if (manualStatusUpdate === "cancel") {
        // Clear the automatic status update interval if the status is 'cancel'
        if (orderToUpdate.updateStatusInterval) {
          clearInterval(orderToUpdate.updateStatusInterval);
          orderToUpdate.updateStatusInterval = null; // Ensure it's cleared
        }
      }

      // Update other order properties
      if (delivery_id) {
        orderToUpdate.delivery_id = delivery_id;
      }

      orderToUpdate.admin_id = adminId;
      orderToUpdate.updated_at = new Date();

      // Save the updated order
      const updatedOrder = await orderToUpdate.save();

      return res.status(200).json({ message: "Order updated", order: updatedOrder });
    } else {
      // If manualStatusUpdate is not provided, return a 400 error
      return res.status(400).json({ error: "Manual status update is required." });
    }
  } catch (error) {
    console.error("Error updating order:", error);
    res.status(500).json({ error: "Unable to update order." });
  }
};



const getOrdersByUser = async (req, res) => {
  try {
    // Check if user ID is provided in the request params
    const userId = req.user.id;

    if (!userId) {
      return res.status(400).json({ error: "User ID not provided" });
    }

    // Fetch all orders for the specified user
    const userOrders = await FoodOrder.find({ user: userId });

    if (userOrders.length === 0) {
      return res.status(404).json({ error: "No orders found for the user" });
    }

    // Map over user orders and fetch additional details from referenced models
    const ordersWithDetails = await Promise.all(
      userOrders.map(async (order) => {
        const addressDetails = order.address_id ? await Address.findOne({ _id: order.address_id }) : null;
        console.log(addressDetails, "addressdetails")
        const cartDetails = order.cart_id ? await cart.findOne({ _id: order.cart_id }) : null;
        console.log(cartDetails, "cartDetails");
        const userDetails = order.user ? await User.findOne({ _id: order.user }) : null;
        console.log(userDetails);
        // Extract specific details from order
        const { address_id, cart_id, user, ...orderDetails } = order.toObject();

        // Return the order with details
        return {
          order: {
            ...orderDetails,
            address: addressDetails,
            cart: cartDetails,
            user: userDetails
          }
        };
      })
    );
    console.log(ordersWithDetails, "kook")
    // Send the array of orders with details in the response
    res.status(200).json({ orders: ordersWithDetails });
  } catch (error) {
    console.error("Error fetching user orders:", error);
    res.status(500).json({ error: "Unable to fetch user orders." });
  }
};
// const getAllorder = async (req, res) => {
//   const orderId = req.query.orderid;
//   const restaurantId = req.query.restaurantid;

//   // Check if either orderId or restaurantId is missing
//   if (!orderId && !restaurantId) {
//     return res.status(400).json({ message: "Either orderId or restaurantId must be provided" });
//   }

//   try {
//     let orderQuery = {};

//     if (restaurantId) {
//       orderQuery.restaurant_id = restaurantId;
//     }
//     if (orderId) {
//       orderQuery.orderId = orderId;
//     }

//     const order = await FoodOrder.find(orderQuery).sort({ updated_at: -1 });

//     if (!order || order.length === 0) {
//       return res.status(404).json({ message: "Order not found" });
//     }

//     const orderDetails = order.map((cartid) => cartid.cart_id);

//     // Fetch user details
//     const user = await User.findById(order[0].user).select("firstName");

//     if (!user) {
//       return res.status(404).json({ message: "User not found" });
//     }

//     // Count the number of orders for the user
//     const orderCountForUser = await FoodOrder.countDocuments({ user: user._id });

//     // Fetch restaurant details
//     const restaurantDetails = await Restaurant.findById(order[0].restaurant_id);

//     if (!restaurantDetails) {
//       return res.status(404).json({ message: "Restaurant details not found" });
//     }

//     const cartDetails = await cart.find({ _id: { $in: orderDetails }, is_active: false });

//     if (!cartDetails || cartDetails.length === 0) {
//       return res.status(404).json({ message: "Cart details not found" });
//     }

//     const quantity = await cart.aggregate([
//       {
//         $match: {
//           _id: { $in: orderDetails },
//           is_active: false,
//         },
//       },
//       { $unwind: "$items" },
//       {
//         $group: {
//           _id: "$items.menu_item_id",
//           totalQuantity: { $sum: "$items.quantity" },
//         },
//       },
//     ]);

//     const totalSumQuantity = quantity.reduce((sum, item) => sum + item.totalQuantity, 0);
//     const menuitem = quantity.map((menuid) => menuid._id);

//     const menuitems = await MenuItem.find({ _id: { $in: menuitem }, is_active: true });

//     if (menuitems.length === 0) {
//       return res.status(404).json({ message: "Menu items are not found" });
//     }

//     // Fetch address details
//     const addressDetails = await Address.find({ _id: order[0].address_id });

//     if (!addressDetails || addressDetails.length === 0) {
//       return res.status(404).json({ message: "Address details not found" });
//     }

//     const response = {
//       order,
//       cartDetails,
//       quantity,
//       totalSumQuantity,
//       menuitems,
//       addressDetails,
//       user,
//       orderCountForUser,
//       restaurantDetails,
//     };
//     res.status(200).json({ message: "Food Order Details", response });
//   } catch (error) {
//     console.log("Error", error);
//     res.status(500).json({ message: "Internal server error" });
//   }
// };
const getAllorder = async (req, res) => {
  const orderId = req.query.orderid;
  const restaurantId = req.query.restaurantid;

  // Check if either orderId or restaurantId is missing
  if (!orderId && !restaurantId) {
    return res.status(400).json({ message: "Either orderId or restaurantId must be provided" });
  }

  try {
    let orderQuery = {};

    if (restaurantId) {
      orderQuery.restaurant_id = restaurantId;
    }
    if (orderId) {
      orderQuery.orderId = orderId;
    }

    // Exclude orders with status "delivered" and "cancel"
    orderQuery.status = { $nin: ['preparing', 'packing', 'pickup', 'on the way', 'delivered', 'cancel',] };
    const order = await FoodOrder.find(orderQuery).sort({ updated_at: -1 });

    if (!order || order.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const orderDetails = order.map((cartid) => cartid.cart_id);

    // Fetch user details
    const user = await User.findById(order[0].user).select("firstName");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Count the number of orders for the user
    const orderCountForUser = await FoodOrder.countDocuments({ user: user._id });

    // Fetch restaurant details
    const restaurantDetails = await Restaurant.findById(order[0].restaurant_id);

    if (!restaurantDetails) {
      return res.status(404).json({ message: "Restaurant details not found" });
    }

    const cartDetails = await cart.find({ _id: { $in: orderDetails }, is_active: false });

    if (!cartDetails || cartDetails.length === 0) {
      return res.status(404).json({ message: "Cart details not found" });
    }

    const quantity = await cart.aggregate([
      {
        $match: {
          _id: { $in: orderDetails },
          is_active: false,
        },
      },
      { $unwind: "$items" },
      {
        $group: {
          _id: "$items.menu_item_id",
          totalQuantity: { $sum: "$items.quantity" },
        },
      },
    ]);

    const totalSumQuantity = quantity.reduce((sum, item) => sum + item.totalQuantity, 0);
    const menuitem = quantity.map((menuid) => menuid._id);

    const menuitems = await MenuItem.find({ _id: { $in: menuitem }, is_active: true });

    if (menuitems.length === 0) {
      return res.status(404).json({ message: "Menu items are not found" });
    }

    // Fetch address details
    const addressDetails = await Address.find({ _id: order[0].address_id });

    if (!addressDetails || addressDetails.length === 0) {
      return res.status(404).json({ message: "Address details not found" });
    }

    const response = {
      order,
      cartDetails,
      quantity,
      totalSumQuantity,
      menuitems,
      addressDetails,
      user,
      orderCountForUser,
      restaurantDetails,
    };
    res.status(200).json({ message: "Food Order Details", response });
  } catch (error) {
    console.log("Error", error);
    res.status(500).json({ message: "Internal server error" });
  }
};



const getOrderById = async (req, res) => {
  try {
    const orderId = req.params.orderId;
    // Fetch order by orderId
    const order = await FoodOrder.findOne({ orderId });

    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    // Fetch details from referenced models
    const addressDetails = order.address_id ? await Address.findOne({ _id: order.address_id }) : null;
    const cartDetails = order.cart_id ? await cart.findOne({ _id: order.cart_id }) : null;
    const userDetails = order.user ? await User.findOne({ _id: order.user }) : null;
    const restauarntDetails = order.restaurant_id ? await Restaurant.findOne({ _id: order.restaurant_id }) : null;
    // Extract specific details from order
    const { address_id, cart_id, user, ...orderDetails } = order.toObject();

    // Include details in the response
    res.status(200).json({
      order: {
        ...orderDetails,
        address: addressDetails,
        cart: cartDetails,
        user: userDetails,
        restaurant: restauarntDetails,
      }
    });
  } catch (error) {
    console.error("Error fetching order:", error);
    res.status(500).json({ error: "Unable to fetch order." });
  }
};
const cancelOrderFromUser = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming user ID is available in the token payload
    const orderIdToCancel = req.params.orderId; // Assuming the order ID is in the request URL parameters

    // Find the order to cancel
    let orderToCancel = await FoodOrder.findOne({ orderId: orderIdToCancel, user: userId });

    if (!orderToCancel) {
      return res.status(404).json({ error: "Order not found or unauthorized." });
    }

    const { error: validationError, value: updatedOrderData } = foodOrderJoiSchema.validate(req.body, {
      abortEarly: false, // Validate all fields, not just the first one that fails
      allowUnknown: true, // Allow unknown fields that are not defined in the schema
    });

    if (validationError) {
      return res.status(400).json({ error: validationError.details.map(err => err.message) });
    }

    // Update order status to 'cancel' and set the user's response for canceling the order
    updatedOrderData.status = "cancel";
    orderToCancel = await FoodOrder.findOneAndUpdate(
      { orderId: orderIdToCancel, user: userId },
      updatedOrderData,
      { new: true }
    );

    res.status(200).json({ message: "Order canceled", order: orderToCancel });
  } catch (error) {
    console.error("Error canceling order:", error);
    res.status(500).json({ error: "Unable to cancel order." });
  }
};
const cancelOrderByAdmin = async (req, res) => {
  try {
    const adminId = req.user.id; // Assuming admin ID is available in the token payload
    const orderIdToCancel = req.params.orderId; // Assuming the order ID is in the request URL parameters

    // Find the order to cancel
    let orderToCancel = await FoodOrder.findOne({ orderId: orderIdToCancel });
    console.log(orderToCancel, "odwnkjfdjiosdn");
    if (!orderToCancel) {
      return res.status(404).json({ error: "Order not found." });
    }

    const { error: validationError, value: updatedOrderData } = foodOrderJoiSchema.validate(req.body, {
      abortEarly: false, // Validate all fields, not just the first one that fails
      allowUnknown: true, // Allow unknown fields that are not defined in the schema
    });

    if (validationError) {
      return res.status(400).json({ error: validationError.details.map(err => err.message) });
    }

    // Update order status to 'cancel' and set the admin's reason for canceling the order
    updatedOrderData.status = "cancel";
    updatedOrderData.reason_for_cancel_byadmin = req.body.reason_for_cancel_byadmin; // Admin's reason for cancellation
    updatedOrderData.updated_by = adminId; // Update the 'updated_by' field with admin's ID

    orderToCancel = await FoodOrder.findOneAndUpdate(
      { orderId: orderIdToCancel },
      updatedOrderData,
      { new: true }
    );

    res.status(200).json({ message: "Order canceled by admin", order: orderToCancel });
  } catch (error) {
    console.error("Error canceling order by admin:", error);
    res.status(500).json({ error: "Unable to cancel order by admin." });
  }
};

const getOrderByAdmin = async (req, res) => {
  const adminId = req.user.id
  if (!adminId) {
    return res.status(400).json({ message: "Token Not Provided" })
  }
  try {
    const order = await FoodOrder.findOne({ admin_id: adminId })
    const carts = await cart.findOne({ _id: order.cart_id })
    const users = await user.findOne({ _id: order.user })
    res.status(200).json({
      message: "get completed",
      orderid: order._id,
      time: order.created_at,
      firstname: users.firstName,
      lastname: users.lastName,
      mobile: users.mobile,
      email: users.email, carts
    })
  } catch (err) {
    console.log(err)
    res.status(500).json({ message: "Internal Server Error", err })
  }
}

const customersDetails = async (req, res) => {
  const adminid = req.user.id;
  const resId = req.params.id;

  // if (!adminid || !resId) {
  //   return res.status(401).json({ message: "Token and resid not provided" });
  // }

  try {
    const carts = await cart.aggregate([
      { $match: { restaurantId: resId, is_active: false } },
    ]);

    const userIds = carts.map((cart) => cart.userId);
    const users = await user.find({ _id: { $in: userIds } });

    const userDetails = users.map((user) => ({
      userId: user._id,
      firstname: user.firstName,
      lastname: user.lastName,
      email: user.email,
    }));

    const orders = await cart.aggregate([
      { $match: { is_active: false } },
      { $group: { _id: "$userId", orderCount: { $sum: 1 } } },
    ]);

    const totalAmounts = await cart.aggregate([
      { $group: { _id: "$userId", totalAmount: { $sum: "$totalAmount" } } },
    ]);

    const totalAmountsMap = totalAmounts.reduce((acc, entry) => {
      acc[entry._id] = entry.totalAmount;
      return acc;
    }, {});

    const userIdsWithAverage = {};
    Object.keys(totalAmountsMap).forEach((userId) => {
      const totalAmount = totalAmountsMap[userId];
      const orderCount =
        orders.find((order) => order._id === userId)?.orderCount || 0;
      const averageTotalAmount = orderCount > 0 ? totalAmount / orderCount : 0;
      userIdsWithAverage[userId] = averageTotalAmount;
    });

    // res.status(200).json({
    //   message: "Get completed",
    //   customersDetails: userDetails,
    //   orders,
    //   totalAmounts: totalAmountsMap,
    //   averageTotalAmounts: userIdsWithAverage,
    // });
    return res.status(200).json({
      success: true,
      message: {
        text: "Get order successfully.",
        additionalInfo: {
          customersDetails: userDetails,
          orders,
          totalAmounts: totalAmountsMap,
          averageTotalAmounts: userIdsWithAverage,
        },
      },
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
const getCustomerInfo = async (req, res) => {
  const userId = req.params.userid;
  const restaurantId = req.params.restaurantid;
  if (!userId) {
    return res.status(401).json({ message: "Token and userId not provided" });
  }

  try {
    // const userID = new mongoose.Types.ObjectId(userId);
    const users = await user
      .findOne({ _id: userId })
      .select("firstName lastName mobile");
    if (!users) {
      return res.status(404).json({ error: "User not found" });
    }

    const orders = await cart.aggregate([
      { $match: { userId: userId, restaurantId: restaurantId } },
      { $group: { _id: "$userId", orderCount: { $sum: 1 } } },
    ]);

    const totalAmounts = await cart.aggregate([
      { $match: { userId: userId, restaurantId: restaurantId } },
      { $group: { _id: "$userId", totalAmount: { $sum: "$totalAmount" } } },
    ]);

    const totalAmountsMap = totalAmounts.reduce((acc, entry) => {
      acc[entry._id] = entry.totalAmount;
      return acc;
    }, {});

    const userIdsWithAverage = {};
    Object.keys(totalAmountsMap).forEach((userId) => {
      const totalAmount = totalAmountsMap[userId];
      const orderCount =
        orders.find((order) => order._id === userId)?.orderCount || 0;
      const averageTotalAmount = orderCount > 0 ? totalAmount / orderCount : 0;
      userIdsWithAverage[userId] = averageTotalAmount;
    });

    const lastOrders = await cart.aggregate([
      { $match: { userId: userId } },
      { $sort: { createdat: -1 } },
      { $group: { _id: "$userId", orderCount: { $sum: 1 }, lastOrder: { $first: "$$ROOT" } } },
    ]);

    const ordersWithVoucher = await cart.aggregate([
      {
        $match: { userId: userId, restaurantId: restaurantId, voucherDiscount: { $exists: true } }
      },
      { $group: { _id: "$userId", totalOrderCount: { $sum: 1 } } },
    ]);

    const ordersWithDiscount = await cart.aggregate([
      { $match: { userId: userId, restaurantId: restaurantId } },
      { $group: { _id: "$userId", totalDiscount: { $sum: "$voucherDiscount" } } },
    ]);

    const orderHistory = await Restaurant.find({ _id: restaurantId }).select("restaurantName");

    const ordersId = await FoodOrder.find({ restaurant_id: restaurantId, user: userId }).select("orderId user status ");

    const TotalOrders = await FoodOrder.aggregate([
      { $match: { restaurant_id: restaurantId, user: userId } },
      { $group: { _id: "$orderId", totalAmount: { $sum: "$total_amount" } } },
    ]);

    const address = await Address.findOne({ user: userId });
    if (!address) {
      return res.status(404).json({ error: "address not found" });
    }

    // res.status(200).json({
    //   customerInfo: users,
    //   TotalOrder: orders,
    //   totalAmount: totalAmountsMap,
    //   orderValue: userIdsWithAverage,
    //   lastOrder: lastOrders,
    //   orderWithVoucher: ordersWithVoucher,
    //   ordersWithDiscount: ordersWithDiscount,
    //   orderHistory,
    //   ordersId,
    //   totalOrderValue: TotalOrders,
    //   address,
    // });
    return res.status(200).json({
      success: true,
      message: {
        text: "Get order successfully.",
        additionalInfo: {
          customerInfo: users,
          TotalOrder: orders,
          totalAmount: totalAmountsMap,
          orderValue: userIdsWithAverage,
          lastOrder: lastOrders,
          orderWithVoucher: ordersWithVoucher,
          ordersWithDiscount: ordersWithDiscount,
          orderHistory,
          ordersId,
          totalOrderValue: TotalOrders,
          address,
        },
      },
    });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Unable to fetch user." });
  }
};

const totalSalesReport = async (req, res) => {
  const adminId = req.user.id;
  const restaurantId = req.params.id;

  if (!restaurantId && !adminId) {
    return res.status(401).json({
      message:
        "restaurant id is not available in params or authentication issue",
    });
  }
  try {
    const salesReport = await FoodOrder.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          status: "delivered",
        },
      },
      {
        $lookup: {
          from: "cartresponse2",
          localField: "cart_id",
          foreignField: "_id",
          as: "cartitem",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "users",
          foreignField: "_id",
          as: "user",
        },
      },
      {
        $group: {
          _id: {
            user: "$user._id",
          },
          salesReport: { $push: "$$ROOT" },
        },
      },
      {
        $project: {
          data: {
            salesReport: "$salesReport",
            cartitem: "$cartitem",
          },
        },
      },
    ]);


    const getrestaurants = await Restaurant.find({ _id: restaurantId });

    const findNetSales = await FoodOrder.aggregate([
      {
        $match: {
          restaurant_id: restaurantId,
          status: "delivered",
        },
      },
      {
        $group: {
          _id: null,
          total_amount: { $sum: "$total_amount" },
        },
      },
    ]);

    const netSales = findNetSales.length > 0 ? findNetSales[0].total_amount : 0;

    res.status(200).json({ message: "salesNet report", salesReport, restaurant: getrestaurants, TotalNetSales: netSales });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "internal server error" });
  }
};

//sales report, rushHours, total order, delivery pending, total delivery
// const salesReport = async (req, res) => {
//   const adminId = req.user.id;
//   const restaurantId = req.params.id;
//   if (!adminId || !restaurantId) {
//     return res.status(401).json({
//       message: "token is not provided in authentication and restaurantid",
//     });
//   }
//   try {
//     //today
//     const currentDate = new Date();
//     console.log(currentDate)
//     currentDate.setHours(0, 0, 0, 0);
//     //week
//     const startOfWeek = new Date(currentDate);
//     startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
//     //month
//     const startOfMonth = new Date(
//       currentDate.getFullYear(),
//       currentDate.getMonth(), 1);

//     //get order
//     const orderinfo = await FoodOrder.find({
//       admin_id: adminId,
//       restaurant_id: restaurantId,
//       // status: 'delivered'
//     });
//     if (!orderinfo && orderinfo) {
//       return res.status(401).json({ message: "restaurant id is not found" });
//     }

//     const cartDetails = orderinfo.map((order) => ({ cart_id: order.cart_id }));
//     console.log("lop", cartDetails);

//     const totalFinalAmountToday = await cart.aggregate([
//       {
//         $match: {
//           // "items.cart_id": { $in: cartIds },
//           createdat: { $gte: currentDate },
//           is_active: { $eq: false }
//         },
//       },
//       {
//         $group: {
//           _id: 0,
//           FinalAmountTodaySum: { $sum: "$tax_pack_totalamount" },
//         },
//       },
//     ]);

//     const totalFinalAmountForToday =
//       totalFinalAmountToday.length > 0
//         ? totalFinalAmountToday[0].FinalAmountTodaySum
//         : false || 0;
//     console.log("Total Final Amount for Today:", totalFinalAmountForToday);


//     const totalFinalAmountThisWeek = await cart.aggregate([
//       {
//         $match: {
//           // "items.cart_id": { $in: cartIds },
//           createdat: { $gte: startOfWeek },
//           is_active: { $eq: false }
//         },
//       },
//       {
//         $group: {
//           _id: 0,
//           totalFinalAmountThisWeek: { $sum: "$tax_pack_totalamount" },
//         },
//       },
//     ]);

//     const totalFinalAmountForThisWeek =
//       totalFinalAmountThisWeek.length > 0
//         ? totalFinalAmountThisWeek[0].totalFinalAmountThisWeek
//         : 0;
//     console.log(
//       "Total Final Amount for This Week:",
//       totalFinalAmountForThisWeek
//     );

//     // Calculate total final amount for this month

//     const totalFinalAmountThisMonth = await cart.aggregate([
//       {
//         $match: {
//           // "cartitem.cart_id": { $in: cartIds },
//           createdat: { $gte: startOfMonth },
//           is_active: { $eq: false }
//         },
//       },
//       {
//         $group: {
//           _id: 0,
//           totalFinalAmountThisMonth: { $sum: "$tax_pack_totalamount" },
//         },
//       },
//     ]);

//     const totalFinalAmountForThisMonth =
//       totalFinalAmountThisMonth.length > 0
//         ? totalFinalAmountThisMonth[0].totalFinalAmountThisMonth
//         : 0;
//     console.log(
//       "Total Final Amount for This Month:",
//       totalFinalAmountForThisMonth
//     );
//     const deliveredOrders = await FoodOrder.find({
//       restaurant_id: restaurantId,
//       status: "delivered",
//       created_at: { $gte: currentDate },
//     });

//     const totalDeliveredOrders = deliveredOrders.length;

//     const pendingOrders = await FoodOrder.find({
//       restaurant_id: restaurantId,
//       status: { $ne: "delivered" },
//       created_at: { $gte: currentDate },
//     });

//     const totalPendingOrders = pendingOrders.length;
//     res.status(200).json({
//       message: "restaurant get ok",
//       orderinfo,
//       totalDeliveredOrders,
//       totalPendingOrders,
//       totalFinalAmountForToday,
//       totalFinalAmountForThisWeek,
//       totalFinalAmountForThisMonth,
//     });
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ message: "internal server error" });
//   }
// };


const salesReport = async (req, res) => {
  const admin_id = req.user.id;
  const restaurant_id = req.params.id;
  if (!admin_id || !restaurant_id) {
    return res.status(401).json({
      message: "token is not provided in authentication and restaurantid",
    });
  }
  try {
    //today
    const currentDate = new Date();
    console.log(currentDate);
    currentDate.setHours(0, 0, 0, 0);

    //week
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());

    //month
    const startOfMonth = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      1
    );
    const totalFinalAmountToday = await FoodOrder.find({
      restaurant_id,
      admin_id,
      status: 'delivered',
      created_at: { $gte: currentDate },
    });

    const totalFinalAmountForToday = totalFinalAmountToday.reduce((total, totalFinalAmountToday) => {
      return total + totalFinalAmountToday.total_amount;
    }, 0);

    console.log("today sales amount", totalFinalAmountForToday)

    // Calculate total final amount for this week
    const totalFinalAmountThisWeek = await FoodOrder.find({
      restaurant_id,
      admin_id,
      status: 'delivered',
      created_at: { $gte: startOfWeek },
    });

    const totalFinalAmountForThisWeek = totalFinalAmountThisWeek.reduce((total, totalFinalAmountThisWeek) => {
      return total + totalFinalAmountThisWeek.total_amount;
    }, 0);
    console.log(
      "Total Final Amount for This Week:",
      totalFinalAmountForThisWeek
    );

    // Calculate total final amount for this month
    const totalFinalAmountThisMonth = await FoodOrder.find({
      restaurant_id,
      admin_id,
      status: 'delivered',
      created_at: { $gte: startOfMonth },
    })

    const totalFinalAmountForThisMonth = totalFinalAmountThisMonth.reduce((total, totalFinalAmountThisMonth) => {
      return total + totalFinalAmountThisMonth.total_amount;
    }, 0);
    console.log(
      "Total Final Amount for This Month:",
      totalFinalAmountForThisMonth
    );

    const deliveredOrders = await FoodOrder.find({
      restaurant_id,
      status: "delivered",
      created_at: { $gte: currentDate },
    });

    const totalDeliveredOrders = deliveredOrders.length;

    const pendingOrders = await FoodOrder.find({
      restaurant_id,
      status: { $ne: "delivered" },
      created_at: { $gte: currentDate },
    });

    const totalPendingOrders = pendingOrders.length;
    res.status(200).json({
      message: "restaurant get ok",
      totalDeliveredOrders,
      totalPendingOrders,
      totalFinalAmountForToday,
      totalFinalAmountForThisWeek,
      totalFinalAmountForThisMonth,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "internal server error" });
  }
};

//most order food
//most order food
const mostOrder = async (req, res) => {
  const restaurantId = req.params.id;
  const timePeriod = req.query.timeperiod;

  try {
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    let startDate, endDate;

    // Calculate start and end dates based on time period
    switch (timePeriod) {
      case "today":
        startDate = currentDate;
        endDate = new Date(); // Today's date
        endDate.setHours(23, 59, 59, 999); // Set end time to end of the day
        break;
      case "thisweek":
        startDate = new Date(currentDate);
        startDate.setDate(startDate.getDate() - startDate.getDay()); // Start of the week
        endDate = new Date(currentDate);
        endDate.setDate(endDate.getDate() - endDate.getDay() + 6); // End of the week
        endDate.setHours(0, 0, 0, 0); // Set end time to end of the day
        break;
      case "thismonth":
        startDate = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          1
        ); // Start of the month
        endDate = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth() + 1,
          0
        ); // End of the month
        endDate.setHours(0, 0, 0, 0); // Set end time to end of the day
        break;
      default:
        return res.status(400).json({ message: "Invalid time period" });
    }

    const restaurantIds = await Restaurant.find({ _id: restaurantId });
    console.log(restaurantIds)
    const restaurantIdArray = restaurantIds.map((restaurant) => restaurant._id);
    console.log(restaurantIdArray);

    const mostOrderedFood = await cart.aggregate([
      {
        $match: {
          restaurant_id: { $in: restaurantIdArray },
          createdat: { $gte: startDate, $lte: endDate },
          is_active: { $eq: false },
        },
      },
      {
        $unwind: "$items",
      },
      {
        $group: {
          _id: {
            foodName: "$items.menu_item_name",
            category: "$items.additemvariant.category",
            price: "$items.menu_item_price",
          },
          totalPersonOrders: { $addToSet: "$userId" },
          lastOrderTime: { $max: "$createdat" },
        },
      },
      {
        $sort: { lastOrderTime: -1 }, // Sort by last order time (descending)
      },
      {
        $limit: 10, // Limit to top 10 results
      },
      {
        $project: {
          _id: 0,
          userId: { $size: "$totalPersonOrders" },
          foodName: "$_id.foodName",
          category: "$_id.category",
          price: "$_id.price",
          lastOrderTime: 1,
          timeDifference: {
            $let: {
              vars: {
                diff: { $divide: [{ $subtract: [new Date(), "$lastOrderTime"] }, 1000 * 60] },
              },
              in: {
                $cond: [
                  { $lt: ["$$diff", 60] },
                  { $concat: [{ $toString: { $floor: "$$diff" } }, " mins"] },
                  {
                    $cond: [
                      { $lt: ["$$diff", 1440] },
                      { $concat: [{ $toString: { $floor: { $divide: ["$$diff", 60] } } }, " hours"] },
                      { $concat: [{ $toString: { $floor: { $divide: ["$$diff", 1440] } } }, " days"] },
                    ],
                  },
                ],
              },
            },
          },
        },
      },
    ]);

    res.status(200).json({
      message: `Top 10 most ordered foods in the current ${timePeriod} retrieved successfully`,
      mostOrderedFood,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};


function getDatePeriodFilter(datePeriod) {
  switch (datePeriod) {
    case 'today':
      return { $gte: new Date(new Date().setHours(0, 0, 0, 0)) };
    case 'thisWeek':
      const today = new Date();
      const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
      return { $gte: startOfWeek };
    case 'thisMonth':
      const todays = new Date();
      const startOfMonth = new Date(todays.getFullYear(), todays.getMonth(), 1);
      return { $gte: startOfMonth };
    default:
      return {};
  }
}
const overallReports = async (req, res) => {
  try {
    const restaurantId = req.params.restaurant_id;

    // Construct the match filter based on query parameters
    const matchFilter = { restaurant_id: restaurantId };
    if (req.query.datePeriod) {
      // Implement date period filter logic here
      matchFilter.created_at = getDatePeriodFilter(req.query.datePeriod);
    }
    if (req.query.restaurantName) {
      matchFilter.restaurantName = req.query.restaurantName;
    }
    if (req.query.deliveryType) {
      matchFilter.status = req.query.deliveryType === 'delivered' ? 'delivered' : 'takeaway';
    }
    if (req.query.voucherCode) {
      matchFilter.voucherCode = req.query.voucherCode;
    }

    // Calculate total order count
    const totalOrderCount = await FoodOrder.countDocuments(matchFilter);

    // Calculate overall order amount
    const overallOrderAmountResult = await FoodOrder.aggregate([
      { $match: matchFilter },
      { $group: { _id: null, totalAmount: { $sum: "$total_amount" } } }
    ]);
    const overallOrderAmount = overallOrderAmountResult.length > 0 ? overallOrderAmountResult[0].totalAmount : 0;

    // Calculate cancel order count
    const cancelOrderCount = await FoodOrder.countDocuments({
      ...matchFilter,
      status: "cancel",
    });

    // Calculate cancel order total amount
    const cancelOrderAmountResult = await FoodOrder.aggregate([
      { $match: { ...matchFilter, status: "cancel" } },
      { $group: { _id: null, totalAmount: { $sum: "$total_amount" } } }
    ]);
    const cancelOrderAmount = cancelOrderAmountResult.length > 0 ? cancelOrderAmountResult[0].totalAmount : 0;

    // Calculate refund order count
    const refundOrderCount = await FoodOrder.countDocuments({
      ...matchFilter,
      status: "cancel",
      userresponsefrocancel: "refund",
    });

    // Calculate refund order total amount
    const refundOrderAmountResult = await FoodOrder.aggregate([
      { $match: { ...matchFilter, status: "cancel", userresponsefrocancel: "refund" } },
      { $group: { _id: null, totalAmount: { $sum: "$total_amount" } } }
    ]);
    const refundOrderAmount = refundOrderAmountResult.length > 0 ? refundOrderAmountResult[0].totalAmount : 0;

    // Calculate average order size
    const averageOrderSize = totalOrderCount > 0 ? overallOrderAmount / totalOrderCount : 0;

    return res.json({
      success: true,
      message: {
        text: "get order successfully",
        additionalInfo: {
          totalOrderCount,
          overallOrderAmount,
          averageOrderSize,
          cancelOrderCount,
          cancelOrderAmount,
          refundOrderCount,
          refundOrderAmount,
        }
      },
    });
  } catch (error) {
    console.error("Error in overall report controller:", error);
    return res.status(500).json({ success: false, error: "Internal Server Error" });
  }
};


const businessreview = async (req, res) => {
  const restaurantId = req.params.id;
  try {
    const restaurantOrders = await FoodOrder.find({ restaurant_id: restaurantId });
    if (restaurantOrders.length === 0) {
      return res.status(404).json({ message: "No orders found for the specified restaurant" });
    }

    // Calculate time period based on the query parameters
    let filter = {};
    const { timePeriod, restaurantName } = req.query;
    console.log("Restaurant Name:", restaurantName);

    // Add restaurant name filter
    if (restaurantName) {
      filter.restaurantName = restaurantName;
      console.log("ji", filter.restaurantName = restaurantName)
    }

    if (timePeriod === 'today') {
      filter.updated_at = { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }; // Today's records
    } else if (timePeriod === 'thisWeek') {
      const today = new Date();
      const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
      filter.updated_at = { $gte: startOfWeek }; // This week's records
    } else if (timePeriod === 'thisMonth') {
      const today = new Date();
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      filter.updated_at = { $gte: startOfMonth }; // This month's records
    }

    // Find all orders for the restaurant with applied filters
    const restaurantOrdersFiltered = await FoodOrder.find({
      restaurant_id: restaurantId,
      ...filter
    });

    // Perform aggregation on the retrieved orders
    const aggregatedData = await FoodOrder.aggregate([
      {
        $match: {
          _id: { $in: restaurantOrdersFiltered.map(order => order._id) },
          status: "delivered", // Use ObjectIds directly
        },
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalRevenue: { $sum: "$total_amount" },
          averageOrderValue: { $avg: "$total_amount" },
          ordersPerCustomer: { $addToSet: "$user" },
          earliestOrderDate: { $min: "$created_at" },
        },
      },
    ]);
    console.log("Aggregated Data:", aggregatedData);
    // Access and use the aggregated data
    const { totalOrders, totalRevenue, averageOrderValue, ordersPerCustomer, earliestOrderDate } = aggregatedData[0];

    res.status(200).json({
      message: "Review data retrieved successfully",
      totalOrders,
      totalRevenue,
      averageOrderValue,
      ordersPerCustomer: ordersPerCustomer.length,
      earliestOrderDate,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};


const campaignPerReport = async (req, res) => {
  const resId = req.params.id;
  const { timePeriod, restaurantName } = req.query;

  if (!resId) {
    return res.status(401).json({ message: "Restaurant Id not provided" });
  }

  try {
    // Construct match filter based on query parameters
    const matchFilter = { restaurant_id: resId };
    if (timePeriod) {
      matchFilter.created_at = getDatePeriodFilter(timePeriod);
    }
    if (restaurantName) {
      matchFilter.restaurantName = restaurantName;
    }

    const restaurantIdOrders = await FoodOrder.find({ restaurant_id: resId })

    const cartIds = restaurantIdOrders.map((order) => order.cart_id);

    const users = await cart.find({ _id: { $in: cartIds } });

    const restaurantIds = users.map((user) => user._id);

    const totalAmounts = await cart.aggregate([
      { $match: { _id: { $in: restaurantIds }, voucherDiscount: { $ne: 0 } } },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: "$totalAmount" },
          totalVoucherAmount: { $sum: "$voucherDiscount" },
          totalOrdersWithVouchers: { $sum: 1 },
        },
      },
    ]);

    const percentage = totalAmounts.length > 0
      ? (totalAmounts[0].totalOrdersWithVouchers / totalAmounts[0].totalVoucherAmount) * 100
      : 0;

    res.status(200).json({
      message: "get completed",
      ordersWithVoucher: totalAmounts,
      percentageOfOrdersWithVouchers: percentage,
    });

  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Unable to fetch." });
  }
};

const customerReport = async (req, res) => {
  const restaurantId = req.params.id;
  if (!restaurantId) {
    return res.status(401).json({ message: "Token and restaurantId not provided" });
  }
  try {
    // const restaurantId =new mongoose.Types.ObjectId(restaurantIds)
    const customer = await FoodOrder.find({ restaurant_id: restaurantId });
    if (!customer) {
      return res.status(404).json({ error: " customer not found" });
    }
    res.status(200).json({ message: "get completed", customer });
  } catch (error) {
    console.error("Error fetching customer:", error);
    res.status(500).json({ error: "Unable to fetch customer." });
  }
};

const netSales = async (req, res) => {
  const adminId = req.user.id;
  if (!adminId) {
    return res.status(400).json({ message: "Token not provided" });
  }

  const { timePeriod, restaurantName } = req.query;

  try {
    let filter = { admin_id: adminId };

    // Apply additional filters based on query parameters
    if (timePeriod === 'today') {
      filter.updated_at = { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }; // Today's records
    } else if (timePeriod === 'thisWeek') {
      const today = new Date();
      const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
      filter.updated_at = { $gte: startOfWeek }; // This week's records
    } else if (timePeriod === 'thisMonth') {
      const today = new Date();
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      filter.updated_at = { $gte: startOfMonth }; // This month's records
    }

    if (restaurantName) {
      filter.restaurantName = restaurantName;
    }

    // Find all restaurants belonging to the admin with optional filters
    const restaurants = await Restaurant.find(filter);

    // Iterate through each restaurant to calculate net sales
    const netSalesReports = [];
    for (const restaurant of restaurants) {
      // Find orders and carts for the current restaurant
      const orders = await FoodOrder.find({ restaurant_id: restaurant._id });
      const carts = await cart.find({ is_active: false, restaurant_id: restaurant._id });

      // Calculate total net sales for the restaurant
      const totalNetSales = carts.reduce((acc, cart) => acc + cart.totalAmount, 0);

      // Calculate total delivery fee and tax from carts
      let totalDeliveryFee = 0;
      let totalTax = 0;
      let discount = 0;
      let FoodOrderAmount = 0;
      let totalFoodAmount = 0;
      for (const cart of carts) {
        totalDeliveryFee += cart.deliveryfee || 0;
        totalTax += cart.vat_tax || 0;
        FoodOrderAmount += cart.totalAmount || 0;
        totalFoodAmount += cart.tax_pack_totalamount || 0;
      }

      // Get the last updated order details
      const lastUpdatedOrder = orders.length > 0 ? orders[orders.length - 1] : null;

      // Extract details from the last updated order
      const lastUpdatedOrderId = lastUpdatedOrder ? lastUpdatedOrder.orderId : null;
      const lastUpdatedOrderStatus = lastUpdatedOrder ? lastUpdatedOrder.status : null;
      const lastUpdatedOrderPaymentType = lastUpdatedOrder ? lastUpdatedOrder.paymentType : null;
      const lastUpdatedOrderDeliveryType = lastUpdatedOrder ? lastUpdatedOrder.deliveryType : null;
      const lastUpdatedOrderUpdatedAt = lastUpdatedOrder ? lastUpdatedOrder.updated_at : null;

      // Get the last updated user details for the cart
      const lastUpdatedUser = await User.findById(carts[carts.length - 1]?.userId); // Fetch user details based on userId

      // Push the net sales report for the restaurant
      netSalesReports.push({
        restaurant_id: restaurant._id,
        restaurantName: restaurant.restaurantName,
        totalNetSales: totalNetSales,
        restaurantTimeend: restaurant.updated_at,
        restaurantTimestart: restaurant.created_at,
        deliveryfee: totalDeliveryFee,
        tax: totalTax,
        cartDiscount: discount,
        FoodOrderAmount: FoodOrderAmount,
        totalFoodAmount: totalFoodAmount,
        lastUpdatedUser: lastUpdatedUser
          ? {
            _id: lastUpdatedUser._id,
            firstName: lastUpdatedUser.firstName,
            lastName: lastUpdatedUser.lastName,
            phone: lastUpdatedUser.mobile,
          }
          : null, // Include last updated user details
        lastUpdatedOrderId: lastUpdatedOrderId,
        lastUpdatedOrderStatus: lastUpdatedOrderStatus,
        lastUpdatedOrderPaymentType: lastUpdatedOrderPaymentType,
        lastUpdatedOrderDeliveryType: lastUpdatedOrderDeliveryType,
        lastUpdatedOrderUpdatedAt: lastUpdatedOrderUpdatedAt,
        //salestotal: netSalesReports,
      });
    }

    // Send the net sales reports for all restaurants
    res.status(200).json({ message: "Net sales reports", netSalesReports });
  } catch (error) {
    console.log("error", error)
    res.status(500).json({ message: 'internal server error' })
  }

}
const livenotificationforadmin = async (req, res) => {
  try {
    const restaurantId = req.params.restaurantId;
    let orders;

    const sendOrdersToClientss = async () => {
      try {
        orders = await FoodOrder.find({
          restaurant_id: restaurantId,
          status: "pending",
        }).sort({ updated_at: -1 });
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ message: "New orders received", orders }));
          }
        });
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };

    // Periodically update orders every 2 seconds
    const intervalId = setInterval(sendOrdersToClientss, 2000);

    // Call the function immediately to send initial orders
    await sendOrdersToClientss();

    // Respond to the client
    res.status(200).json({ message: "ok", orders });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "internal server error" });
  }
};
const eodReport = async (req, res) => {
  const restaurantid = req.params.id;
  if (!restaurantid) {
    return res.status(401).json({ message: "restaurant id is not found in the id" });
  }
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Set time to midnight
    const matchCriteria = {
      restaurant_id: restaurantid,
      created_at: { $gte: today }, // Filter for orders created today
    };
    const orders = await FoodOrder.find(matchCriteria);
    if (orders.length === 0) {
      return res.status(404).json({ message: "No orders found for today" }); // Use 404 for not found
    }
    const totalAmount = orders.reduce((acc, order) => acc + order.total_amount, 0);
    res.status(200).json({
      message: "End of day report",
      data: {
        restaurant_id: restaurantid,
        date: today.toISOString(), // Include date in response
        totalAmount,
        // Other data you want to include from orders (e.g., order details)
      },
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
// const rushHours = async (req, res) => {
//   try {
//     const { restaurantId, day } = req.query;

//     if (!restaurantId || !day) {
//       return res.status(400).json({ error: 'Required parameters are missing' });
//     }

//     const selectedDay = day.toLowerCase();

//     // Validate if the provided day is valid
//     if (!['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'].includes(selectedDay)) {
//       return res.status(400).json({ error: 'Invalid day' });
//     }

//     const today = new Date();
//     const currentDay = today.getDay();
//     const dayIndex = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'].indexOf(selectedDay);
//     const dayDifference = dayIndex - currentDay;

//     // Calculate the target date (Wednesday in this case)
//     const targetDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() + dayDifference);

//     // Calculate the start and end of the selected day
//     const startOfDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), 0, 0, 0);
//     const endOfDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate(), 23, 59, 59);

//     // Array to store intervals with total ordered count
//     const intervals = [];

//     // Loop through each 2-hour interval of the day
//     let intervalStart = new Date(startOfDay);
//     while (intervalStart <= endOfDay) {
//       const intervalEnd = new Date(intervalStart.getTime() + 2 * 60 * 60 * 1000); // Add 2 hours

//       // Calculate total ordered count for the current interval
//       const totalOrderedCount = await FoodOrder.countDocuments({
//         restaurant_id: restaurantId,
//         created_at: { $gte: intervalStart, $lt: intervalEnd }
//       });

//       // Store the interval with total ordered count
//       intervals.push({
//         intervalStart: intervalStart.toISOString(),
//         intervalEnd: intervalEnd.toISOString(),
//         totalOrderedCount
//       });

//       // Move to the next interval
//       intervalStart = intervalEnd;
//     }

//     // Respond with the total ordered count for the specified day
//     res.json({
//       day: selectedDay.charAt(0).toUpperCase() + selectedDay.slice(1), // Capitalize the first letter of the day
//       intervals
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// };
// const totalorderchart = async (req, res) => {
//   const restaurantId = req.query.restaurantId;
//   const period = req.query.period;

//   try {
//     const now = new Date();
//     let start, end;

//     switch (period) {
//       case 'today':
//         start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
//         end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
//         break;
//       case 'week':
//         start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay(), 0, 0, 0);
//         end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay() + 6, 23, 59, 59);
//         break;
//       case 'month':
//         start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
//         end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
//         break;
//       default:
//         return res.status(400).json({ error: 'Invalid period' });
//     }

//     const intervals = [];
//     const totalOrders = [];

//     for (let i = start; i <= end; i.setHours(i.getHours() + 2)) {
//       const intervalStart = new Date(i);
//       const intervalEnd = new Date(intervalStart.getTime() + 2 * 60 * 60 * 1000);

//       const totalDelivered = await FoodOrder.countDocuments({
//         restaurant_id: restaurantId,
//         created_at: { $gte: intervalStart, $lt: intervalEnd },
//         status: 'delivered'
//       });

//       const totalPending = await FoodOrder.countDocuments({
//         restaurant_id: restaurantId,
//         created_at: { $gte: intervalStart, $lt: intervalEnd },
//         status: { $ne: 'delivered' }
//       });

//       intervals.push({
//         intervalStart: intervalStart,
//         intervalEnd: intervalEnd,
//         totalDelivered,
//         totalPending
//       });
//     }

//     res.status(200).json({
//       period,
//       intervals
//     });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: 'Internal server error' });
//   }
// };
const rushHours = async (req, res) => {
  try {
    const { restaurantId, day } = req.query;

    if (!restaurantId || !day) {
      return res.status(400).json({ error: 'Required parameters are missing' });
    }

    const selectedDay = day.toLowerCase();

    // Validate if the provided day is valid
    if (!['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'].includes(selectedDay)) {
      return res.status(400).json({ error: 'Invalid day' });
    }

    const today = new Date();
    const currentDay = today.getUTCDay(); // Get current UTC day
    const dayIndex = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'].indexOf(selectedDay);
    let dayDifference = dayIndex - currentDay;

    // Adjust day difference to get data for the previous day if the selected day is in the future
    if (dayDifference > 0) {
      dayDifference -= 7; // Subtract 7 days to get the previous day
    }

    // Calculate the target date in UTC
    const targetDate = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() + dayDifference));

    // Calculate the start and end of the selected day in UTC
    const startOfDay = new Date(Date.UTC(targetDate.getUTCFullYear(), targetDate.getUTCMonth(), targetDate.getUTCDate(), 0, 0, 0));
    const endOfDay = new Date(Date.UTC(targetDate.getUTCFullYear(), targetDate.getUTCMonth(), targetDate.getUTCDate(), 23, 59, 59));

    // Array to store intervals with total ordered count
    const intervals = [];

    // Loop through each 2-hour interval of the day
    let intervalStart = new Date(startOfDay);
    while (intervalStart <= endOfDay) {
      const intervalEnd = new Date(intervalStart.getTime() + 2 * 60 * 60 * 1000); // Add 2 hours

      // Calculate total ordered count for the current interval
      const totalOrderedCount = await FoodOrder.countDocuments({
        restaurant_id: restaurantId,
        created_at: { $gte: intervalStart, $lt: intervalEnd }
      });

      // Store the interval with total ordered count
      intervals.push({
        intervalStart: intervalStart.toISOString(),
        intervalEnd: intervalEnd.toISOString(),
        totalOrderedCount
      });

      // Move to the next interval
      intervalStart = intervalEnd;
    }

    // Respond with the total ordered count for the specified day
    res.json({
      day: selectedDay.charAt(0).toUpperCase() + selectedDay.slice(1), // Capitalize the first letter of the day
      intervals
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
//next api
const totalorderchart = async (req, res) => {
  const restaurantId = req.query.restaurantId;
  const period = req.query.period;

  try {
    const now = new Date(); // Get current time in local time zone
    console.log(now)
    let start, end;

    switch (period) {
      case 'today':
        start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0));
        end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 23, 59, 59));
        break;
      case 'week':
        start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - now.getUTCDay(), 0, 0, 0));
        end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - now.getUTCDay() + 6, 23, 59, 59));
        break;
      case 'month':
        start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0));
        end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 0, 23, 59, 59));
        break;
      default:
        return res.status(400).json({ error: 'Invalid period' });
    }

    const intervals = [];
    const totalOrders = [];

    for (let i = start; i <= end; i.setUTCHours(i.getUTCHours() + 2)) {
      const intervalStart = new Date(i);
      const intervalEnd = new Date(intervalStart.getTime() + 2 * 60 * 60 * 1000);

      const totalDelivered = await FoodOrder.countDocuments({
        restaurant_id: restaurantId,
        created_at: { $gte: intervalStart, $lt: intervalEnd },
        status: 'delivered'
      });

      const totalPending = await FoodOrder.countDocuments({
        restaurant_id: restaurantId,
        created_at: { $gte: intervalStart, $lt: intervalEnd },
        status: { $ne: 'delivered' }
      });

      intervals.push({
        intervalStart: intervalStart,
        intervalEnd: intervalEnd,
        totalDelivered,
        totalPending
      });
    }

    res.status(200).json({
      period,
      intervals
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = {
  createOrder,
  setWebSocketServer,
  updateOrderFromAdmin,
  getOrdersByUser,
  getAllorder,
  getOrderById,
  cancelOrderFromUser,
  cancelOrderByAdmin,
  getOrderByAdmin,
  overallReports,
  customersDetails,
  getCustomerInfo,
  totalSalesReport,
  salesReport,
  mostOrder,
  campaignPerReport,
  businessreview,
  customerReport,
  netSales,
  livenotificationforadmin,
  eodReport,
  rushHours,
  totalorderchart,
};
