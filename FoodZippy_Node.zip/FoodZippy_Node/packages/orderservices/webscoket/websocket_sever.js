const WebSocket = require('ws');
const http = require('http');

const server = http.createServer((req, res) => {
    // Handle HTTP requests if needed

    // Set CORS headers for HTTP requests
    res.setHeader('Access-Control-Allow-Origin', '*'); // Adjust the origin as needed
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('WebSocket server is running on a separate port.');
    // res.writeHead(200, { 'Content-Type': 'text/plain' });
    // res.end('WebSocket server is running on a separate port.');
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('WebSocket client connected');

    ws.on('message', (message) => {
        console.log(`Received: ${message}`);
    });

    ws.on('close', () => {
        console.log('WebSocket client disconnected');
    });
});
// function broadcastOrder(orderMessage) {
//     if (wss) {
//         wss.clients.forEach((client) => {
//             if (client.readyState === WebSocket.OPEN) {
//                 client.send(orderMessage);
//             }
//         });
//     }
// }
//const ipAddress = '192.168.1.42'; // Replace this with your desired IP address

const PORT = 3008;

server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
module.exports = wss;
