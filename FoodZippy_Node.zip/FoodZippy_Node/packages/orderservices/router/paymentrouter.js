const express = require("express");
const Router = express.Router();
const { createPaymentforuser, getPaymentInfo, createProductPlansSubscribeAndAttach, getAllPlans, getAllProductsAndPlans, createCustomerAndSubscription, } = require("../../orderservices/controller/paymentcontroller")
const {
    requireUserAuth,
} = require("../../../packages/userservices/middleware/vaildateUserToken");
Router.post('/create-payment', requireUserAuth, createPaymentforuser);
Router.get("/", getPaymentInfo);
Router.post('/admin', createProductPlansSubscribeAndAttach);
Router.get('/admin/plans', getAllPlans);
Router.post("/admin/cus", createCustomerAndSubscription);
Router.get("/products-plans", getAllProductsAndPlans);

module.exports = Router;