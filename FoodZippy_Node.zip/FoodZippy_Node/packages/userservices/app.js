const express = require("express");
const bodyParser = require("body-parser");
const superadmin = require("../userservices/router/superAdminrouter");
const userRouter = require("./router/userRouter");
const adminRouter = require("./router/adminrouter");
const restaurantRouter = require("../../packages/resturantservices/router/restaurantRouter");
const menuRouter = require("../../packages/resturantservices/router/menuRouter");
const Favorite = require("../resturantservices/router/favoriteRouter");
const orderrouter = require("../orderservices/router/orderrouter");
const addcartitem = require("../resturantservices/router/AddcartitemRouter");
const voucher = require("../resturantservices/router/voucherRouter");
const campaigns = require("../resturantservices/router/loyaltyRouter");
const deliveryPerson = require("../resturantservices/router/deliverypersonRouter");
const servicescharge = require("../resturantservices/router/serviceschargeRouter");
const manager = require("../resturantservices/router/managerRoute");
const deliveryZone = require("../resturantservices/router/deliveryzoneRouter");
const branchRestaurant = require("../resturantservices/router/branchRestaurantRouter");
const payment = require("../orderservices/router/paymentrouter")
const deliveryRoute = require("../userservices/router/deliveryBoyrouter")
const db = require("../common/connection");
const dotenv = require("dotenv");
const path = require('path');
const cors = require("cors");
// Load environment variables from .env file
dotenv.config();
require("../orderservices/webscoket/websocket_sever");
const app = express();
const PORT = process.env.PORT;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => {
  console.log("Connected to MongoDB");
});
// Middlewares
app.use(bodyParser.json());
app.use(express.json());
app.options("*", cors());
app.use(cors());
//app.use(express.static(__dirname, 'public'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, PATCH"
  );
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Credentials", true);
  res.setHeader("Content-Type", "application/json");
  next();
});
// Routes
app.use("/api/v1/superadmin", superadmin);
app.use("/api/v1/user", userRouter); // Assuming you want the user routes under /api
app.use("/api/v1/admin", adminRouter);
app.use("/api/v1/restaurant", restaurantRouter);
app.use("/api/v1/menu", menuRouter);
app.use("/api/v1/order", orderrouter);
app.use("/api/v1/favorite", Favorite);
app.use("/api/v1/addcartitem", addcartitem);
app.use("/api/v1/voucher", voucher);
app.use("/api/v1/campaigns", campaigns);
app.use("/api/v1/delivery", deliveryPerson);
app.use("/api/v1/service-charge", servicescharge);
app.use("/api/v1/manager", manager);
app.use("/api/v1/deliveryzone", deliveryZone);
app.use("/api/v1/branchrestaurant", branchRestaurant);
app.use("/api/v1/payment", payment);
app.use("/api/v1/deliveryperson", deliveryRoute)
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
