const Joi = require("joi");
const Admin = require("../../common/model/adminSchema");
const Restaurant = require("../../common/model/restaurantSchema");
const superAdmin = require("../../common/model/superAdminSchema");
const Manager = require("../../common/model/managerSchema")
const otpGenerator = require("otp-generator");
const bcrypt = require("bcrypt");
const {
  generateToken,
  addTokenToBlacklist,
  verifyToken,
} = require("../middleware/authMiddleware");
const mailService = require("../helper/mail_serverices");
const apiResponse = require("../middleware/apiResponse");
const fs = require('fs');
const path = require('path');
// Joi schema for admin data validation
const adminSchema = Joi.object({
  email: Joi.string().email(),
  password: Joi.string()
    .pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z\d]).{8,}$/)
    .message(
      "Password must contain at least 8 characters, including one lowercase letter, one uppercase letter, one digit, and one special character."
    ),
  firstname: Joi.string(),
  lastname: Joi.string(),
  gender: Joi.string(),
  mobile: Joi.string().min(10).max(11),
  country: Joi.string(),
  ipaddress: Joi.string(),
  is_active: Joi.boolean(),
  otp: Joi.string().length(6),
  otp_time_out: Joi.boolean(),
  superadminId: Joi.string(),
});
const createAdmin = async (req, res) => {
  let admin; // Declare admin variable outside the try block for rollback

  try {
    const { email } = req.body;

    // Check if the admin already exists
    const existingAdmin = await Admin.findOne({ email, is_active: true });
    if (existingAdmin) {
      return res.status(400).json({ message: "Admin already exists with this email." });
    }

    const otp = Math.floor(100000 + Math.random() * 900000);
    admin = new Admin({ email, otp });
    await admin.save();

    // Sending email to the admin using the common mail service
    const subject = "Welcome to the Admin Panel";
    const text = `Hello,\n\nCongratulations! Your admin account has been created.
        \n\nEmail: ${email}\nOTP: ${otp}\n\nYou can now log in to the admin panel using the provided OTP within the next 10 minutes.
        \n\nBest regards,\nThe Admin Team`;
    const emailSent = await mailService.sendEmail(email, subject, text);

    if (emailSent) {
      const token = generateToken(admin, "admin");
      const ipaddress =
        req.headers["x-forwarded-for"] || req.connection.remoteAddress;
      console.log(ipaddress);
      return apiResponse.saveApiResponseWithData(
        res,
        "Admin created. OTP sent to email.",
        { token }
      );
    } else {
      // If there's an error sending the email, rollback the creation of the admin
      await Admin.deleteOne({ _id: admin._id }); // Use deleteOne method to delete the document
      return apiResponse.serverErrorResponse(
        res,
        "Unable to send OTP email. Admin creation failed."
      );
    }
  } catch (error) {
    console.log("Error creating admin:", error);

    // Rollback the creation of the admin if an error occurs
    if (admin) {
      await Admin.deleteOne({ _id: admin._id }); // Use deleteOne method to delete the document
    }

    return apiResponse.serverErrorResponse(res, "Unable to create admin.");
  }
};

const verifyOTP = async (req, res) => {
  const { otp } = req.body;
  try {
    // Extract admin's ID and email from the token payload
    const { id, email } = req.user;

    // Find the admin by ID, email, and ensure OTP has not been used
    const admin = await Admin.findOne({ _id: id, email, otp_time_out: false });
    if (!admin) {
      //return res.status(404).json({ error: 'Admin not found or OTP already used.' });
      return apiResponse.dataFoundResponse(
        res,
        "Admin not found or OTP already used."
      );
    }

    // Check if OTP matches and has not expired
    console.log("Stored OTP:", admin.otp); // Add this log to see the stored OTP
    console.log("Received OTP:", otp); // Add this log to see the received OTP
    console.log("Current Time:", Date.now()); // Add this log to see the current time
    if (admin.otp === otp) {
      admin.otp_time_out = true;
      await admin.save();
      // res.status(200).json({ message: 'OTP verification successful. You are now logged in.' });
      return apiResponse.saveApiResponseWithNoData(
        res,
        "OTP verification successful. You are now logged in."
      );
    } else if (admin.otpExpiration <= Date.now()) {
      const newOTP = Math.floor(100000 + Math.random() * 900000);
      admin.otp = newOTP;
      admin.otpExpiration = Date.now() + 10 * 60 * 1000; // 10 minutes
      await admin.save();
      return apiResponse.validationError(
        res,
        "OTP has expired. A new OTP has been sent to your email."
      );
    } else {
      return apiResponse.validationError(res, "Invalid OTP.");
    }
  } catch (error) {
    console.log("Error verifying OTP:", error);
    return apiResponse.serverErrorResponse(res, "Unable to verify OTP.");
  }
};
const createPassword = async (req, res) => {
  try {
    const { id, email } = req.user; // Extracted from token payload
    const { password } = req.body;

    // Validate password using Joi
    const { error: passwordValidationError } = adminSchema.validate(req.body);

    if (passwordValidationError) {
      return apiResponse.validationError(res, passwordValidationError.message);
    }
    console.log(password, "password");
    // Generate a salt using bcrypt.genSalt
    bcrypt.genSalt(10, async (err, salt) => {
      if (err) {
        return apiResponse.serverErrorResponse(res, "Error generating salt.");
      }

      try {
        // Hash the password using the generated salt
        const hashedPassword = await bcrypt.hash(password, salt);
        console.log(hashedPassword, "wertyuio");

        // Update the admin's record with the new hashed password
        const admin = await Admin.findOneAndUpdate(
          { _id: id, email },
          { password: hashedPassword, is_active: true },
          { new: true }
        );

        if (!admin) {
          return apiResponse.dataNotFoundResponse(res, "Admin not found.");
        }
        return apiResponse.getApiResponse(
          res,
          "Password created and updated successfully."
        );
        // Respond with a success message
      } catch (error) {
        return apiResponse.serverErrorResponse(res, "Error updating password.");
      }
    });
  } catch (error) {
    return apiResponse.serverErrorResponse(res, "Unable to create password.");
  }
};
const updateAdmin = async (req, res) => {
  try {
    const { user } = req;
    // Validate the request body using adminSchema
    const { error } = adminSchema.validate(req.body);
    if (error) {
      return apiResponse.validationError(res, error.details[0].message);
    }
    // Find the existing admin by ID
    const existingAdmin = await Admin.findById(user);
    if (!existingAdmin) {
      return apiResponse.dataNotFoundResponse(res, "Admin not found.");
    }
    // Update the admin's data
    existingAdmin.set(req.body);
    await existingAdmin.save();
    return apiResponse.updateApiResponseWithData(
      res,
      "Admin update successful."
    );
  } catch (error) {
    return apiResponse.serverErrorResponse(res, "Unable to update admin.");
  }
};
const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const { error } = adminSchema.validate(req.body);
    if (error) {
      const validationErrorsArray = error.details.map(
        (detail) => detail.message
      );
      console.log(validationErrorsArray); // Log validation errors
      return apiResponse.validationError(res, validationErrorsArray);
    }

    // Check if the email is not registered
    const admin = await Admin.findOne({ email, is_active: true });
    if (!admin) {
      // return apiResponse.dataFoundResponse(res, 'Email is not registger')
      return res.status(401).json({ message: "Email is not registger" });
    }
    console.log(admin, "happy");
    const passwordMatch = bcrypt.compareSync(password, admin.password);
    console.log("Password Match:", passwordMatch);

    if (!passwordMatch) {
      console.log("Invalid Password!");
      return apiResponse.validationError(res, "Invalid credentials.");
    }
    const token = generateToken(admin, "admin");
    return apiResponse.getApiResponse(res, "Admin logged in successfully.", {
      token,
    });
  } catch (error) {
    return apiResponse.serverErrorResponse(
      res,
      "Unable to perform admin login."
    );
  }
};
const logout = async (req, res) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res.status(400).json({ error: "No token provided." });
    }

    // Fetch admin before logging out
    const decodedToken = verifyToken(token); // Assuming you have a function named verifyToken
    if (decodedToken) {
      const adminId = decodedToken.id;
      const admin = await Admin.findById(adminId);

      if (!admin) {
        return res.status(404).json({ error: "Admin not found." });
      }
      // Add the token to the blacklist
      addTokenToBlacklist(token);
      return res
        .status(200)
        .json({ message: "Admin logged out successfully." });
    } else {
      return res
        .status(401)
        .json({ error: "Invalid token or token has expired." });
    }
  } catch (error) {
    console.error("Error logging out:", error);
    return res.status(500).json({ error: "Unable to fetch admin or logout." });
  }
};
// Get all admins
const getAllAdmins = async (req, res) => {
  try {
    const admins = await Admin.find();
    res.status(200).json(admins);
  } catch (error) {
    res.status(500).json({ error: "Unable to fetch admins." });
  }
};

const getAdminById = async (req, res) => {
  try {
    const adminIdFromToken = req.user.id; // Extracted from token payload
    const requestedAdminId = req.params.id;

    // Verify that the requested admin ID matches the admin ID from the token
    if (adminIdFromToken !== requestedAdminId) {
      return apiResponse.validationError(
        res,
        "Forbidden: You can only view your own profile."
      );
    }

    const admin = await Admin.findById(requestedAdminId);
    if (!admin) {
      return apiResponse.dataNotFoundResponse(res, "Admin not found.");
    }
    return apiResponse.getApiResponse(res, "Admin data", admin);
  } catch (error) {
    return apiResponse.serverErrorResponse(res, "Unable to fetch admin.");
  }
};

const requestPasswordReset = async (req, res) => {
  try {
    const { email } = req.body;
    const admin = await Admin.findOne({ email, is_active: true });

    if (!admin) {
      return res.status(404).json({ error: "Admin not found." });
    }
    // Generate a reset token and save it to the admin's record in the database
    const resetToken = generateToken(admin, "admin");
    const encodedToken = Buffer.from(resetToken).toString("base64");
    admin.resetToken = encodedToken;
    //admin.resetToken = resetToken; // Update the admin's resetToken field
    const decodedToken = Buffer.from(encodedToken, 'base64').toString('utf-8');
    console.log(decodedToken, "decodeToken");
    const savedAdmin = await admin.save();
    // Sending email to the admin using the common mail service
    const subject = "Password Reset Request";
    const link = `https://food-zippy.web.app/reset-password?user=${encodedToken}`;
    const text = `Hello ${admin.email},\n\nYou've requested to reset your password. Please use the following link to reset your password: ${link}`;
    const emailSent = await mailService.sendEmail(email, subject, text);
    // const emailBody = htmlContent.replace('{{resetLink}}', link);
    res
      .status(200)
      .json({
        email: savedAdmin.email,
        message: "Password reset email sent successfully.",
      });
  } catch (error) {
    res.status(500).json({ error: "Failed to request password reset." });
  }
};
const resetPassword = async (req, res) => {
  try {
    // Validate the request body using the adminSchema
    const adminIdFromToken = req.user.id;
    const { error } = adminSchema.validate(req.body);
    if (error) return res.status(400).send(error.details[0].message);

    // Find the admin by the decoded token (attached by the middleware)
    const admin = await Admin.findById(adminIdFromToken);
    if (!admin) {
      return res.status(400).json({ message: "Admin not found" });
    }

    // Generate a new password hash and update the admin's password
    const newPasswordHash = await bcrypt.hash(req.body.password, 10);
    admin.password = newPasswordHash;

    // Save the updated admin
    await admin.save();

    // Add the used token to a blacklist (optional but recommended)
    addTokenToBlacklist(adminIdFromToken);

    return res.status(200).json({ message: "Password reset successfully." });
  } catch (error) {
    console.log(error);
    res.status(500).send("An error occurred");
  }
};

// // Delete an admin by ID
const deleteAdmin = async (req, res) => {
  try {
    const adminId = req.params.id;

    const updatedAdmin = await Admin.findByIdAndUpdate(
      adminId,
      { is_active: false }, // Set is_active to false
      { new: true } // Return the updated document
    );

    if (!updatedAdmin) {
      return res.status(404).json({ message: "Admin not found." });
    }

    res.status(200).json({ message: "Admin soft deleted successfully." });
  } catch (error) {
    res.status(500).json({ error: "Unable to soft delete admin." });
  }
};
const auditlogs = async (req, res) => {
  try {
    const restaurantId = req.params.restaurant_id;
    // Fetch data from Restaurant model
    const restaurant = await Restaurant.findOne({ _id: restaurantId }).select("admin_id created_at");

    if (!restaurant) {
      return res.status(404).json({ error: 'Restaurant not found' });
    }
    const adminId = restaurant.admin_id;
    // Fetch data from Admin model
    const admin = await Admin.findOne({ _id: adminId }).select("created_at firstname");

    if (!admin) {
      return res.status(404).json({ error: 'Admin not found' });
    }
    // Fetch data from Manager model if it exists
    const manager = await Manager.findOne({ admin_id: adminId }).select('created_at firstname');
    res.status(200).json({
      restaurant,
      admin,
      manager: manager || null, // Include manager if found, otherwise null
    });
  } catch (error) {
    console.error('Error retrieving activity logs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
const changePassword = async (req, res) => {
  try {
    const adminId = req.user;
    console.log(adminId, "ijaduh");
    const { oldPassword, newPassword } = req.body;
    // Find SuperAdmin by email
    const admin = await Admin.findOne({ _id: adminId });
    if (!admin) {
      return res.status(404).json({ message: "Admin not found" });
    }
    console.log(admin, "superadmin")
    // Check if old password matches
    const passwordMatch = await bcrypt.compare(oldPassword, admin.password);
    console.log(passwordMatch, "sxxrdhvbygdcsb ygushbs");
    if (!passwordMatch) {
      return apiResponse.validationError(res, "Old password does not match");
    }

    // Hash new password
    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    admin.password = hashedNewPassword;
    await admin.save();

    return apiResponse.saveApiResponseWithData(res, "Password changed successfully");
  } catch (error) {
    console.error("Error changing password:", error);
    return apiResponse.serverErrorResponse(
      res,
      "Unable to change password"
    );
  }
}
module.exports = {
  createAdmin,
  updateAdmin,
  getAdminById,
  getAllAdmins,
  deleteAdmin,
  login,
  logout,
  verifyOTP,
  requestPasswordReset,
  resetPassword,
  createPassword,
  auditlogs,
  changePassword,
};
