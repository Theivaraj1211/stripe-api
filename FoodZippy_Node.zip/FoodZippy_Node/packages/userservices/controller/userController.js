const Joi = require("joi");
const twilio = require("twilio");
const User = require("../../common/model/userSchema");
const Address = require("../../common/model/addressSchema");
const AddressHistory = require("../../common/model/addressHistroy");
const { generateToken } = require("../middleware/authMiddleware");
const apiResponse = require("../middleware/apiResponse");
const dotenv = require("dotenv");
const fs = require("fs");
const path = require("path");
const { log, Console, error } = require("console");
const { AWS, s3Client } = require("../helper/awss3"); // Import the AWS configuration module
const crypto = require("crypto");
const logger = require("../helper/logger");
const { add } = require("winston");
const addressHistroy = require("../../common/model/addressHistroy");
function computeHash(data) {
  const hash = crypto.createHash("sha256");
  hash.update(data);
  return hash.digest("hex");
}

// Now, you can use AWS as configured in aws-config.js
// Load environment variables from .env file
dotenv.config();

// Joi validation schema for user creation and update
const userSchema = Joi.object({
  firstName: Joi.string(),
  lastName: Joi.string(),
  otp: Joi.number().integer().positive().min(100000).max(999999), // OTP should be a 6-digit number
  image: Joi.object({
    data: Joi.binary(), // Validate that 'data' is a binary (Buffer) and is required
    contentType: Joi.string(),
  }),
  imageURL: Joi.string(),
  email: Joi.string().email(),
  is_active: Joi.boolean(),
  mobile: Joi.object({
    countryCode: Joi.string(),
    phoneNumber: Joi.string().min(10).max(11),
  }).optional(),
  ipaddress: Joi.string(),
});
const addressJoiSchema = Joi.object({
  user: Joi.string(), // You can adjust the validation as needed
  type: Joi.string().valid("home", "work", "hotel", "other"),
  address: Joi.string(),
  zipcode: Joi.string().min(3).max(8).regex(/^[a-zA-Z0-9\s]+$/),
  buildingNumber: Joi.string(),
  floorNumber: Joi.string(),
  houseNumber: Joi.string(),
  is_default: Joi.boolean(),
  is_active: Joi.boolean(),
  city: Joi.string(),
  state: Joi.string(),
  location: Joi.object({
    lat: Joi.number(),
    long: Joi.number(),
  }),
  others: Joi.object({
    friends: Joi.array().items(Joi.string()),
    family: Joi.array().items(Joi.string()),
  }),
});
// Replace with your Twilio Account SID and Auth Token
const accountSid = process.env.TWILLO_ACCOUNT_SID;
const authToken = process.env.TWILLO_AUTH;
//const twilioPhoneNumber = process.env.TWILLO_PHONE_NUMBER;
const client = require("twilio")(accountSid, authToken);
const getUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
    console.log("successfully");
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
// const getUserById = async (req, res) => {
//   try {
//     const userId = req.user;
//     console.log(userId, "kjahdfhu");

//     // Fetch the user document
//     const user = await User.findById(userId);
//     console.log(user, "User document without populated addresses");

//     if (!user) {
//       return res.status(404).json({ error: 'User not found' });
//     }

//     console.log("hiii");
//     const addresses = user.addresses; // This should be an array of address IDs
//     console.log("hai 2", addresses);

//     if (!addresses || !addresses.length) {
//       return res.status(404).json({ error: 'Addresses not found for this user' });
//     }

//     // Fetch the address documents for each address ID
//     const addressPromises = addresses.map(async (addressId) => {
//       try {
//         const address = await Address.findById(addressId);
//         console.log(addressId, "Address data");
//         return address;
//       } catch (error) {
//         console.error(`Error fetching address ${addressId}: ${error}`);
//         return null; // You can handle the error or return a placeholder value here
//       }
//     });

//     // Resolve all the address promises
//     const resolvedAddresses = await Promise.all(addressPromises);

//     res.status(200).json({ user, addresses: resolvedAddresses });
//   } catch (err) {
//     console.error("Error:", err);
//     res.status(500).json({ error: err.message });
//   }
// };
const getUserById = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming userId is passed in the request parameters
    console.log(userId, "kjahdfhu");

    // Fetch the user document by userId
    const user = await User.findById(userId); // Assuming 'addresses' is a field in the User model that references the Address model
    console.log(user, "User document with populated addresses");
    const address = await Address.find({ user: userId, is_active: true });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const addresses = user.addresses;

    if (!addresses || !addresses.length) {
      return res
        .status(404)
        .json({ error: "Addresses not found for this user" });
    }

    res.status(200).json({ user, address }); // Returning addresses associated with the user
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: err.message });
  }
};

const getUserByIdimage = async (req, res) => {
  try {
    const userId = req.user;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    const imagePath = path.join(__dirname, "uploads", `${userId}`);

    // Check if the file exists
    if (fs.existsSync(imagePath)) {
      // Set appropriate response headers
      res.setHeader("Content-Type", "image/jpeg"); // Adjust the content type based on your image format

      // Send the image file
      res.sendFile(imagePath, (err) => {
        if (err) {
          logger.error("Failed to send the image:", err.message);
          res.status(500).json({ error: "Failed to send the image" });
        } else {
          logger.info("Image sent successfully");
        }
      });
    } else {
      logger.error("Image not found");
      res.status(404).json({ error: "Image not found" });
    }
  } catch (err) {
    logger.error(err.message);
    res.status(500).json({ error: err.message });
  }
};

const updateUserById = async (req, res) => {
  try {
    const { id, mobile } = req.user; // Extracted from token payload
    const updateData = req.body;
    const { error: userValidationError } = userSchema.validate(updateData, {
      allowUnknown: true,
    });

    // Validate the request body using addressUpdateJoiSchema for address updates
    const { error: addressValidationError } = addressJoiSchema.validate(
      updateData,
      { allowUnknown: true }
    );

    if (userValidationError && addressValidationError) {
      return apiResponse.validationError(
        res,
        "Invalid user and address update data"
      );
    }

    // Fetch the user from the database
    const existingUser = await User.findOne({
      _id: id,
      "mobile.countryCode": mobile.countryCode,
      "mobile.phoneNumber": mobile.phoneNumber,
    }).populate("addresses");

    if (!existingUser) {
      return apiResponse.dataNotFoundResponse(res, "User not found");
    }

    // Ensure the user can only update their own data by matching id and phone_number
    if (
      existingUser.id !== id ||
      existingUser.mobile.phoneNumber !== mobile.phoneNumber
    ) {
      return apiResponse.dataNotFoundResponse(
        res,
        "Forbidden: You can only update your own data."
      );
    }

    // Update user fields if provided
    const fieldsToUpdate = [
      "firstName",
      "lastName",
      "email",
      "otp",
      "is_active",
      "mobile",
      "ipaddress",
      "image",
    ];
    if (updateData.mobile) {
      if (updateData.mobile.phoneNumber !== existingUser.mobile.phoneNumber) {
        // Update mobile and generate new OTP
        existingUser.mobile = updateData.mobile;
        existingUser.otp = 444323;
      }
      delete updateData.mobile;
    }
    if (req.file) {
      updateData.image = {
        data: req.file.buffer,
        contentType: req.file.string,
      };
    }
    fieldsToUpdate.forEach((field) => {
      if (updateData[field] !== undefined) {
        existingUser[field] = updateData[field];
      }
    });
    if (updateData.addresses) {
      if (!Array.isArray(updateData.addresses)) {
        return res
          .status(400)
          .json({ error: "Addresses must be an array of objects" });
      }
      // Create an array to hold the new Address documents
      const newAddresses = [];

      // Iterate through the addresses array
      for (const addressData of updateData.addresses) {
        // Validate the address data using the Joi schema
        const { error: addressValidationError } =
          addressJoiSchema.validate(addressData);
        if (addressValidationError) {
          console.log("error", addressValidationError);
          return res.status(400).json({ error: "Invalid address data" });
        }

        // Create a new instance of the Address model
        const newAddress = new Address({
          user: existingUser._id, // Assign the address to the user
          type: addressData.type,
          address: addressData.address,
          zipcode: addressData.zipcode,
          buildingNumber: addressData.buildingNumber,
          floorNumber: addressData.floorNumber,
          houseNumber: addressData.houseNumber,
          is_default: addressData.is_default || false,
          city: addressData.city,
          state: addressData.state,
          location: addressData.location,
          others: addressData.others,
        });

        // Save the address to the database and push it to the newAddresses array
        const savedAddress = await newAddress.save();
        newAddresses.push(savedAddress);
        // Create an instance of AddressHistory and save it
        const addressHistory = new AddressHistory({
          user: existingUser._id,
          address: savedAddress._id,
          timestamp: new Date(),
        });
        await addressHistory.save();
      }

      // Assign the newAddresses array to existingUser.addresses
      existingUser.addresses = newAddresses;
    }

    // Save the updated user
    const updatedUser = await existingUser.save();
    return apiResponse.updateApiResponseWithData(res, "Update successful", {
      updatedUser,
    });
  } catch (err) {
    return apiResponse.serverErrorResponse(res, err.message);
  }
};
const createUser = async (req, res) => {
  try {
    // Validate the request body
    const { error } = userSchema.validate(req.body);
    if (error) {
      return apiResponse.validationError(res, error.details[0].message);
    }
    const { mobile } = new User(req.body);
    const ipaddress =
      req.headers["x-forwarded-for"] || req.connection.remoteAddress;
    const existingUser = await User.findOne({
      "mobile.phoneNumber": mobile.phoneNumber,
      is_active: true,
    });
    if (existingUser) {
      await existingUser.save();
      const token = generateToken(existingUser, "user");
      return apiResponse.saveApiResponseWithData(res, "User already exists", {
        token,
      });
    }
    const otp = 444323;
    const user = new User({ ...req.body, ipaddress: ipaddress });
    user.otp = otp;
    const savedUser = await user.save();
    try {
      const token = generateToken(user, "user");
      return apiResponse.saveApiResponseWithData(
        res,
        "user create successfully",
        { token }
      );
    } catch (err) {
      return apiResponse.dataNotFoundResponse(
        res,
        "Failed to send OTP. Please try again later."
      );
    }
  } catch (err) {
    return apiResponse.serverErrorResponse(res, err.message);
  }
};
const verifyOTP = async (req, res) => {
  try {
    const { mobile, id } = req.user; // Extracted from token payload
    const { otp } = req.body;
    const user = await User.findOne({
      _id: id,
      "mobile.countryCode": mobile.countryCode,
      "mobile.phoneNumber": mobile.phoneNumber,
    });
    console.log(user, "sdfghjkl");
    if (!user) {
      console.log(user, "vghjk");
      return res.status(204).json({ message: "User not found" });
    }

    if (
      user.mobile.countryCode !== mobile.countryCode ||
      user.mobile.phoneNumber !== mobile.phoneNumber
    ) {
      // return apiResponse.unauthorizedResponse(res, 'Unauthorized. Phone number mismatch.');
      console.log(user, "werfgyji");
      return res
        .status(401)
        .json({ message: "Unauthorized. Phone number mismatch." });
    }
    if (user.otp !== otp) {
      //  return apiResponse.dataNotFoundResponse(res, 'Invalid OTP')
      console.log("uzserf", user);
      return res.status(400).json({ message: "Invalid OTP" });
    }
    // Clear the OTP once it's verified
    user.is_active = true;
    user.otp = undefined;
    await user.save();
    // Here you can implement the logic for creating a token for the user and returning it for further authentication.
    return apiResponse.saveApiResponseWithNoData(
      res,
      "OTP verified successfully"
    );
  } catch (err) {
    return apiResponse.serverErrorResponse(res, err.message);
  }
};
const deleteUserById = async (req, res) => {
  try {
    const userId = req.params.id;

    const deletedUser = await User.findByIdAndDelete(userId);

    if (!deletedUser) {
      return res.status(404).json({ error: "User not found" });
    }

    res.status(200).json({ message: "User deleted successfully" });
    console.log("successfully deleted");
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
// const sendOTP = async (mobile) => {
//   const otp = generateOTP();
//   await client.messages.create({
//     body: `Your OTP is: ${otp}`,
//     from: twilioPhoneNumber,
//     to:`+${mobile.countryCode}${mobile.phoneNumber}`,
//   });
//   return otp.toString();
// };
// const login = async (req, res) => {
//   try {
//     const { mobile } = req.body;
//     const { error } = userSchema.validate(req.body);
//     if (error) {
//       return apiResponse.validationError(res, error.details[0].message);
//     }
//     const user = await User.findOne({ mobile });
//     if (!user) {
//       return apiResponse.dataNotFoundResponse(res, 'User not found');
//     }
//     const newotp = 444324;
//     const users = new User({ ...req.body, otp: newotp });
//     try {
//       // Send the new OTP to the user's phone number
//       await client.messages.create({
//         body: `Your new OTP is: ${newotp}`,
//         from: +18643343136,
//         to: `+${mobile.countryCode}${mobile.phoneNumber}`,
//       });
//       //const otp = await sendOTP(phone_number);
//       users.otp = newotp;
//       await users.save()
//       const token = generateToken(user, 'user');
//       return apiResponse.saveApiResponseWithNoData(res, 'OTP sent successfully', { token });
//     } catch (twilioError) {
//       console.error('Twilio error:', twilioError);
//       if (twilioError.code === 21211) {
//         return apiResponse.dataNotFoundResponse(res, 'Invalid phone number. Please provide a valid phone number.');
//       }
//       if (twilioError.status === 401) {
//         return apiResponse.dataNotFoundResponse(res, 'Invalid phone number. Please provide a valid phone number.');
//       }
//       return apiResponse.dataNotFoundResponse(res, 'Failed to send OTP. Please try again later.');
//     }
//   } catch (err) {
//     return apiResponse.serverErrorResponse(res, err.message);
//   }
// };
const login = async (req, res) => {
  try {
    const { mobile } = new User(req.body);
    const { error } = userSchema.validate(req.body);
    if (error) {
      logger.error('Validation error:', error.details[0].message);
      return apiResponse.validationError(res, error.details[0].message);
    }
    const user = await User.findOne({
      "mobile.countryCode": mobile.countryCode,
      "mobile.phoneNumber": mobile.phoneNumber,
    });
    if (!user) {
      logger.info("user not found");
      return res.status(204).json({ message: "User not found" });
    }
    if (!user.is_active) {
      logger.info("user not active");
      return res.status(203).json({ message: "User not active " });
    }
    //const newOtp = Math.floor(100000 + Math.random() * 900000); // Generate a new 6-digit OTP
    const newOtp = 444323;
    try {
      user.otp = newOtp;
      await user.save();
      const token = generateToken(user, "user");
      logger.info("Token generated successfully:", token);
      return apiResponse.saveApiResponseWithData(res, "OTP sent successfully", {
        token,
      });
    } catch (err) {
      return apiResponse.dataFoundResponse(
        res,
        "Failed to send OTP. Please try again later."
      );
    }
  } catch (err) {
    logger.error("Unexpected error:", err.message);
    return apiResponse.serverErrorResponse(res, err.message);
  }
};

const resendOTP = async (req, res) => {
  try {
    const { mobile } = req.body;
    // Find the user based on the provided phone number
    const user = await User.findOne({ mobile });
    if (!user) {
      //return res.status(404).json({ error: 'User not found' });
      return apiResponse.validationError(res, "User not found");
    }
    const otp = 444323;
    user.otp = otp;
    await user.save();
    try {
      return apiResponse.updateApiResponseWithData(
        res,
        "New OTP sent successfully"
      );
    } catch (err) {
      return apiResponse.dataNotFoundResponse(
        res,
        "Failed to send OTP. Please try again later."
      );
    }
  } catch (err) {
    return apiResponse.serverErrorResponse(res, err.message);
  }
};
const updateUserWithImage = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No image file provided" });
    }
    const userId = req.user.id;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    user.image = {
      data: req.file.buffer, // This line gets the image upload buffer data
      contentType: req.file.mimetype, // Corrected to req.file.mimetype
    };
    const imageFileName = `${req.file.originalname}`;
    // const imageFileName = `${req.file.originalname}_${Date.now()}`;
    const imagePath = `/uploads/${imageFileName}`; // Relative path to the image
    user.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;
    // user.image.data = req.file.Buffer,
    //   user.image.contentType = req.file.mimetype,cd
    await user.save();

    return res.status(200).json({ message: "Image upload successful", user });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
};
// const updateUserWithImage = async (req, res) => {
//   try {
//     if (!req.file) {
//       return res.status(400).json({ message: 'No image file provided' });
//     }
//     const userId = req.user.id;
//     const user = await User.findById(userId);
//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }
//     const s3 = new AWS.S3();
//     const params = {
//       Bucket: 'taramsys.dev',
//       Key: `image/${userId}/${req.file.originalname}`, // Define the S3 key based on your desired structure
//       Body: req.file.buffer, // Set the Body property here
//       ContentType: req.file.mimetype,
//     };
//     await s3.putObject(params).promise();
//     //await s3.upload(params).promise();

//     user.image = {
//       url: `https://s3.console.aws.amazon.com/s3/buckets/taramsys.dev?region=eu-west-2/${userId}/${req.file.originalname}`, // Replace with your S3 bucket URL
//     };

//     await user.save();

//     return res.status(200).json({ message: 'Image upload successful', user });
//   } catch (err) {
//     console.error(err);
//     return res.status(500).json({ message: 'Server error' });
//   }
// };
// const updateUserWithImage = async (req, res) => {
//   try {
//     if (!req.file) {
//       return res.status(400).json({ message: 'No image file provided' });
//     }

//     const userId = req.user.id;
//     const user = await User.findById(userId);

//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     // Compute the hash of the uploaded image data
//     const uploadedImageHash = computeHash(req.file.buffer);

//     // Check if the user already has an image
//     if (user.image) {
//       // Compute the hash of the existing image data
//       const existingImageHash = computeHash(user.image.data);

//       // If the hashes match, it's a duplicate image, so don't save it again
//       if (uploadedImageHash === existingImageHash) {
//         return res.status(200).json({ message: 'Duplicate image detected', user });
//       }
//     }

//     // Save the new image data
//     user.image = {
//       data: req.file.buffer,
//       contentType: req.file.mimetype,
//     };

//     await user.save();

//     return res.status(200).json({ message: 'Image upload successful', user });
//   } catch (err) {
//     console.error(err);
//     return res.status(500).json({ message: 'Server error' });
//   }
// };
const updateAddressByUserId = async (req, res) => {
  try {
    const addressId = req.params.addressId; // Ensure the correct parameter name is used
    const userId = req.user.id;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if the address belongs to the user
    const address = await Address.findOne({ _id: addressId, user: userId });
    if (!address) {
      return res
        .status(404)
        .json({ message: "Address not found for the user" });
    }

    // Perform the address update based on the request body data
    const updatedAddress = await Address.findByIdAndUpdate(
      addressId,
      { ...req.body, updated_at: new Date() },
      { new: true }
    );

    res.json({
      message: "Address updated successfully",
      address: updatedAddress,
    });
  } catch (error) {
    logger.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = {
  createUser,
  getUsers,
  getUserById,
  updateUserById,
  login,
  verifyOTP,
  createUser,
  deleteUserById,
  resendOTP,
  updateUserWithImage,
  getUserByIdimage,
  updateAddressByUserId,
};
