const Joi = require("joi");
const delivery = require("../../common/model/deliverypersonSchema");
const foodOrder = require("../../common/model/orderSchema");
const address = require("../../common/model/addressSchema");
const user = require("../../common/model/userSchema");
const cart = require("../../common/model/addcartitemSchema");
const {
    generateToken,
} = require("../../userservices/middleware/authMiddleware");
const deliveryBoySchema = Joi.object({
    name: Joi.string(),
    contact: Joi.object({
        mobileNumber: Joi.number().min(999999999).max(99999999999),
        countryCode: Joi.number().max(99),
    }),
    profileimage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    profileimageURL: Joi.string(),
    IdProofimage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    IdProofimageURL: Joi.string(),
    licenseiemage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    licenseimageURL: Joi.string(),
    is_active: Joi.boolean().default(false),
    otp: Joi.number().min(100000).max(999999),
    restaurant_id: Joi.string(),
    admin_id: Joi.string(),
    location: Joi.object({
        lat: Joi.number(),
        long: Joi.number(),
    }),
    address: Joi.string(),
    city: Joi.string(),
    state: Joi.string(),
    pinCode: Joi.number(),
    createdBy: Joi.string().valid("admin", "manager").default("admin"),
    updatedBy: Joi.string().valid("admin", "manager").default("admin"),
    createdat: Joi.date(),
    updatedat: Joi.date(),
    bikeNumber: Joi.string(),
    usertype: Joi.string().valid("delivery").default("delivery"),
    is_deliveryStatus: Joi.boolean().default(true),
    governmentIssuedPhotoIdCard: Joi.string(),
    is_available: Joi.boolean().default(true),
    email: Joi.string(),
});

const loginDeliveryBoy = async (req, res) => {
    try {
        const { contact } = req.body;
        const { error } = deliveryBoySchema.validate(req.body);
        if (error) {
            return res
                .status(400)
                .json({ message: "validation error", error: error.details[0].message });
        }
        const checkDeliveryBoy = await delivery.findOne({ contact });
        if (!checkDeliveryBoy) {
            return res
                .status(400)
                .json({ message: "delivery boy not created by admin" });
        }
        if (checkDeliveryBoy.is_active === false) {
            return res
                .status(400)
                .json({ message: "Admin not active your account " });
        }
        const newOtp = 333444;
        try {
            console.log("hiinnknkj", newOtp);
            checkDeliveryBoy.otp = newOtp;
            await checkDeliveryBoy.save();
            const token = generateToken(checkDeliveryBoy, "deliveryboy");
            console.log(token, "ertyuio456789");
            res.status(200).json({ message: "login completed...", token });
        } catch (error) {
            res.status(400).json({ message: "otp send failed try again" });
        }
    } catch (error) {
        console.log("error", error);
        res.status(500).json({ message: "internal server error" });
    }
};

//resend otp
const resendOtp = async (req, res) => {
    try {
        const { contact } = req.body;
        const { error } = deliveryBoySchema.validate(req.body);
        if (error) {
            return res
                .status(400)
                .json({ message: "validation error", error: error.details[0].message });
        }
        const checkDeliveryBoy = await delivery.findOne({ contact });
        if (!checkDeliveryBoy) {
            return res.status(400).json({
                message:
                    "kindly contact with restaurant and register the delivery boy info",
            });
        }
        const resendOtp = 555666;
        checkDeliveryBoy.otp = resendOtp;
        await checkDeliveryBoy.save();
        res.status(200).json({ message: "New otp send suceessfully(` 555666`)" });
    } catch (error) {
        console.log("error", error);
        res.status(500).json({ message: "internal server error" });
    }
};

//otp verify
const otpVerify = async (req, res) => {
    try {
        const { id } = req.user;
        const { otp } = req.body;
        const deliveryboy = await delivery.findOne({ _id: id });
        if (!deliveryboy) {
            return res
                .status(400)
                .json({ message: "token id not founded in database" });
        }
        if (deliveryboy.otp !== otp) {
            return res.status(400).json({ message: `Invalid OTP is ${otp}` });
        }
        deliveryboy.is_active = true;
        await deliveryboy.save();
        res.status(200).json({ message: "OTP verify completed" });
    } catch (error) {
        console.log("error", error);
        res.status(500).json({ message: "internal server error" });
    }
};
const getIncomingOrder = async (req, res) => {
    try {
        const { id } = req.user;
        if (!id) {
            return res.status(401).json({ message: "Invalid Authorization" });
        }

        const restaurantId = await delivery.findOne({ _id: id });
        const restaurant_id = restaurantId.restaurant_id;

        const orders = await foodOrder.find({
            delivery_id: id,
            restaurant_id,
            status: { $in: ["preparing", "pickup", "on the way"] },
        });

        if (!orders || orders.length === 0) {
            return res.status(400).json({ message: "No orders found for this delivery boy" });
        }

        const deliveryBoyLocation = await delivery.findOne({ _id: id });
        if (!deliveryBoyLocation) {
            return res.status(400).json({ message: "Delivery boy location not available" });
        }

        const combinedData = await Promise.all(
            orders.map(async (order) => {
                const deliveryAddress = await address.findById(order.address_id);
                const userinfo = await user.findById(order.user);
                const cartitem = await cart.findById(order.cart_id);
                return {
                    order,
                    deliveryAddress,
                    userinfo,
                    cartitem
                };
            })
        );

        res.status(200).json({
            message: "Incoming food order details...",
            orders: combinedData,
            deliveryBoyLocation: deliveryBoyLocation.location,
        });
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

const getCompletedOrders = async (req, res) => {
    try {
        const { id } = req.user;
        if (!id) {
            return res.status(401).json({ message: "Invalid Authorization" });
        }

        const restaurantId = await delivery.findOne({ _id: id });
        const restaurant_id = restaurantId.restaurant_id;

        const orders = await foodOrder.find({
            delivery_id: id,
            restaurant_id,
            status: { $in: ["delivered"] },
        });

        if (!orders || orders.length === 0) {
            return res.status(400).json({ message: "No orders found for this delivery boy" });
        }

        const deliveryBoyLocation = await delivery.findOne({ _id: id });
        if (!deliveryBoyLocation) {
            return res.status(400).json({ message: "Delivery boy location not available" });
        }

        const combinedData = await Promise.all(
            orders.map(async (order) => {
                const deliveryAddress = await address.findById(order.address_id);
                const userinfo = await user.findById(order.user);
                const cartitem = await cart.findById(order.cart_id);
                return {
                    order,
                    deliveryAddress,
                    userinfo,
                    cartitem
                };
            })
        );

        res.status(200).json({
            message: "Incoming food order details...",
            orders: combinedData,
            deliveryBoyLocation: deliveryBoyLocation.location,
        });
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};


//completed order
// const getCompletedOrder = async (req, res) => {
//     const { id } = req.user;
//     if (!id) {
//         return res
//             .status(401)
//             .json({ message: "invalid token kindly provid the token" });
//     }
//     try {
//         const completedOrder = await foodOrder.find({
//             delivery_id: id,
//             status: "delivered",
//         });
//         if (!completedOrder) {
//             return res.status(400).json({ message: "no completed order found" });
//         }
//         res
//             .status(200)
//             .json({ message: "delivered order taken ok..", completedOrder });
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "internal server error" });
//     }
// };

//cancel order
// const getCancelOrder = async (req, res) => {
//     const { id } = req.user;
//     if (!id) {
//         return res
//             .status(401)
//             .json({ message: "invalid token kindly provid the token" });
//     }
//     try {
//         const cancelOrder = await foodOrder.find({
//             delivery_id: id,
//             status: "cancel",
//         });
//         if (!cancelOrder) {
//             return res.status(400).json({ message: "no completed order found" });
//         }
//         res.status(200).json({ message: "cancel order taken ok..", cancelOrder });
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "internal server error" });
//     }
// };
const getCancelOrder = async (req, res) => {
    const { id } = req.user;
    if (!id) {
        return res.status(401).json({ message: "Invalid token. Kindly provide the token." });
    }
    try {
        // Find canceled orders for the delivery person
        const cancelOrders = await foodOrder.find({ delivery_id: id, status: "cancel" });

        if (!cancelOrders || cancelOrders.length === 0) {
            return res.status(404).json({ message: "No canceled orders found" });
        }

        // Array to store details of canceled orders along with cart details
        const ordersWithCartDetails = [];

        // Iterate over each canceled order
        for (const order of cancelOrders) {
            // Retrieve cart details using the cart_id from the canceled order
            const cartDetails = await cart.findById(order.cart_id);

            // If cart details are found, add them to the canceled order object
            if (cartDetails) {
                const orderWithCartDetails = {
                    cancelOrder: order,
                    cartDetails: cartDetails
                };
                ordersWithCartDetails.push(orderWithCartDetails);
            }
        }

        res.status(200).json({ message: "Cancel orders retrieved successfully", ordersWithCartDetails });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal server error" });
    }
};


//pickup order
const updatedOrderPickup = async (req, res) => {
    const orderId = req.params.id;
    try {
        const updatedOrder = await foodOrder.findOneAndUpdate(
            { orderId },
            { $set: { status: "pickup" } },
            { new: true }
        );
        if (!updatedOrder) {
            return res.status(400).json({ message: "no order found yet" });
        }
        res
            .status(200)
            .json({ message: "Order pickup ok...", order: updatedOrder });
    } catch (error) {
        console.log("Error:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

//update to cancel order
const updateCancelOrder = async (req, res) => {
    const orderId = req.params.id;
    const { reason_for_cancel_byDeliveryBoy } = req.body;
    try {
        const updateCancelOrder = await foodOrder.findOneAndUpdate(
            { orderId },
            { $set: { status: "cancel", reason_for_cancel_byDeliveryBoy } },
            { new: true }
        );
        if (!updateCancelOrder) {
            return res.status(400).json({ message: "Order not found" });
        }
        res
            .status(200)
            .json({ message: "Cancel order update completed", updateCancelOrder });
    } catch (error) {
        console.log("error", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

//reday to ride
const updateOnTheWay = async (req, res) => {
    const orderId = req.params.id;
    try {
        const updateOrderOnTheWay = await foodOrder.findOneAndUpdate(
            { orderId },
            { $set: { status: "on the way" } },
            { new: true }
        );
        if (!updateOrderOnTheWay) {
            return res.status(400).json({ message: "Order not found" });
        }
        res
            .status(200)
            .json({ message: "on the order update completed", updateOrderOnTheWay });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "internal server error" });
    }
};

//order delivered
const updateOrderDelivered = async (req, res) => {
    const orderId = req.params.id;
    try {
        const updateDeliveredOrder = await foodOrder.findOneAndUpdate(
            { orderId },
            { $set: { status: "delivered" } },
            { new: true }
        );
        if (!updateDeliveredOrder) {
            return res.status(400).json({ message: "Order not found" });
        }
        res
            .status(200)
            .json({
                message: "delivered order update completed",
                updateDeliveredOrder,
            });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "internal server error" });
    }
};

//updates status
const updateStatus = async (req, res) => {
    const orderId = req.params.id;
    const { status, reason_for_cancel_byDeliveryBoy } = req.body;
    const allowedStatus = ["cancel", "delivered", "pickup", "on the way"];
    if (!allowedStatus.includes(status)) {
        return res
            .status(400)
            .json({ message: `Invalid status provided ${status}` });
    }
    try {
        const updateOrder = await foodOrder.findOneAndUpdate(
            { orderId },
            { $set: { status, reason_for_cancel_byDeliveryBoy } },
            { new: true }
        );

        if (!updateOrder) {
            return res.status(400).json({ message: "Order not found" });
        }

        res.status(200).json({ message: "Order update completed", updateOrder });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal server error" });
    }
};

//avilable status
const avilableStatus = async (req, res) => {
    const _id = req.user;
    const { is_available } = req.body;
    if (!_id) {
        return res.status(400).json({ message: "token not provided" });
    }
    try {
        const deliveryBoyStatus = await delivery.findOneAndUpdate(
            { _id },
            { $set: { is_available } },
            { new: true }
        );
        if (!deliveryBoyStatus) {
            return res
                .status(400)
                .json({ message: "delivery boy status update failed" });
        }
        res
            .status(200)
            .json({
                message: "deliveryboy status changed",
                status: deliveryBoyStatus,
            });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "internal server error" });
    }
};

const getOrderDetails = async (req, res) => {
    // const delivery_id = req.user.id;
    // if (!delivery_id) {
    //     return res.status(400).json({ message: "token not provided" });
    // }
    // try {
    //     const orders = await foodOrder.find({ delivery_id });
    //     if (orders.length === 0) {
    //         return res.status(200).json({ message: "no order found" });
    //     }

    //     // Assuming each order has a cart_id
    //     const cartIds = orders.map(order => order.cart_id);

    //     // Use $in operator to find carts with multiple cart_ids
    //     const cartdetails = await cart.find({ _id: { $in: cartIds } });

    //     res.status(200).json({ message: "orders", orders, cartdetails });
    // } catch (error) {
    //     res.status(500).json({ message: "internal server error" });
    // }
    const delivery_id = req.user.id;
    const orderId = req.params.orderId; // Assuming order_id is passed as a parameter

    if (!delivery_id) {
        return res.status(400).json({ message: "token not provided" });
    }
    try {
        const order = await foodOrder.findOne({ orderId: orderId, delivery_id });
        if (!order) {
            return res.status(200).json({ message: "order not found" });
        }

        const cartId = order.cart_id;
        const cartdetails = await cart.findOne({ _id: cartId });

        res.status(200).json({ message: "order details", order, cartdetails });
    } catch (error) {
        res.status(500).json({ message: "internal server error" });
    }
};

module.exports = {
    loginDeliveryBoy,
    resendOtp,
    otpVerify,
    getIncomingOrder,
    getCompletedOrders,
    getCancelOrder,
    updatedOrderPickup,
    updateCancelOrder,
    updateOrderDelivered,
    updateOnTheWay,
    updateStatus,
    avilableStatus,
    getOrderDetails,
};