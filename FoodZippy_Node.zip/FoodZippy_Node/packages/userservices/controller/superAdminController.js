const Joi = require("joi");
const Restaurant = require("../../common/model/restaurantSchema");
const SuperAdmin = require('../../common/model/superAdminSchema');
const Admin = require('../../common/model/adminSchema');
const foodOrder = require("../../common/model/orderSchema");
const PaymentHistory = require("../../common/model/paymentHistorySchema");
const Address = require('../../common/model/addressSchema');
const plans = require("../../common/model/subscriptionPlanSchema")
const otpGenerator = require("otp-generator");
const bcrypt = require("bcrypt");
const dotenv = require("dotenv");
const stripe = require('stripe')(process.env.STRIPE_SECRETKEY);
dotenv.config();
const {
    generateToken,
    addTokenToBlacklist,
    verifyToken,
} = require("../middleware/authMiddleware");
const mailService = require("../helper/mail_serverices");
const apiResponse = require("../middleware/apiResponse");
const Menu = require('../../common/model/menuSchema');
const fs = require('fs');
const path = require('path');
const FoodOrder = require("../../common/model/orderSchema");
const { address } = require("../../orderservices/webscoket/websocket_sever");
// Joi schema for validating login data
const superAdminSchema = Joi.object({
    email: Joi.string().email(),
    password: Joi.string(),
});
const adminSchema = Joi.object({
    email: Joi.string().email(),
    password: Joi.string()
        .pattern(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z\d]).{8,}$/)
        .message(
            "Password must contain at least 8 characters, including one lowercase letter, one uppercase letter, one digit, and one special character."
        ),
    firstname: Joi.string(),
    lastname: Joi.string(),
    gender: Joi.string(),
    mobile: Joi.string().min(10).max(11),
    country: Joi.string(),
    ipaddress: Joi.string(),
    is_active: Joi.boolean(),
    otp: Joi.string().length(6),
    otp_time_out: Joi.boolean(),
    superadminId: Joi.string(),
});
const restaurantSchema = Joi.object({
    logoImage: Joi.object().keys({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    imageURL: Joi.string(),
    restaurantName: Joi.string(),
    address: Joi.string(),
    currency: Joi.string(),
    city: Joi.string(),
    zipcode: Joi.string().min(3).max(8).regex(/^[a-zA-Z0-9\s]+$/),
    mobile: Joi.object({
        countryCode: Joi.string(),
        phoneNumber: Joi.string().min(10).max(11),
    }).optional(),
    facilities: Joi.string(),
    serviceDescription: Joi.string(),
    is_active: Joi.boolean().default(true),
    mapLocation: Joi.object({
        lat: Joi.number(),
        long: Joi.number(),
    }),
    admin_id: Joi.string(),
    superadminId: Joi.string(),
    cin_number: Joi.string(),
    gst_number: Joi.string(),
    tin_number: Joi.string(),
});
const menuItemJoiSchema = Joi.object({
    categoryName: Joi.string(),
    itemName: Joi.string(),
    itemAvailableTime: Joi.string(),
    itemAvailableTimefrom: Joi.string(),
    itemAvailableTimeto: Joi.string(),
    preparationTime: Joi.string(),
    description: Joi.string(),
    itemImage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    imageURL: Joi.string(),
    itemType: Joi.string().valid("vegetarian", "non vegetarian", "vegan"),
    itemPrice: Joi.number(),
    is_active: Joi.boolean(),
    discountPriceAvailable: Joi.boolean(),
    discountPriceAmount: Joi.number(),
    packingCharge: Joi.number(),
    admin_id: Joi.string(),
    restaurant_id: Joi.string(),
    additemvariant: Joi.array().items(
        Joi.object({
            category: Joi.string(),
            itemName: Joi.string(),
            price: Joi.number(),
            type: Joi.string().valid("vegetarian", "non vegetarian", "vegan"),
            isActive: Joi.boolean(),
            created_at: Joi.date(),
            updated_at: Joi.date(),
        })
    ),
    // combo: Joi.array().items(
    //   Joi.object({
    //     comboItems: Joi.array().items(Joi.string()),
    //     is_active: Joi.boolean(),
    //     comboPrice: Joi.number(),
    //   })
    // ),
    addons: Joi.array().items(
        Joi.object({
            addonName: Joi.string(),
            addonPrice: Joi.number(),
        })
    ),
    created_at: Joi.date(),
    superadminId: Joi.date(),
    updated_at: Joi.date(),
});
// const createsuperAdmin = async (req, res) => {
//     try {
//         // Validate request body
//         const { error, value } = superAdminSchema.validate(req.body);
//         if (error) {
//             return apiResponse.validationError(res, error.details[0].message);
//         }

//         // Check if SuperAdmin with given email already exists
//         const existingSuperAdmin = await SuperAdmin.findOne({ email: value.email });
//         if (existingSuperAdmin) {
//             return apiResponse.validationError(res, "SuperAdmin with this email already exists");
//         }

//         // Hash password
//         const hashedPassword = await bcrypt.hash(value.password, 10);

//         // Create new SuperAdmin
//         const newSuperAdmin = new SuperAdmin({
//             email: value.email,
//             password: hashedPassword,
//             is_active: value.is_active || false,
//         });

//         // Save SuperAdmin to database
//         await newSuperAdmin.save();

//         // Send response
//         return apiResponse.saveApiResponseWithData(res, "SuperAdmin created successfully");
//     } catch (error) {
//         console.error("Error creating SuperAdmin:", error);
//         return apiResponse.serverErrorResponse(res, "Internal server error");
//     }
// };
const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const { error } = superAdminSchema.validate(req.body);
        if (error) {
            const validationErrorsArray = error.details.map(
                (detail) => detail.message
            );
            console.log(validationErrorsArray); // Log validation errors
            return apiResponse.validationError(res, validationErrorsArray);
        }

        // Check if the email is not registered
        const superadmin = await SuperAdmin.findOne({ email, is_active: true });
        if (!superadmin) {
            // return apiResponse.dataFoundResponse(res, 'Email is not registger')
            return res.status(401).json({ message: "Email is not registger" });
        }
        const passwordMatch = bcrypt.compareSync(password, superadmin.password);
        console.log("Password Match:", passwordMatch);

        if (!passwordMatch) {
            console.log("Invalid Password!");
            return apiResponse.validationError(res, "Invalid credentials.");
        }
        const token = generateToken(superadmin, "SuperAdmin");
        return apiResponse.getApiResponse(res, "super admin logged in successfully.", {
            token,
        });
    } catch (error) {
        return apiResponse.serverErrorResponse(
            res,
            "Unable to perform admin login."
        );
    }
};
// const changePassword = async (req, res) => {
//     try {
//         const superadminId = req.user;
//         console.log(superadminId, "ijaduh");
//         const { oldPassword, newPassword } = req.body;
//         // Find SuperAdmin by email
//         const superadmin = await SuperAdmin.findOne({ _id: superadminId });
//         if (!superadmin) {
//             return res.status(404).json({ message: "SuperAdmin not found" });
//         }
//         console.log(superadmin, "superadmin")
//         // Check if old password matches
//         const passwordMatch = await bcrypt.compare(oldPassword, superadmin.password);
//         console.log(passwordMatch, "sxxrdhvbygdcsb ygushbs");
//         if (!passwordMatch) {
//             return apiResponse.validationError(res, "Old password does not match");
//         }

//         // Hash new password
//         const hashedNewPassword = await bcrypt.hash(newPassword, 10);

//         // Update password
//         superadmin.password = hashedNewPassword;
//         await superadmin.save();

//         return apiResponse.saveApiResponseWithData(res, "Password changed successfully");
//     } catch (error) {
//         console.error("Error changing password:", error);
//         return apiResponse.serverErrorResponse(
//             res,
//             "Unable to change password"
//         );
//     }
// };
const requestPasswordReset = async (req, res) => {
    try {
        const { email } = req.body;
        const superadmin = await SuperAdmin.findOne({ email, is_active: true });
        console.log(superadmin, "happy")
        if (!superadmin) {
            return res.status(404).json({ error: "SuperAdmin not found." });
        }

        // Generate a reset token and save it to the superadmin's record in the database
        const resetToken = generateToken(superadmin, "SuperAdmin");
        console.log(resetToken, "resetToken");
        const encodedToken = Buffer.from(resetToken).toString("base64");
        superadmin.resetToken = encodedToken;

        const savedSuperAdmin = await superadmin.save();

        // Sending email to the superadmin using the common mail service
        const subject = "Password Reset Request";
        const link = `https://foodzippy-sa.web.app/reset-password?user=${encodedToken}`;
        const text = `Hello ${superadmin.email},\n\nYou've requested to reset your password. Please use the following link to reset your password: ${link}`;
        const emailSent = await mailService.sendEmail(email, subject, text);

        res.status(200).json({
            email: savedSuperAdmin.email,
            message: "Password reset email sent successfully.",
        });
    } catch (error) {
        res.status(500).json({ error: "Failed to request password reset." });
    }
};

const resetPassword = async (req, res) => {
    try {
        // Validate the request body using the superAdminSchema
        const superAdminIdFromToken = req.user;
        const { error } = superAdminSchema.validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);

        // Find the superadmin by the decoded token (attached by the middleware)
        const superadmin = await SuperAdmin.findById(superAdminIdFromToken);
        if (!superadmin) {
            return res.status(400).json({ message: "SuperAdmin not found" });
        }

        // Generate a new password hash and update the superadmin's password
        const newPasswordHash = await bcrypt.hash(req.body.password, 10);
        superadmin.password = newPasswordHash;

        // Save the updated superadmin
        await superadmin.save();

        // Add the used token to a blacklist (optional but recommended)
        addTokenToBlacklist(superAdminIdFromToken);

        return res.status(200).json({ message: "Password reset successfully." });
    } catch (error) {
        console.log(error);
        res.status(500).send("An error occurred");
    }
};
const createadmin = async (req, res) => {
    try {
        const superAdminId = req.user;
        // Extract data from request body
        const { email, firstname, lastname, gender, mobile, country, is_active } = req.body;
        // Check if an admin with the same email already exists
        const existingAdmin = await Admin.findOne({ email });
        if (existingAdmin) {
            return res.status(400).json({ message: "An admin with this email already exists." });
        }
        // Find the superadmin by the decoded token (attached by the middleware)
        const superadmin = await SuperAdmin.findById(superAdminId);
        if (!superadmin) {
            return res.status(400).json({ message: "SuperAdmin not found" });
        }
        // Create admin object
        const admin = new Admin({
            email,
            firstname,
            lastname,
            gender,
            mobile,
            country,
            is_active: true,
        });
        admin.superadminId = superAdminId;

        // Save admin to database
        await admin.save();

        res.status(201).json({ message: 'Admin created successfully', admin });
    } catch (error) {
        console.error(error); // Log the error to the console
        res.status(500).json({ message: 'Error creating admin', error: error.message });
    }
};
// const updateAdminStatus = async (req, res) => {
//     try {
//         const superAdminId = req.user;
//         // Extract data from request body
//         const { adminId } = req.body;

//         // Find the superadmin by the decoded token (attached by the middleware)
//         const superadmin = await SuperAdmin.findById(superAdminId);
//         if (!superadmin) {
//             return res.status(400).json({ message: "SuperAdmin not found" });
//         }

//         // Find the admin to update
//         const admin = await Admin.findById(adminId);
//         if (!admin) {
//             return res.status(400).json({ message: "Admin not found" });
//         }
//         // Extract data from request body
//         const { is_active, email, firstname, lastname, gender, mobile } = req.body;

//         // Update the fields provided in the request body
//         if (is_active !== undefined) {
//             admin.is_active = is_active;
//         }
//         if (email !== undefined) {
//             admin.email = email;
//         }
//         if (firstname !== undefined) {
//             admin.firstname = firstname;
//         }
//         if (lastname !== undefined) {
//             admin.lastname = lastname;
//         }
//         if (gender !== undefined) {
//             admin.gender = gender;
//         }
//         if (mobile !== undefined) {
//             admin.mobile = mobile;
//         }

//         // Save admin to database
//         await admin.save();

//         res.status(200).json({ message: 'Admin status updated successfully', admin });
//     } catch (error) {
//         console.error(error); // Log the error to the console
//         res.status(500).json({ message: 'Error updating admin status', error: error.message });
//     }
// };
const updateAdminStatus = async (req, res) => {
    try {
        const superAdminId = req.user;
        // Extract data from request body
        const { adminId } = req.body;

        // Find the superadmin by the decoded token (attached by the middleware)
        const superadmin = await SuperAdmin.findById(superAdminId);
        if (!superadmin) {
            return res.status(400).json({ message: "SuperAdmin not found" });
        }

        // Find the admin to update
        const admin = await Admin.findById(adminId);
        if (!admin) {
            return res.status(400).json({ message: "Admin not found" });
        }

        // Extract data from request body
        const { is_active, email, firstname, lastname, gender, mobile } = req.body;

        // Check if email is being updated
        let emailUpdated = false;
        if (email !== undefined && admin.email !== email) {
            emailUpdated = true;
        }

        // Update the fields provided in the request body
        if (is_active !== undefined) {
            admin.is_active = is_active;
        }
        if (email !== undefined) {
            admin.email = email;
        }
        if (firstname !== undefined) {
            admin.firstname = firstname;
        }
        if (lastname !== undefined) {
            admin.lastname = lastname;
        }
        if (gender !== undefined) {
            admin.gender = gender;
        }
        if (mobile !== undefined) {
            admin.mobile = mobile;
        }
        // Save admin to database
        await admin.save();
        // Send email notification if email is updated
        if (emailUpdated) {
            const subject = "Restaurant Admin Email Address Updated";
            const link = "https://food-zippy.web.app";
            const text = `Hello ${admin.firstname},\n\nYour email address has been updated.\n\nYour new email address is:
             ${admin.email}\n\nYou have been successfully updated as an admin for the restaurant. ${link}`; // Email content
            await mailService.sendEmail(admin.email, subject, text);
        }
        res.status(200).json({ message: 'Admin status updated successfully', admin });
    } catch (error) {
        console.error(error); // Log the error to the console
        res.status(500).json({ message: 'Error updating admin status', error: error.message });
    }
};

const createrestaurantbysuperaadmin = async (req, res) => {
    try {
        // Access fields from the request body
        const {
            restaurantName,
            address,
            currency,
            city,
            zipcode,
            mobile,
            is_active,
            mapLocation,
            admin_id,
            cin_number,
            gst_number,
            tin_number,
        } = req.body;

        // Access the user_id from the token (assuming it's the super admin ID)
        const superadminId = req.user;

        // Validate request body against restaurantSchema
        const { error: restaurantValidationError, value: validatedRestaurantBody } =
            restaurantSchema.validate({
                restaurantName,
                address,
                currency,
                city,
                zipcode,
                mobile,
                is_active,
                mapLocation,
                cin_number,
                gst_number,
                tin_number,
            });

        // Check if there is a validation error in the restaurant request body
        if (restaurantValidationError) {
            return res.status(400).json({ error: restaurantValidationError.details[0].message });
        }
        // Check if restaurant name already exists in the database
        const existingRestaurant = await Restaurant.findOne({ restaurantName });
        if (existingRestaurant) {
            return res.status(400).json({ error: "Restaurant name already exists" });
        }
        // Retrieve admin details from admin_id
        const admin = await Admin.findById({ _id: admin_id });

        // Check if admin with provided admin_id exists and is active
        if (!admin || !admin.is_active) {
            return res.status(400).json({ error: "Invalid or inactive admin_id" });
        }
        // Check if the admin already has a restaurant
        const existingRestaurantForAdmin = await Restaurant.findOne({ admin_id: admin_id });
        if (existingRestaurantForAdmin) {
            return res.status(400).json({ error: "Admin already has a restaurant" });
        }

        // Generate a random special character
        const specialCharacter = String.fromCharCode(Math.floor(Math.random() * 94) + 33); // ASCII range for special characters

        // Generate admin password based on criteria
        const lowercaseLetters = 'abcdefghijklmnopqrstuvwxyz';
        const uppercaseLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const digits = '0123456789';
        const specialCharacters = '!@#$%^&*()-_+=';

        let generatedPassword = '';

        // At least one lowercase letter
        generatedPassword += lowercaseLetters.charAt(Math.floor(Math.random() * lowercaseLetters.length));

        // At least one uppercase letter
        generatedPassword += uppercaseLetters.charAt(Math.floor(Math.random() * uppercaseLetters.length));

        // At least one digit
        generatedPassword += digits.charAt(Math.floor(Math.random() * digits.length));

        // At least one special character
        generatedPassword += specialCharacters.charAt(Math.floor(Math.random() * specialCharacters.length));

        // Fill the rest of the password with random characters to reach the minimum length of 8
        for (let i = 4; i < 8; i++) {
            generatedPassword += lowercaseLetters.charAt(Math.floor(Math.random() * lowercaseLetters.length));
        }

        // Shuffle the password characters to ensure randomness
        generatedPassword = generatedPassword.split('').sort(() => Math.random() - 0.5).join('');

        // Hash the generated password
        const hashedPassword = await bcrypt.hash(generatedPassword, 10);

        // Update admin document with hashed password
        admin.password = hashedPassword;
        await admin.save();

        // Initialize a new Restaurant object with the validated data
        const newRestaurant = new Restaurant({
            restaurantName,
            address,
            currency,
            city,
            zipcode,
            mobile,
            is_active,
            mapLocation,
            superadminId,
            admin_id,
            cin_number,
            gst_number,
            tin_number,
        });

        // Check if a file was uploaded and save image details
        if (req.file) {
            newRestaurant.logoImage = {
                data: req.file.buffer,
                contentType: req.file.mimetype,
            };
            const imageFileName = `${req.file.originalname}`;
            const imagePath = `/uploads/${imageFileName}`; // Relative path to the image
            newRestaurant.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;
        }
        // Save the new restaurant to the database
        await newRestaurant.save();
        // Sending email to the admin using the common mail service
        const subject = "Restaurant Admin Credentials";
        const link = "https://food-zippy.web.app"
        const text = `Hello ${admin.firstname},\n\nYour username is: ${admin.email}\nYour password is: ${generatedPassword}\n
        \nYou have been successfully created as an admin for the restaurant ${restaurantName}.${link}` // Email content
        const emailSent = await mailService.sendEmail(admin.email, subject, text);

        // Send a success response
        res.status(201).json({
            message: "Restaurant created successfully",
            restaurantDetails: newRestaurant,
            adminDetails: {
                firstname: admin.firstname,
                password: generatedPassword,
            }
        });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};
const updateRestaurantBySuperadmin = async (req, res) => {
    try {
        // Access fields from the request body
        const {
            restaurantId,
            restaurantName,
            address,
            currency,
            city,
            zipcode,
            mobile,
            is_active,
            mapLocation,
            admin_id,
        } = req.body;

        // Access the user_id from the token (assuming it's the super admin ID)
        const superadminId = req.user;

        // Find the restaurant to update
        const restaurant = await Restaurant.findById(restaurantId);
        if (!restaurant) {
            return res.status(400).json({ error: "Restaurant not found" });
        }

        // Check if the super admin is authorized to update the restaurant
        // if (restaurant.superadminId !== superadminId) {
        //     return res.status(403).json({ error: "You are not authorized to update this restaurant" });
        // }

        // Update restaurant fields
        if (restaurantName !== undefined) {
            restaurant.restaurantName = restaurantName;
        }
        if (address !== undefined) {
            restaurant.address = address;
        }
        if (currency !== undefined) {
            restaurant.currency = currency;
        }
        if (city !== undefined) {
            restaurant.city = city;
        }
        if (zipcode !== undefined) {
            restaurant.zipcode = zipcode;
        }
        if (mobile !== undefined) {
            restaurant.mobile = mobile;
        }
        if (is_active !== undefined) {
            restaurant.is_active = is_active;
        }
        if (mapLocation !== undefined) {
            restaurant.mapLocation = mapLocation;
        }
        if (admin_id !== undefined) {
            restaurant.admin_id = admin_id;
        }

        // Check if admin with provided admin_id exists and is active
        const admin = await Admin.findById(admin_id);
        if (!admin || !admin.is_active) {
            return res.status(400).json({ error: "Invalid or inactive admin_id" });
        }

        // Save the updated restaurant to the database
        await restaurant.save();

        // Send a success response
        res.status(200).json({
            message: "Restaurant updated successfully",
            restaurantDetails: restaurant,
        });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const getAdminsAndRestaurants = async (req, res) => {
    try {
        const superAdminId = req.user;
        // Find the superadmin by the decoded token (attached by the middleware)
        const superadmin = await SuperAdmin.findById(superAdminId);
        if (!superadmin) {
            return res.status(400).json({ message: "SuperAdmin not found" });
        }
        // Retrieve all admins with selected fields
        const admins = await Admin.find({ superadminId: superAdminId }, 'firstname email mobile is_active');
        // Retrieve all restaurants with selected fields
        // const restaurants = await Restaurant.find({ superadminId: superAdminId, is_active: true }, 'restaurantName address admin_id is_active');
        // console.log(restaurants, "msdindsj");
        const restaurants = await Restaurant.find({ superadminId: superAdminId }, 'restaurantName address admin_id ');
        console.log("Found restaurants:", restaurants);
        res.status(200).json({ admins, restaurants });
    } catch (error) {
        console.error(error); // Log the error to the console
        res.status(500).json({ message: 'Error fetching data', error: error.message });
    }
};
const createMenuItem = async (req, res) => {
    try {
        // Extract admin_id from the request body
        const { admin_id, restaurant_id } = req.body;

        // Extract superadminId from the request token
        const superadminId = req.user;

        // Validate the request body using Joi schema
        const { error, value } = menuItemJoiSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ error: error.details[0].message });
        }

        // Check if a menu item with the same name already exists for the provided admin_id
        const existingMenuItem = await Menu.findOne({ itemName: value.itemName, restaurant_id });
        if (existingMenuItem) {
            return res.status(400).json({ error: "Menu item with the same name already exists" });
        }

        // Create a new menu item based on the validated request data
        const newMenuItem = new Menu(value);
        newMenuItem.admin_id = admin_id;
        newMenuItem.superadminId = superadminId;
        newMenuItem.restaurant_id = restaurant_id;
        // Handle the uploaded image if available
        if (req.file) {
            newMenuItem.itemImage.data = req.file.buffer;
            newMenuItem.itemImage.contentType = req.file.mimetype;
        }

        // Construct image URL
        const imageFileName = `${req.file.originalname}`;
        const imagePath = `/uploads/${imageFileName}`;
        newMenuItem.imageURL = `${req.protocol}://${req.get("host")}${imagePath}`;

        // Save the menu item to the database
        const savedItem = await newMenuItem.save();

        // Send the saved menu item in the response
        res.status(201).json(savedItem);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
};
const getRestaurantsForSuperAdmin = async (req, res) => {
    try {
        // Get the super admin ID from the request token
        const superAdminId = req.user;

        // Extract fromDate and toDate from the request query parameters
        const { fromDate, toDate } = req.query;

        // Initialize the query object with the super admin ID
        let query = { superadminId: superAdminId };

        // If both fromDate and toDate are provided, add them to the query
        if (fromDate && toDate) {
            const fromDateObj = new Date(fromDate);
            const toDateObj = new Date(toDate);
            // Add the createdAt field to the query to filter by date range
            query.createdAt = {
                $gte: fromDateObj,
                $lte: toDateObj
            };
        }

        // Find all restaurants matching the query
        const restaurants = await Restaurant.find(query);

        // if (!restaurants || restaurants.length === 0) {
        //     return res.status(404).json({ error: "No restaurants found" });
        // }

        // Initialize total number of restaurants, total number of orders, and total number of subscriptions
        let totalRestaurants = restaurants.length;
        let totalOrders = 0;
        let totalSubscriptions = 0;

        // Iterate over each restaurant
        for (let i = 0; i < restaurants.length; i++) {
            const restaurant = restaurants[i];

            // Find the total number of orders for the current restaurant
            const orderCount = await FoodOrder.countDocuments({ restaurant_id: restaurant._id });

            // Add the order count to the total orders
            totalOrders += orderCount;

            // Find the total number of subscriptions for the current restaurant
            const subscriptionCount = await PaymentHistory.countDocuments({ restaurantId: restaurant._id });

            // Add the subscription count to the total subscriptions
            totalSubscriptions += subscriptionCount;
        }

        // Return the total number of restaurants, total number of orders, and total number of subscriptions in the response
        res.status(200).json({ totalRestaurants, totalOrders, totalSubscriptions });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
};


const getAllorders = async (req, res) => {
    try {
        // Extract restaurant name from query parameters
        const restaurantName = req.query.restaurantName;

        // Create a filter object
        let filter = {};

        // If restaurantName is provided, add it to the filter
        if (restaurantName) {
            const restaurant = await Restaurant.findOne({ restaurantName: restaurantName });
            if (!restaurant) {
                return res.status(404).json({ message: "Restaurant not found" });
            }
            filter['restaurant_id'] = restaurant._id;
        }

        // Find all orders matching the filter and populate the restaurant and address details
        const orders = await FoodOrder.find(filter)
            .populate({
                path: 'restaurant_id',
                select: 'restaurantName', // Only select the restaurantName field
                model: Restaurant
            })
            .populate({
                path: 'address_id',
                model: Address
            });

        // If no orders found, return empty response
        if (!orders || orders.length === 0) {
            return res.status(404).json({ message: "No orders found" });
        }

        // Initialize counts
        let pendingCount = 0;
        let cancelledCount = 0;

        // Transform each order object to include additional data
        const formattedOrders = orders.map(order => {
            // Determine the mode of payment
            let modeOfPayment = '';
            if (order.payment_id) {
                modeOfPayment = 'Card';
            } else if (order.cash_on_delivery) {
                modeOfPayment = 'Cash on Delivery';
            } else {
                modeOfPayment = 'Not specified';
            }

            // Count pending and cancelled orders
            if (order.status === 'pending') {
                pendingCount++;
            } else if (order.status === 'cancel') {
                cancelledCount++;
            }

            // Check if restaurant_id is not null before accessing its properties
            const restaurantName = order.restaurant_id ? order.restaurant_id.restaurantName : 'N/A';

            return {
                orderId: order.orderId,
                status: order.status,
                total_amount: order.total_amount,
                restaurantName: restaurantName,
                deliveryLocation: order.address_id,
                modeOfPayment: modeOfPayment,
                // Add other fields you want to include from the address
            };
        });

        // Response object including orders and counts
        const response = {
            orders: formattedOrders,
            pendingCount: pendingCount,
            cancelledCount: cancelledCount
        };

        res.status(200).json(response);
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const getAllOrdersForRestaurant = async (req, res) => {
    try {
        // Extract restaurant ID and status from query parameters
        const restaurantId = req.query.restaurantId;
        const status = req.query.status;

        // If restaurantId is not provided, return an error response
        if (!restaurantId) {
            return res.status(400).json({ error: "Restaurant ID is required" });
        }

        // Find the restaurant by ID
        const restaurant = await Restaurant.findById(restaurantId);

        // If restaurant not found, return an error response
        if (!restaurant) {
            return res.status(404).json({ error: "Restaurant not found" });
        }

        // Create filter object with restaurant ID
        const filter = { restaurant_id: restaurant._id };

        // If status is provided, add it to the filter
        if (status) {
            filter.status = status;
        }

        // Find all orders matching the filter
        const orders = await FoodOrder.find(filter)
            .populate({
                path: 'address_id',
                model: Address
            });

        // If no orders found, return empty response
        if (!orders || orders.length === 0) {
            return res.status(404).json({ message: "No orders found for this restaurant" });
        }

        // Transform each order object to include additional data
        const formattedOrders = orders.map(order => {
            // Determine the mode of payment
            let modeOfPayment = '';
            if (order.payment_id) {
                modeOfPayment = 'Card';
            } else if (order.cash_on_delivery) {
                modeOfPayment = 'Cash on Delivery';
            } else {
                modeOfPayment = 'Not specified';
            }

            return {
                orderId: order.orderId,
                status: order.status,
                total_amount: order.total_amount,
                deliveryLocation: order.address_id,
                modeOfPayment: modeOfPayment,
                // Add other fields you want to include from the address
            };
        });

        // Response object including orders
        const response = {
            orders: formattedOrders
        };

        res.status(200).json(response);
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
};
const getClientInformation = async (req, res) => {
    try {
        // Extract admin_id from request parameters
        const adminId = req.params.admin_id;

        // Find admin details by admin_id
        const admin = await Admin.findById(adminId);
        // If admin not found, return error response
        if (!admin) {
            return res.status(404).json({ error: "Admin not found" });
        }

        let restaurant = null;
        let paymentHistory = null;

        // If admin has associated restaurant, find restaurant details
        if (adminId) {
            restaurant = await Restaurant.find({ admin_id: adminId });
            paymentHistory = await PaymentHistory.find({ restaurantId: restaurant._id });
        }
        // Construct client information object
        const clientInformation = {
            admin: {
                _id: admin._id,
                firstname: admin.firstname,
                lastname: admin.lastname,
                email: admin.email,
                mobile: admin.mobile,
                gender: admin.gender,
                ipaddress: admin.ipaddress,
                country: admin.country,
                // Add other admin details as needed
            },
        };

        // Return client information in the response
        res.status(200).json({ clientInformation, restaurant, paymentHistory });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
};
//create subscription plans
const createSubscription = async (req, res) => {
    const superadmin = req.user.id;
    const restaurantId = req.query.restaurantId;
    try {
        // Create a product
        const product = await stripe.products.create({
            name: "Subscription Plan",
            type: "service",
            // images: [''],
        });
        const plan = {
            nickname: req.body.planName,
            interval: req.body.duration,
            interval_count: req.body.count || 1,
            currency: req.body.currency || "usd",
            amount: req.body.price * 100,
            active: false,
            metadata: {
                restaurant_id: restaurantId,
                max_users: req.body.maxUsers,
                max_restaurants: req.body.maxRestaurants,
                one_time_setup_charge: req.body.setupCharge,
                commission_percentage: req.body.commissionPercentage,
            },
        };

        // Create the plan in Stripe
        const createdPlan = await stripe.plans.create({
            product: product.id,
            ...plan,
        });

        // Save the plan details to MongoDB
        const savedPlan = await plans.create({
            stripePlanId: createdPlan.id,
            plan_creater_id: superadmin,
            ...plan,
            product: createdPlan.product,
        });

        res
            .status(200)
            .json({
                message: "Subscription plan created successfully.",
                createdPlan,
                savedPlan,
            });
    } catch (error) {
        console.error("Error creating subscription plan:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};


//update supscription
const updateSubscription = async (req, res) => {
    const subscriptionId = req.params.planid;
    const superAdminId = req.user.id;
    const planUpdates = {
        nickname: req.body.planName,
        interval: req.body.duration,
        interval_count: req.body.count || 1,
        currency: req.body.currency || "usd",
        amount: req.body.price * 100,
        active: req.body.active,
        livemode: req.body.livemode,
        metadata: {
            max_users: req.body.maxUsers,
            max_restaurants: req.body.maxRestaurants,
            one_time_setup_charge: req.body.setupCharge,
            commission_percentage: req.body.commissionPercentage,
        }
    };

    try {
        const existingPlans = await stripe.plans.retrieve(subscriptionId);
        const updatedPlans = await stripe.plans.create({
            product: existingPlans.product,
            ...planUpdates,
        });
        const saveUpadte = await plans.findOneAndUpdate(
            { product: updatedPlans.product },
            {
                ...planUpdates,
                stripePlanId: updatedPlans.id,
                plan_creater_id: superAdminId,
            },
            { new: true }
        );
        await stripe.plans.del(subscriptionId)

        res
            .status(200)
            .json({
                message: "Plan updated successfully",
                updatedPlans,
                saveplan: saveUpadte,
            });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal server error" });
    }
};

//getActive plan only
const getProductionPlans = async (req, res) => {
    try {
        const plans = await stripe.plans.list({
            active: true,
        });
        res.status(200).json({ plans });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal server error" });
    }
};

// show plan info details after selected a plan
const paymenyInfo = async (req, res) => {
    const planId = req.params.planid;
    const email = req.params.email;
    try {
        const plan = await stripe.plans.retrieve(planId);
        console.log("poi", plan);

        let totalAmount = 0;
        let isNewUser = false;

        const customer = await stripe.customers.list({ email: email, limit: 1 });
        if (customer.data.length > 0) {
            const plan = await stripe.plans.retrieve(planId);
            totalAmount = plan.amount;
        } else {
            const plan = await stripe.plans.retrieve(planId);
            totalAmount =
                plan.amount + parseFloat(plan.metadata.one_time_setup_charge);
            isNewUser = true;
        }
        res.status(200).json({ message: "ok..", plan, totalAmount, isNewUser });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "internal server error" });
    }
};

//get all subscription plan
const getAllPlans = async (req, res) => {
    try {
        const plans = await stripe.plans.list();
        console.log(plans);
        res.status(200).json({ message: plans });
    } catch (error) {
        console.log(error);
        res.status(500).json("internal server error");
    }
};

//payment processing logic with code
const subscriptionPayment = async (req, res) => {
    const subscriptionPlanId = req.params.planid;
    const restaurantId = req.query.restaurantId;
    const _id = req.user.id;
    try {
        const adminCustomer = await Admin.findOne({ _id });
        const superAdminCustomer = await SuperAdmin.findOne({ _id });

        let getcustomerExists = adminCustomer || superAdminCustomer;

        // console.log("dd", getcustomerExists);

        const existingCustomers = await stripe.customers.list({
            email: getcustomerExists.email,
            limit: 1,
        });
        const customerExists = existingCustomers.data.length > 0;

        // const customer = customerExists
        //     ? existingCustomers.data[0]
        //     : await stripe.customers.create({ email, name });

        const plan = await stripe.plans.retrieve(subscriptionPlanId);
        // console.log("pp", plan)

        const totalAmount = customerExists
            ? plan.amount
            : plan.amount + (parseFloat(plan.metadata.one_time_setup_charge) || 0);

        //section
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ["card"],
            line_items: [
                {
                    price_data: {
                        currency: "usd",
                        product_data: {
                            name: plan.nickname,
                        },
                        unit_amount: Math.round(totalAmount),
                    },
                    quantity: 1,
                },
            ],
            mode: "payment",
            success_url: "http://localhost:3000/api/v1/success",
            cancel_url: "http://localhost:3000/api/v1/cancel",
            payment_intent_data: {
                description: "",
            },
        });
        let customer;
        let expiryDate;
        //check already plan valid date diff and add to exp or interval date(pending)
        if (session.payment_status === "unpaid") {
            const checkDueDate = await Admin.findOne({
                $or: [{ _id: _id }, { superadminId: _id }],
            });
            //   console.log("check due date", checkDueDate.due_date);
            const today = new Date();
            const dueDate = new Date(checkDueDate.due_date);

            // Calculate the difference in days between today and the due date
            let differenceInDays = Math.ceil(
                (dueDate - today) / (1000 * 60 * 60 * 24)
            );
            differenceInDays = differenceInDays >= 0 ? differenceInDays : 0; // Ensure differenceInDays is not negative

            //   console.log("totals", differenceInDays);
            customer = await stripe.customers.create({
                email: getcustomerExists.email,
            });
            expiryDate = new Date();
            expiryDate.setDate(
                expiryDate.getDate() + parseInt(plan.interval_count + differenceInDays)
            );
            //   console.log("lkj", expiryDate);
        }
        const saveDataAdmin = await Admin.findOneAndUpdate(
            {
                $or: [{ _id: _id }, { superadminId: _id }],
            },
            { due_date: expiryDate, commission: plan.metadata.commission_percentage },
            { new: true }
        );
        // console.log("admin", saveDataAdmin);
        //going to save data
        const paymentHistory = paymentHistorySchema({
            customer: customer,
            SubscriperId: _id,
            plan: plan,
            totalAmount: totalAmount,
            session: session,
            expiryDate: expiryDate,
            restaurantId: restaurantId
        });
        // console.log("pooiiiii", paymentHistory);
        await paymentHistory.save();

        res.status(200).json({ message: "ok....", paymentHistory });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal server error" });
    }
};
const getPaymentInfosuperadmin = async (req, res) => {
    try {
        const sessionId = req.params.id;

        if (!sessionId) {
            return res.status(400).json({ error: 'sessionId is required in the request body' });
        }

        // Retrieve payment status from Stripe
        const session = await stripe.checkout.sessions.retrieve(sessionId);
        const paymentStatus = session.payment_status;
        console.log("lko", paymentStatus)

        const paymentData = await PaymentHistory.findOneAndUpdate(
            { "session.id": sessionId },
            { $set: { "session.payment_status": paymentStatus } },
            { new: true }
        );

        if (!paymentData) {
            return res.status(404).json({ error: 'Payment data not found' });
        }

        res.json({ sessionId, paymentStatus, paymentData });
    } catch (error) {
        console.error('Error retrieving payment information:', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};
const getInvoiceData = async (req, res) => {
    try {
        // Extract restaurant ID from request parameters
        const restaurantId = req.params.restaurant_id;

        // Find the restaurant based on the provided ID
        const restaurant = await Restaurant.findById(restaurantId);

        // If restaurant not found, return error response
        if (!restaurant) {
            return res.status(404).json({ error: "Restaurant not found" });
        }

        // Find the admin associated with the restaurant
        const admin = await Admin.findById(restaurant.admin_id);

        // Construct invoice data object
        const invoiceData = {
            restaurant: {
                _id: restaurant._id,
                restaurantName: restaurant.restaurantName,
                address: restaurant.address,
                // Add other restaurant details as needed
            },
            admin: {
                _id: admin._id,
                firstname: admin.firstname,
                lastname: admin.lastname,
                email: admin.email,
                mobile: admin.mobile,
                gender: admin.gender,
                // Add other admin details as needed
            },
            // Fetch payment history data based on the restaurant ID
            paymentHistory: await PaymentHistory.find({ restaurantId: restaurant._id })
        };

        // Return invoice data in the response
        res.status(200).json({ invoiceData });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
};
const getRestaurantsWithoutOrders = async (req, res) => {
    try {
        // Find all restaurants
        const restaurants = await Restaurant.find();

        if (!restaurants || restaurants.length === 0) {
            return res.status(404).json({ message: "No restaurants found" });
        }

        // Retrieve restaurant IDs with orders
        const restaurantIdsWithOrders = await FoodOrder.distinct("restaurant_id");

        // Filter out restaurants with orders
        const restaurantsWithoutOrders = restaurants.filter(restaurant => !restaurantIdsWithOrders.includes(restaurant._id.toString()));

        // Calculate number of days without orders for each restaurant
        const restaurantsWithDaysWithoutOrders = await Promise.all(restaurantsWithoutOrders.map(async restaurant => {
            // Find the last order date for the restaurant
            const lastOrder = await FoodOrder.findOne({ restaurant_id: restaurant._id }).sort({ created_at: -1 }).select("created_at");

            // If there are no orders, set lastOrderDate to null
            const lastOrderDate = lastOrder ? lastOrder.created_at : null;

            // Calculate the number of days without orders
            const daysWithoutOrders = lastOrderDate ? Math.floor((new Date() - lastOrderDate) / (1000 * 60 * 60 * 24)) : null;

            // Format the output message
            const message = daysWithoutOrders ? `No order for ${daysWithoutOrders} days` : "No orders";

            return {
                restaurant: restaurant,
                message: message
            };
        }));

        res.status(200).json({ restaurantsWithDaysWithoutOrders });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error fetching data", error: error.message });
    }
};

// const subscriptionReport = async (_req, res) => {
//     try {
//         const getRestaurants = await Restaurant.find({});
//         const restaurantDetails = [];

//         for (const restaurant of getRestaurants) {
//             const getSubscriptions = await PaymentHistory.find({
//                 $or: [{ SubscriperId: restaurant.admin_id }, { SubscriperId: restaurant.superadminId }]
//             });

//             for (const subscription of getSubscriptions) {
//                 const reportInfo = {
//                     restaurantId: restaurant._id,
//                     restaurantName: restaurant.restaurantName,
//                     planStatus: subscription.plan.active,
//                     subScriptionPlan: subscription.plan.nickname,
//                     commissionRate: subscription.plan.metadata.commission_percentage,
//                     numberOfUser: subscription.plan.metadata.max_users,
//                     numberOfRestaurant: subscription.plan.metadata.max_restaurants,
//                     planAmount: subscription.plan.amount,
//                     dueDate: subscription.expiryDate,
//                 };
//                 restaurantDetails.push(reportInfo);
//             }
//         }
//         res.status(200).json({ message: "Total subscription and commission reports", restaurantDetails });
//     } catch (error) {
//         console.log(error);
//         res.status(500).json({ message: "internal server error" });
//     }
// };
const subscriptionReport = async (_req, res) => {
    try {
        const getRestaurants = await Restaurant.find({});
        const restaurantDetails = [];

        for (const restaurant of getRestaurants) {
            // Fetch admin details for the restaurant
            const admin = await Admin.findById(restaurant.admin_id);
            if (!admin) {
                console.log(`Admin not found for restaurant: ${restaurant.restaurantName}`);
                continue; // Skip this restaurant if admin details are not found
            }

            const getSubscriptions = await PaymentHistory.find({
                $or: [{ SubscriperId: restaurant.admin_id }, { SubscriperId: restaurant.superadminId }]
            });

            for (const subscription of getSubscriptions) {
                const reportInfo = {
                    restaurantId: restaurant._id,
                    restaurantName: restaurant.restaurantName,
                    adminID: admin._id,
                    planStatus: subscription.plan.active,
                    subScriptionPlan: subscription.plan.nickname,
                    commissionRate: subscription.plan.metadata.commission_percentage,
                    numberOfUser: subscription.plan.metadata.max_users,
                    numberOfRestaurant: subscription.plan.metadata.max_restaurants,
                    planAmount: subscription.plan.amount,
                    dueDate: subscription.expiryDate,
                };
                restaurantDetails.push(reportInfo);
            }
        }
        res.status(200).json({ message: "Total subscription and commission reports", restaurantDetails });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "internal server error" });
    }
};

const getFilteredData = async (req, res) => {
    try {
        const { filter } = req.query;

        if (!filter) {
            const allData = await FoodOrder.find();
            const totalOrderCount = allData.length;
            const totalActiveUsersCreatedAt = await Admin.countDocuments({ created_at: { $ne: null } });

            return res.status(200).json({
                totalOrderCount,
                totalActiveUsersCreatedAt
            });
        }

        let startDate, endDate;

        switch (filter) {
            case 'thisWeek':
                const today = new Date();
                const dayOfWeek = today.getDay();
                const startOfWeek = new Date(today);
                startOfWeek.setDate(today.getDate() - dayOfWeek);
                startOfWeek.setHours(0, 0, 0, 0);
                startDate = startOfWeek;
                endDate = new Date(today);
                endDate.setHours(23, 59, 59, 999);
                break;
            case 'today':
                startDate = new Date();
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                endDate.setHours(23, 59, 59, 999);
                break;
            case 'thisMonth':
                startDate = new Date();
                startDate.setDate(1);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                endDate.setMonth(startDate.getMonth() + 1);
                endDate.setDate(0);
                endDate.setHours(23, 59, 59, 999);
                break;
            default:
                return res.status(400).json({ message: 'Invalid filter option' });
        }

        const query = {
            createdAt: {
                $gte: startDate,
                $lte: endDate
            }
        };

        const filteredData = await FoodOrder.find(query);
        const totalOrderCount = filteredData.length;
        const totalActiveUsersCreatedAt = await Admin.countDocuments({
            created_at: {
                $gte: startDate,
                $lte: endDate
            }
        });

        res.status(200).json({
            totalOrderCount,
            totalActiveUsersCreatedAt
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching data', error: error.message });
    }
};
// Controller for changing password
const changepassword = async (req, res) => {
    try {
        const superadminId = req.user;
        const { adminId, newPassword } = req.body;

        // Find the admin by ID
        const admin = await Admin.findById(adminId);
        if (!admin) {
            return res.status(404).json({ message: 'Admin not found' });
        }

        // Check if the superadmin ID from the token matches the superadmin ID associated with the admin
        // if (admin.superadminId.toString() !== req.superadminId) {
        //     return res.status(403).json({ message: 'Forbidden: You do not have permission to change this admin\'s password' });
        // }

        // Hash the new password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(newPassword, salt);

        // Update the admin's password
        admin.password = hashedPassword;
        await admin.save();

        // Send an email to the admin with the new password
        const subject = 'Your password has been changed';
        const text = `Hello ${admin.firstname},\n\nYour password has been successfully changed to: ${newPassword}\n
        \nIf you did not request this change, please contact support immediately.\n\nBest regards,\nYour SuperAdmin Team`;
        await mailService.sendEmail(admin.email, subject, text);

        res.status(200).json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
// Controller to get all payment history with restaurant and admin details
const adminpaymenthistory = async (req, res) => {
    try {
        // Extract restaurant name from query parameters
        const { restaurantName } = req.query;

        // If restaurantName is provided, find the restaurant by name
        let restaurant = null;
        if (restaurantName) {
            restaurant = await Restaurant.findOne({ restaurantName: restaurantName });
            if (!restaurant) {
                return res.status(404).json({ message: 'Restaurant not found' });
            }
        }

        // If restaurantName is not provided, fetch all payment history records
        // Otherwise, fetch payment history records for the specified restaurant
        const query = restaurant ? { restaurantId: restaurant._id } : {};
        const paymentHistories = await PaymentHistory.find(query).populate('restaurantId');

        // For each payment history, fetch the associated restaurant and admin details
        const paymentHistoriesWithDetails = await Promise.all(paymentHistories.map(async (paymentHistory) => {
            // Check if restaurantId is populated and not null
            if (!paymentHistory.restaurantId) {
                return null; // Skip this payment history if restaurantId is not populated
            }

            // Fetch restaurant details
            const restaurantDetails = await Restaurant.findById(paymentHistory.restaurantId);
            if (!restaurantDetails) {
                return null; // Skip this payment history if restaurantDetails is not found
            }

            // Check if admin_id is present in restaurantDetails
            if (!restaurantDetails.admin_id) {
                return null; // Skip this payment history if admin_id is not present
            }

            // Fetch admin details
            const admin = await Admin.findById(restaurantDetails.admin_id);
            if (!admin) {
                return null; // Skip this payment history if admin details are not found
            }

            // Return the payment history with restaurant and admin details
            return {
                restaurantName: restaurantDetails.restaurantName,
                adminFirstName: admin.firstname,
                planName: paymentHistory.plan.nickname,
                invoiceNumber: paymentHistory.plan.invoiceNumber,
                totalAmount: paymentHistory.totalAmount,
                paymentStatus: paymentHistory.plan.active,
                dateAndTime: paymentHistory.plan.created_at,
            };
        }));

        // Filter out null values from paymentHistoriesWithDetails
        const filteredPaymentHistories = paymentHistoriesWithDetails.filter(history => history !== null);

        res.status(200).json({ paymentHistories: filteredPaymentHistories });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
};




module.exports = {
    login,
    changepassword,
    resetPassword,
    requestPasswordReset,
    createadmin,
    createrestaurantbysuperaadmin,
    updateAdminStatus,
    getAdminsAndRestaurants,
    createMenuItem,
    getRestaurantsForSuperAdmin,
    getAllorders,
    getAllOrdersForRestaurant,
    getClientInformation,
    updateRestaurantBySuperadmin,
    createSubscription,
    updateSubscription,
    getProductionPlans,
    paymenyInfo,
    getAllPlans,
    subscriptionPayment,
    getPaymentInfosuperadmin,
    getInvoiceData,
    getRestaurantsWithoutOrders,
    subscriptionReport,
    getFilteredData,
    adminpaymenthistory,
};