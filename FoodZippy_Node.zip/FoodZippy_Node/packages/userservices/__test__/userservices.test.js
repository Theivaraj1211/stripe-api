const chai = require('chai');
const chaiHttp = require('chai-http');
const { describe, it } = require('mocha');
const app = require('../app'); // replace with your actual app instance

chai.use(chaiHttp);
const { expect } = chai;

describe('Login API', () => {
    it('should return a valid token on successful login', (done) => {
        chai.request(app)
            .post('/api/v1/user/login')
            .send({ mobile: { countryCode: '91', phoneNumber: '9500312421' } })
            .end((err, res) => {
                expect(res).to.have.status(200);
                expect(res.body).to.have.property('message').to.equal('OTP sent successfully');
                expect(res.body).to.have.property('data').to.have.property('token').to.be.a('string');
                done();
            });
    });

    it('should handle user not found', (done) => {
        chai.request(app)
            .post('/api/v1/user/login')
            .send({ mobile: { countryCode: 'nonExistingCountryCode', phoneNumber: 'nonExistingPhoneNumber' } })
            .end((err, res) => {
                expect(res).to.have.status(204);
                expect(res.body).to.have.property('message').to.equal('User not found');
                done();
            });
    });

    // Add more test cases for other scenarios
});
