const SuperAdmin = require('../../common/model/superAdminSchema');
const { verifyToken } = require('./authMiddleware');
const apiResponse = require('../middleware/apiResponse');
const requiresuperAdminAuth = async (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
        return apiResponse.unauthorizedResponse(res, 'Unauthorized. Token not provided.')
    }

    const decodedUser = verifyToken(token);

    if (decodedUser) {
        try {
            const { id } = decodedUser;
            const superadmin = await SuperAdmin.findById(id);

            if (!superadmin) {
                return apiResponse.validationError(res, 'Unauthorized. superAdmin not found.')
            }

            req.user = superadmin;
            next();
        } catch (err) {
            return apiResponse.serverErrorResponse(res, err.message);
        }
    } else {
        return apiResponse.unauthorizedResponse(res, 'Unauthorized. Invalid token or token has expired.');
    }
};1

module.exports = { requiresuperAdminAuth }