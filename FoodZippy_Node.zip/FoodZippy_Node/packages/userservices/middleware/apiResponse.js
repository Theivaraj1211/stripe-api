exports.getApiResponse = function (res, msg, data) {
    var resData = {
        status: 1,
        message: msg,
        result: data
    };
    return res.status(200).json(resData);
};

exports.dataFoundResponse = function (res, msg) {
    var resData = {
        status: 0,
        message: msg
    };
    return res.status(204).json(resData);
};
exports.dataNotFoundResponse = function (res, msg) {
    var resData = {
        status: 0,
        message: msg
    };
    return res.status(204).json(resData);
};

exports.saveApiResponseWithData = function (res, msg, data) {
    var resData = {
        status: 1,
        message: msg,
        result: data
    };
    return res.status(201).json(resData);
};

exports.saveApiResponseWithNoData = function (res, msg) {
    var resData = {
        status: 1,
        message: msg
    };
    return res.status(201).json(resData);
};

exports.updateApiResponseWithData = function (res, msg, data) {
    var resData = {
        status: 1,
        message: msg,
        result: data
    };
    return res.status(201).json(resData);
};

exports.updateApiResponseWithNoData = function (res, msg) {
    var resData = {
        status: 1,
        message: msg
    };
    return res.status(201).json(resData);
};

exports.validationError = function (res, msg) {
    var resData = {
        status: 0,
        message: msg
    };
    return res.status(400).json(resData);
};

exports.unauthorizedResponse = function (res, msg) {
    var data = {
        status: 0,
        message: msg,
    };
    return res.status(401).json(data);
};


exports.serverErrorResponse = function (res, msg) {
    var data = {
        status: 0,
        message: msg ? msg : 'Something Went Wrong',
    };
    return res.status(500).json(data);
};
