const deliveryBoySchema = require('../../common/model/deliverypersonSchema');
const { verifyToken } = require('./authMiddleware');
const apiResponse = require('./apiResponse')

const requireDeliveryAuth = async (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
        return apiResponse.serverErrorResponse(res, 'Unauthorized. Token not provided.');
    }

    const decodedDeliveryBoy = verifyToken(token);

    if (decodedDeliveryBoy) {
        try {
            const { id } = decodedDeliveryBoy;
            const deliveryBoy = await deliveryBoySchema.findById(id);

            if (!deliveryBoy) {
                return apiResponse.validationError(res, 'Unauthorized. User not found.');
            }
            req.user = deliveryBoy;
            next();
        } catch (err) {
            return apiResponse.unauthorizedResponse(res, err.message)
        }
    } else {
        return apiResponse.serverErrorResponse(res, 'Unauthorized. Invalid token or token has expired.')
    }
};

module.exports = { requireDeliveryAuth }
