const User = require('../../common/model/userSchema');
const { verifyToken } = require('./authMiddleware');
const apiResponse = require('./apiResponse')

const requireUserAuth = async (req, res, next) => {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
        return apiResponse.serverErrorResponse(res, 'Unauthorized. Token not provided.');
    }

    const decodedUser = verifyToken(token);

    if (decodedUser) {
        try {
            const { id } = decodedUser;
            const user = await User.findById(id);

            if (!user) {
                return apiResponse.validationError(res, 'Unauthorized. User not found.');
            }
            req.user = user;
            next();
        } catch (err) {
            return apiResponse.unauthorizedResponse(res, err.message)
        }
    } else {
        return apiResponse.serverErrorResponse(res, 'Unauthorized. Invalid token or token has expired.')
    }
};

module.exports = { requireUserAuth }
