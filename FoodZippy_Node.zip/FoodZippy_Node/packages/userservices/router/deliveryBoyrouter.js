const express = require("express");
const router = express.Router();
const {
    loginDeliveryBoy,
    resendOtp,
    otpVerify,
    getIncomingOrder,
    getCompletedOrders,
    getCancelOrder,
    updatedOrderPickup,
    updateCancelOrder,
    updateOrderDelivered,
    updateOnTheWay,
    updateStatus,
    getOrderDetails,
    avilableStatus,
} = require("../../userservices/controller/deliverypersonController");
const { requireDeliveryAuth } = require("../middleware/vailadateDeliveryBoyToken");
// Define routes
router.post("/login", loginDeliveryBoy);
router.post("/resend-otp", resendOtp);
router.post("/otp-verify", requireDeliveryAuth, otpVerify);
router.get("/incomingorder", requireDeliveryAuth, getIncomingOrder);
router.get("/completedorder", requireDeliveryAuth, getCompletedOrders);
router.get("/cancelOrder", requireDeliveryAuth, getCancelOrder);
router.put("/orderpickup/:id", updatedOrderPickup);
router.put("/cancelOrder/:id", updateCancelOrder);
router.put("/delivered/:id", updateOrderDelivered);
router.put("/onthewayorder/:id", updateOnTheWay);
router.put("/updatestatus/:id", updateStatus);
router.put("/avilablestatus", requireDeliveryAuth, avilableStatus);
router.get("/getOrderDetails/:orderId", requireDeliveryAuth, getOrderDetails);

module.exports = router;