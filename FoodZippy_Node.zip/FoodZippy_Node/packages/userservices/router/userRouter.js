const express = require('express');
const router = express.Router();
const upload = require('../middleware/multerConfig');
const { requireUserAuth } = require('../middleware/vaildateUserToken')
const {
    createUser,
    // getUsers,
    getUserById,
    updateUserById,
    login,
    verifyOTP,
    deleteUserById,
    resendOTP,
    updateUserWithImage,
    getUserByIdimage,
    updateAddressByUserId,
} = require('../controller/userController');
// Define routes
router.post('/', createUser);
router.post('/otpverify', requireUserAuth, verifyOTP);
router.put('/', requireUserAuth, updateUserById);
router.post('/login', login);
router.get('/', requireUserAuth, getUserById);
router.post('/resendotp', resendOTP);
//router.get('/', getUsers)
router.put('/:id', deleteUserById);
router.post('/imageupload', requireUserAuth, upload.single('image'), updateUserWithImage);
router.get('/profileimage', getUserByIdimage);
router.put('/updateaddress/:addressId', requireUserAuth, updateAddressByUserId);
//router.route('/').put(requireUserAuth,updateUserWithImage)
module.exports = router;
