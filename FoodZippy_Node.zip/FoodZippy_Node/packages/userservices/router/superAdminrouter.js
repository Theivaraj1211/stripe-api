const express = require('express');
const router = express.Router();
const { requireAdminAuth } = require("../middleware/vaildateAdminToken");
const { requiresuperAdminAuth } = require('../middleware/vaildateSuperAdminToken');
const upload = require('../middleware/multerConfig');
const {
    login, requestPasswordReset, resetPassword, createadmin, createrestaurantbysuperaadmin, updateAdminStatus, getAdminsAndRestaurants, createMenuItem,
    getAllorders,
    getAllOrdersForRestaurant,
    getRestaurantsForSuperAdmin,
    getClientInformation,
    updateRestaurantBySuperadmin,
    createSubscription,
    updateSubscription,
    getProductionPlans,
    paymenyInfo,
    getAllPlans,
    subscriptionPayment,
    getPaymentInfosuperadmin,
    getInvoiceData,
    getRestaurantsWithoutOrders,
    subscriptionReport,
    getFilteredData,
    changepassword,
    adminpaymenthistory,
} = require('../controller/superAdminController');

// Define routes
router.post('/login', login);
router.put('/changepassword', requiresuperAdminAuth, changepassword);
router.post('/forgotpassword', requestPasswordReset);
router.post('/resetpassword', requiresuperAdminAuth, resetPassword);
router.post('/createAdmin', requiresuperAdminAuth, createadmin);
router.post('/createrestaurant', requiresuperAdminAuth, upload.single('logoImage'), createrestaurantbysuperaadmin);
router.put('/admin/update-status', requiresuperAdminAuth, updateAdminStatus);
router.get('/admin/all-data', requiresuperAdminAuth, getAdminsAndRestaurants);
router.post('/createmenu', requiresuperAdminAuth, upload.single('itemImage'), createMenuItem);
router.get('/dashboard', requiresuperAdminAuth, getRestaurantsForSuperAdmin);//dashboard we need add sub/commision
router.get('/all-orders', getAllorders); //14 screen
router.get('/restaurant/orders', getAllOrdersForRestaurant); // 31 screen
router.get('/client-information/:admin_id', getClientInformation);
router.put('/update-restaurant', requiresuperAdminAuth, updateRestaurantBySuperadmin);

router.post("/createSubscription", requiresuperAdminAuth, createSubscription);
router.put("/updateSubscription/:planid", requiresuperAdminAuth, updateSubscription);
router.get("/productionplan", getProductionPlans)
router.put("/payment/:planid", requireAdminAuth, subscriptionPayment);  //admin
router.post("/payment/:planid", requiresuperAdminAuth, subscriptionPayment); // super admin
router.get("/plan/:planid/:email", paymenyInfo);
router.get("/getplans", getAllPlans);
router.get('/payment-information', getPaymentInfosuperadmin);
router.get('/invoice/:restaurant_id', getInvoiceData);
router.get('/inactive-restauarnt', getRestaurantsWithoutOrders);
router.get('/subscription-report', subscriptionReport);
router.get('/dashboard-graph', getFilteredData);
router.get('/payment-history', adminpaymenthistory);
module.exports = router;