const AWS = require('aws-sdk');
const { fromIni } = require('@aws-sdk/credential-provider-ini');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

const s3Client = new S3Client({ region: 'us-east-1', credentials: fromIni() });

AWS.config.update({
    accessKeyId: 'AKIAYCHLVC24ZI5CYC7V',
    secretAccessKey: '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',
    region: 'eu-west-2',
});
module.exports = {
    AWS,
    s3Client,
}