const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
// Load environment variables from .env file
dotenv.config();

// Function to send an email
const sendEmail = async (to, subject, text) => {
    const transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST,
        port: process.env.MAIL_PORT,
        service: 'Gmail', // Change the service provider if needed
        auth: {
            user: process.env.MAIL_USER,
            pass: process.env.MAIL_PASSWORD
        }
    });

    const mailOptions = {
        from: process.env.MAIL_USER,
        to,
        subject,
        text
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent:', info.response);
        return true;
    } catch (error) {
        console.log('Error sending email:', error);
        return false;
    }
};

module.exports = {
    sendEmail,
};
