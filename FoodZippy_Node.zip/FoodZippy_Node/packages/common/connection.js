const mongoose = require('mongoose');
const dotenv = require('dotenv');
// Load environment variables from .env file
dotenv.config();
// const connectionString = process.env.MONGODB_URI;
const username = process.env.DBUSERNAME;
const password = process.env.DBPASSWORD;
const cluster = process.env.DBCLUSTER;
const dbname = process.env.DBNAME;
//Try to connect to MongoDB.
try {
    // mongoose.connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true });
    mongoose.connect(
        `mongodb+srv://${username}:${password}@${cluster}.mongodb.net/${dbname}?retryWrites=true&w=majority`,
        {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }
    );
} catch (error) {
    // Check if the error is a MongoNetworkError.
    if (error.name === "MongoNetworkError" && error.message.includes("ECONNREFUSED")) {
        // The MongoDB server is not running.
        console.log("The MongoDB server is not running.");
    } else {
        // Something else went wrong.
        console.log(error);
    }
}
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

module.exports = db;