const mongoose = require('mongoose');

const SuperAdminSchema = new mongoose.Schema({
    email: { type: String, unique: true },
    password: { type: String },
    is_active: { type: Boolean, default: false },
    created_at: {
        type: Date,
        default: () => new Date(),
    },
    updated_at: {
        type: Date,
        default: () => new Date(),
    },
});

const SuperAdmin = mongoose.model('SuperAdmin', SuperAdminSchema);

module.exports = SuperAdmin;