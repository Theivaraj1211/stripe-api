const mongoose = require('mongoose');

const addressHistorySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  address: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Address',
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  created_at: {
    type: Date,
    default: () => new Date(),
  },
  updated_at: {
    type: Date,
    default: () => new Date(),
  },
});
addressHistorySchema.index({ location: '2dsphere' });
module.exports = mongoose.model('AddressHistory', addressHistorySchema);
