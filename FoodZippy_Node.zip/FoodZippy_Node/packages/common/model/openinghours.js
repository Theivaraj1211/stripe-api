//mongoose scheema
const mongoose = require("mongoose");

const hoursSchema = new mongoose.Schema({
    startTime: {
        type: String,
    },
    endTime: {
        type: String,
    },
    date: {
        type: Date,
        default: Date.now() + 5.5 * 60 * 60 * 1000
    },
    meridiem: {
        type: String,
        enum: ["AM", "PM"]
    },
});

const sharedHours = new mongoose.Schema(
    {
        sunday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        monday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        tuesday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        wednesday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        thursday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        friday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        saturday: {
            isHoliday: {
                type: Boolean,
                default: false,
            },
            openingHours1: hoursSchema,
            openingHours2: hoursSchema,
            deliveryHours1: hoursSchema,
            deliveryHours2: hoursSchema,
        },
        resturantId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Restaurant",
        },
        adminId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Admin",
        },
        superadminId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'SuperAdmin',
        },
    },
    {
        timestamps: true,
    }
);

sharedHours.methods.isWithinOpeningHours = function () {
    const currentTime = new Date().toLocaleTimeString("en-US", { hour12: false });
    return currentTime >= this.openingTime && currentTime <= this.closingTime;
};
const hours = mongoose.model("opening&delivery hours", sharedHours);
module.exports = hours;