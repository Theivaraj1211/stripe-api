const mongoose = require("mongoose");

const deliveryBoy = mongoose.Schema({
    name: {
        type: String
    },
    contact: {
        mobileNumber: {
            type: String
        },
        countryCode: {
            type: String
        }
    },
    profileimage: {
        data: Buffer,
        contentType: String,
    },
    profileimageURL: {
        type: String,
    },
    IdProofimage: {
        data: Buffer,
        contentType: String,
    },
    IdProofimageURL: {
        type: String,
    },
    licenseiemage: {
        data: Buffer,
        contentType: String,
    },
    licenseimageURL: {
        type: String,
    },
    is_active: {
        type: Boolean,
        default: false
    },
    otp: {
        type: Number,
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
    },
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Admin",
    },
    location: {
        lat: {
            type: Number
        },
        long: {
            type: Number
        }
    },
    address: String,
    city: String,
    state: String,
    pinCode: Number,
    createdBy: {
        type: String,
        enum: ["admin", "manager"],
        default: "admin"
    },
    updatedBy: {
        type: String,
        enum: ["admin", "manager"],
        default: "admin"
    },
    createdat: {
        type: Date,
        default: Date.now()
    },
    updatedat: {
        type: Date,
        default: Date.now()
    },
    bikeNumber: String,
    usertype: {
        type: String,
        enum: ["delivery"],
        default: "delivery"
    },
    is_deliveryStatus: {
        type: Boolean,
        default: true
    },
    governmentIssuedPhotoIdCard: {
        type: String,
    },
    is_available: {
        type: Boolean,
        default: true
    },
    email: {
        type: String,
    },
},
    {
        timestamps: true
    }
);

const delivery = mongoose.model('deliveryperson', deliveryBoy);
module.exports = delivery;
