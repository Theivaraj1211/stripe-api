const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
    email: { type: String, unique: false },
    password: { type: String },
    firstname: { type: String },
    lastname: { type: String },
    gender: { type: String },
    mobile: { type: String },
    country: { type: String },
    ipaddress: { type: String },
    is_active: { type: Boolean, default: false },
    otp: { type: String },
    otp_time_out: { type: Boolean, default: false },
    superadminId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SuperAdmin',
    },
    created_at: {
        type: Date,
        default: () => new Date(),
    },
    updated_at: {
        type: Date,
        default: () => new Date(),
    },
    tin_number: {
        type: String,
    },
    gst_number: {
        type: String,
    },
    cin_number: {
        type: String,
    },
    commission: { type: String },
    due_date: { type: Date },
});

const Admin = mongoose.model('Admin', adminSchema);

module.exports = Admin;