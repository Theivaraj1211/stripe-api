const mongoose = require("mongoose");

// Define a schema for food orders
const foodOrderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    unique: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  cart_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Addcartitem",
  },
  restaurant_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Restaurant',
  },
  delivery_id: {
    type: mongoose.Schema.Types.ObjectId,
  },
  admin_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Admin",
  },
  cash_on_delivery: {
    type: Boolean,
    default: false,
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
  status: {
    type: String,
    enum: [
      "pending",
      "accepted",
      "preparing",
      "packing",
      "pickup",
      "on the way",
      "delivered",
      "cancel",
    ],
    default: "pending",
  },
  comment: {
    type: String,
  },
  is_active: {
    type: Boolean,
    default: true,
  },
  userresponseforcancel: {
    type: String,
    enum: [
      "order taking too long",
      "place order by mistake",
      "item is not available",
      "change by mind",
      "other",
    ],
  },
  reason_for_cancel_byadmin: {
    type: String,
    enum: [
      "change in delivery address",
      "seller not able to entertain some request",
      "product is taking too long to be delivered",
      "cash not available for COD",
    ],
  },
  reason_for_cancel_byDeliveryBoy:String,
  address_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Address",
  },
  payment_id: {
    type: mongoose.Schema.Types.ObjectId,
  },
  total_amount: {
    type: Number,
  },
  created_by: {
    type: String,
  },
  updated_by: {
    type: String,
  },
  delivery_address_id: {
    type: String,
  },
  quantity: Number,
  delivery_at: {
    type: Date,
  },
  preparationTime: {
    type: String,
  }
});

// Create a FoodOrder model using the schema
const FoodOrder = mongoose.model("FoodOrder", foodOrderSchema);

module.exports = FoodOrder;
