const mongoose = require('mongoose');

const subscriptionPlanSchema = new mongoose.Schema({
    stripePlanId: { type: String }, // Stripe Plan ID
    plan_creater_id: { type: String }, // ID of the user who created the plan
    nickname: { type: String }, // Name of the plan
    interval: { type: String, enum: ['day', 'week', 'month', 'year'] }, // Interval of the plan (e.g., month, year)
    interval_count: { type: Number }, // Number of intervals
    currency: { type: String, default: 'usd' }, // Currency of the plan
    amount: { type: Number, }, // Amount of the plan (in smallest currency unit, e.g., cents)
    active: { type: Boolean, default: false }, // Whether the plan is active or not
    metadata: { // Additional metadata related to the plan
        restaurant_id: { type: mongoose.Types.ObjectId, ref: 'Restaurant' },
        max_users: { type: String }, // Maximum number of users
        max_restaurants: { type: String }, // Maximum number of restaurants
        one_time_setup_charge: { type: String }, // One-time setup charge
        commission_percentage: { type: String } // Commission percentage
    },
    product: { type: String }, // ID of the product associated with the plan
    due_date: { type: Date },
    is_default: { type: Boolean, default: true },
});

const SubscriptionPlan = mongoose.model('SubscriptionPlan', subscriptionPlanSchema);

module.exports = SubscriptionPlan;
