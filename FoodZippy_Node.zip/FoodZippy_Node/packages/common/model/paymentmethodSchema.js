const mongoose = require('mongoose');

const paymentMethodSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
    },
    orderId: {
        type: String,
        ref: 'FoodOrder',
    },
    amount: {
        type: Number,
    },
    type: {
        type: String,
        enum: [
            'card',
            'upi', // Supported in India
            'netbanking', // Supported in India
            'gpay', // Google Pay
            'phonepay', // PhonePe
            'applepay', // Apple Pay
            'other', // Add as needed
        ],
    },
    stripeCustomerId: {
        type: String,
    },
    cardDetails: {
        type: {
            cardholderName: String,
            cardNumber: String,
            expiryMonth: Number,
            expiryYear: Number,
            cvv: String,
        },
    },
    upiDetails: {
        type: {
            virtualPaymentAddress: String,
            vpaProvider: String, // Optional for storing provider name
        },
    },
    netbankingDetails: {
        type: {
            bank: String,
            accountNumber: String,
            ifscCode: String,
        },
    },
    isDefault: {
        type: Boolean,
        default: false,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    stripePaymentMethodId: {
        type: String,
    },
    // Additional fields for India-specific requirements:
    ifscCode: {
        type: String, // Required for card payments
    },
    exportPurposeCode: {
        type: String, // Required for international transactions
    },
    session_id: {
        type: String,
    },
});

module.exports = mongoose.model('PaymentMethod', paymentMethodSchema);
