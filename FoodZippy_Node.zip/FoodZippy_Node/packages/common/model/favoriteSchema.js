const mongoose = require('mongoose');

const favoriteItemSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
    },
    menu_item_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MenuItem',
    },
    is_favorite: {
        type: Boolean
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    },
    // Additional fields specific to favorite item
});

const FavoriteItem = mongoose.model('FavoriteItem', favoriteItemSchema);

module.exports = FavoriteItem;
