const mongoose = require("mongoose");

// Create a Mongoose schema directly without Joi validation
const loyaltySchema = new mongoose.Schema({
  RestaurantName: String,
  admin_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Admin",
  },
  restaurant_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Restaurant", // Reference to the Restaurant model if you have one
  },
  freeVoucherAfter: {
    type: Number,
  },
  voucherValidFor: {
    type: Number,
  },
  typeOfReward: String,
  RoundOfVoucher: String,
  campaignEnable: Boolean,
  deliveryFee: Boolean,
  automaticallyToOrder: Boolean,
  existingOrder: Boolean,
  is_Active: Boolean,
  is_freemeal: {
    type: Boolean,
    default: false,
  },
  percentageDiscount: {
    type: Boolean,
    default: false,
  },
  percentageDiscountAmount: {
    type: Number,
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
  created_by: String,
  updated_by: String,
});

// Middleware to update 'updated_at' timestamp before saving
loyaltySchema.pre("save", function (next) {
  this.updated_at = new Date();
  next();
});

// Create a Mongoose model based on the schema
const Loyalty = mongoose.model("Loyalty", loyaltySchema);

module.exports = Loyalty;
