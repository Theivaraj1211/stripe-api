const mongoose = require("mongoose");

// Define the payment history schema
const paymentHistorySchema = new mongoose.Schema(
    {
        customer: {
            type: mongoose.Schema.Types.Mixed,
        },
        SubscriperId: { type: mongoose.Types.ObjectId, ref: "Admin SuperAdmin" },
        plan: {
            type: mongoose.Schema.Types.Mixed,
        },
        totalAmount: {
            type: Number,
        },
        session: {
            type: mongoose.Schema.Types.Mixed,
        },
        restaurantId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Restaurant'
        },
        expiryDate: {
            type: Date,
        },
    },
    {
        timestamps: true,
    }
);

// Create a model from the schema
const PaymentHistory = mongoose.model("PaymentHistory", paymentHistorySchema);

module.exports = PaymentHistory;
