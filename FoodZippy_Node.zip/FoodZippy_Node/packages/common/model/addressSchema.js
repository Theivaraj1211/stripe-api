const mongoose = require('mongoose');

const addressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  type: {
    type: String,
    enum: ['home', 'work', 'hotel', 'other'], // Types of addresses
  },
  address: String,
  zipcode: String,
  buildingNumber: String,
  floorNumber: String,
  houseNumber: String,
  is_default: {
    type: Boolean,
    default: true,
  },
  is_active: {
    type: Boolean,
    default: true,
  },
  city: String,
  state: String,
  location: {
    lat: {
      type: Number,
    },
    long: {
      type: Number,
    },
  },
  created_at: {
    type: Date,
    default: () => new Date(),
  },
  updated_at: {
    type: Date,
    default: () => new Date(),
  },

});

addressSchema.index({ location: '2dsphere' });

const Address = mongoose.model('Address', addressSchema);

module.exports = Address;
