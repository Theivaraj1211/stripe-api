const mongoose = require('mongoose');

const MenuItemSchema = new mongoose.Schema({
    categoryName: String,
    itemName: String,
    itemAvailableTime: String,
    itemAvailableTimefrom: String,
    itemAvailableTimeto: String,
    preparationTime: String,
    description: String,
    itemImage: {
        data: Buffer,
        contentType: String,
    },
    itemType: {
        type: String,
        enum: ['vegetarian', 'non vegetarian', 'vegan'],
    },
    imageURL: String,
    itemPrice: Number,
    is_active: {
        type: Boolean,
        default: true,
    },
    discountPriceAvailable: Boolean,
    discountPriceAmount: Number,
    packingCharge: Number,
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Admin',
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant', // Reference to the Restaurant model if you have one
    },
    itemAvailableforluch: Boolean,
    itemAvailableforDinner: Boolean,
    itemAvailableforBreakfast: Boolean,
    additemvariant: [
        {
            category: String,
            itemName: String,
            price: Number,
            type: {
                type: String,
                enum: ['vegetarian', 'non vegetarian', 'vegan'],
            },
            isActive: Boolean,
            created_at: {
                type: Date,
                default: () => new Date(),
            },
            updated_at: {
                type: Date,
                default: () => new Date(),
            },
        },
    ],
    combo: [
        {
            comboItems: [String], // This defines comboItems as an array of strings
            is_active: {
                type: Boolean,
                default: true,
            },
            comboPrice: Number, // Price for the combo
        },
    ],
    addons: [
        {
            addonName: String,
            addonPrice: Number,
            is_active: {
                type: Boolean,
                default: true,
            },
        },
    ],
    created_at: {
        type: Date,
        default: () => new Date(),
    },
    superadminId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SuperAdmin',
    },
    updated_at: {
        type: Date,
        default: () => new Date(),
    },
});

module.exports = mongoose.model('MenuItem', MenuItemSchema);
