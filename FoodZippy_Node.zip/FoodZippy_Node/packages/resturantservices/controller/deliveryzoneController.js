const Joi = require('joi');
const DeliveryZones = require("../../common/model/deliveryzoneSchema");
const Restaurant = require('../../common/model/restaurantSchema');
const Admin = require("../../common/model/adminSchema");
const locationPointSchema = Joi.object({
    lat: Joi.number(),
    long: Joi.number(),
});

const circleDeliveryZoneSchema = Joi.object({
    userLat: Joi.number(),
    userLong: Joi.number(),
    deliveryFee: Joi.number(),
    minimumOrder: Joi.number(),
    shape: Joi.string().valid('circle'),
    is_active: Joi.boolean().default(true),
    center: Joi.object({
        latitude: Joi.number(),
        longitude: Joi.number(),
    }),
    radius: Joi.number(),
});

const customDeliveryZoneSchema = Joi.object({
    userLat: Joi.number(),
    userLong: Joi.number(),
    deliveryFee: Joi.number(),
    minimumOrder: Joi.number(),
    shape: Joi.string().valid('custom'),
    is_active: Joi.boolean().default(true),
    locationPoints: Joi.array().items(locationPointSchema),
});

const deliveryZonesSchema = Joi.object({
    deliveryZones: Joi.array().items(Joi.object({
        type: Joi.string().valid('circle', 'custom'),
        userLat: Joi.number(),
        userLong: Joi.number(),
        deliveryFee: Joi.number(),
        minimumOrder: Joi.number(),
        radius: Joi.number(),
        locationPoints: Joi.array().items(locationPointSchema),
    })),
    admin_id: Joi.string(), // Assuming you have a custom Joi extension for ObjectId validation
    restaurant_id: Joi.string(),
    superadminId: Joi.string(),
});
// const setdeliveryzone = async (req, res) => {
//     try {
//         const deliveryZonesData = req.body.deliveryZones || [];

//         if (!deliveryZonesData.length) {
//             return res.status(400).json({ error: 'No delivery zones provided' });
//         }

//         const adminId = req.user.id;
//         const savedDeliveryZones = [];

//         for (const zoneData of deliveryZonesData) {
//             const { userLat, userLong, deliveryFee, shape, locationPoints, minimumOrder } = zoneData;

//             if (!userLat || !userLong || !deliveryFee || !shape) {
//                 return res.status(400).json({ error: 'Invalid parameters in one of the delivery zones' });
//             }

//             const { restaurant_id } = req.body;
//             const admin = await Admin.findById({ _id: adminId });
//             const restaurant = await Restaurant.findById({ _id: restaurant_id });

//             if (!admin || !restaurant) {
//                 return res.status(404).json({ error: 'Admin or Restaurant not found' });
//             }

//             let deliveryZone;
//             switch (shape) {
//                 case 'circle':
//                     deliveryZone = {
//                         type: 'circle',
//                         userLat: userLat,
//                         userLong: userLong,
//                         deliveryFee: deliveryFee,
//                         minimumOrder: minimumOrder,
//                         center: {
//                             latitude: restaurant.mapLocation.lat,
//                             longitude: restaurant.mapLocation.long,
//                         },
//                         radius: deliveryFee, // Use deliveryFee directly for radius
//                     };
//                     break;
//                 case 'custom':
//                     if (!locationPoints || !Array.isArray(locationPoints) || locationPoints.length < 3) {
//                         return res.status(400).json({ error: 'Invalid location points for custom shape' });
//                     }
//                     deliveryZone = {
//                         type: 'custom',
//                         locationPoints: locationPoints,
//                     };
//                     break;
//                 default:
//                     return res.status(400).json({ error: 'Invalid shape parameter' });
//             }

//             // Save the delivery zone data into the database
//             const savedZone = await DeliveryZones.create({
//                 deliveryZones: [{
//                     type: shape,
//                     userLat: userLat,
//                     userLong: userLong,
//                     deliveryFee: deliveryFee,
//                     minimumOrder: minimumOrder,
//                     locationPoints: locationPoints,
//                 },
//                 ],
//                 admin_id: adminId,
//                 restaurant_id: restaurant._id,
//             });

//             savedDeliveryZones.push(savedZone);
//         }

//         res.json({ savedDeliveryZones });
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// }
const setdeliveryzone = async (req, res) => {
    try {
        const deliveryZonesData = req.body.deliveryZones || [];

        if (!deliveryZonesData.length) {
            return res.status(400).json({ error: 'No delivery zones provided' });
        }

        const adminId = req.user.id;
        const savedDeliveryZones = [];

        for (const zoneData of deliveryZonesData) {
            const { userLat, userLong, deliveryFee, shape, locationPoints, minimumOrder } = zoneData;

            if (!userLat || !userLong || !deliveryFee || !shape) {
                return res.status(400).json({ error: 'Invalid parameters in one of the delivery zones' });
            }

            const { restaurant_id } = req.body;
            const admin = await Admin.findById({ _id: adminId });
            const restaurant = await Restaurant.findById({ _id: restaurant_id });

            if (!admin || !restaurant) {
                return res.status(404).json({ error: 'Admin or Restaurant not found' });
            }

            let deliveryZone;

            switch (shape) {
                case 'circle':
                    deliveryZone = {
                        type: 'circle',
                        userLat: userLat,
                        userLong: userLong,
                        deliveryFee: deliveryFee,
                        minimumOrder: minimumOrder,
                        radius: deliveryFee, // Use deliveryFee directly for radius
                    };
                    break;
                case 'custom':
                    if (!locationPoints || !Array.isArray(locationPoints) || locationPoints.length < 3) {
                        return res.status(400).json({ error: 'Invalid location points for custom shape' });
                    }
                    deliveryZone = {
                        type: 'custom',
                        locationPoints: locationPoints,
                    };
                    break;
                default:
                    return res.status(400).json({ error: 'Invalid shape parameter' });
            }

            // Save the delivery zone data into the database
            const savedZone = await DeliveryZones.create({
                deliveryZones: [deliveryZone],
                admin_id: adminId,
                restaurant_id: restaurant._id,
                radius: deliveryFee,
            });

            savedDeliveryZones.push(savedZone);
        }

        // Simplify the response structure if you're only saving one zone at a time
        res.json({ savedDeliveryZone: savedDeliveryZones.length === 1 ? savedDeliveryZones[0] : savedDeliveryZones });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
const getalldeliveryzone = async (req, res) => {
    try {
        const { restaurant_id } = req.params;

        const deliveryZones = await DeliveryZones.find({ restaurant_id });

        if (!deliveryZones) {
            return res.status(404).json({ error: 'Delivery zones not found for the specified restaurant' });
        }

        res.json({ deliveryZones });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
}
const updateAndDeleteDeliveryZones = async (req, res) => {
    try {
        const { deliveryZonesData, updateAction } = req.body;

        if (!deliveryZonesData || !deliveryZonesData.length || !updateAction) {
            return res.status(400).json({ error: 'Invalid request parameters' });
        }

        const adminId = req.user.id;
        const savedDeliveryZones = [];

        for (const zoneData of deliveryZonesData) {
            const { zoneId, userLat, userLong, deliveryFee, shape, locationPoints, minimumOrder } = zoneData;

            if (!userLat || !userLong || !deliveryFee || !shape) {
                return res.status(400).json({ error: 'Invalid parameters in one of the delivery zones' });
            }

            const { restaurant_id } = req.body;
            const admin = await Admin.findById({ _id: adminId });
            const restaurant = await Restaurant.findById({ _id: restaurant_id });

            if (!admin || !restaurant) {
                return res.status(404).json({ error: 'Admin or Restaurant not found' });
            }

            let deliveryZone;
            switch (shape) {
                case 'circle':
                    deliveryZone = {
                        type: 'Circle',
                        center: { latitude: restaurant.mapLocation.lat, longitude: restaurant.mapLocation.long },
                        radius: deliveryFee * 1000,
                    };
                    break;
                case 'custom':
                    if (!locationPoints || !Array.isArray(locationPoints) || locationPoints.length < 3) {
                        return res.status(400).json({ error: 'Invalid location points for custom shape' });
                    }
                    deliveryZone = locationPoints.map((point) => {
                        return { latitude: point.lat, longitude: point.long };
                    });
                    break;
                default:
                    return res.status(400).json({ error: 'Invalid shape parameter' });
            }

            // Perform update or delete based on the updateAction
            let savedZone;
            if (updateAction === 'update') {
                // Update existing delivery zone
                savedZone = await DeliveryZones.findByIdAndUpdate(
                    zoneId,
                    {
                        $set: {
                            deliveryZones: [
                                {
                                    type: shape,
                                    userLat: userLat,
                                    userLong: userLong,
                                    deliveryFee: deliveryFee,
                                    minimumOrder: minimumOrder,
                                    locationPoints: locationPoints,
                                },
                            ],
                        },
                    },
                    { new: true }
                );
            } else if (updateAction === 'delete') {
                // Delete existing delivery zone
                savedZone = await DeliveryZones.findByIdAndDelete(zoneId);
            } else {
                return res.status(400).json({ error: 'Invalid updateAction parameter' });
            }

            savedDeliveryZones.push(savedZone);
        }

        res.json({ savedDeliveryZones });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
};
const setdeliveryzonebyadmin = async (req, res) => {
    try {
        const superAdminId = req.user;
        const deliveryZonesData = req.body.deliveryZones || [];
        const adminId = req.body.adminId; // Assuming adminId is provided in the request body

        if (!adminId) {
            return res.status(400).json({ error: 'Admin ID is required' });
        }

        if (!deliveryZonesData.length) {
            return res.status(400).json({ error: 'No delivery zones provided' });
        }

        const savedDeliveryZones = [];

        for (const zoneData of deliveryZonesData) {
            const { userLat, userLong, deliveryFee, shape, locationPoints, minimumOrder } = zoneData;

            if (!userLat || !userLong || !deliveryFee || !shape) {
                return res.status(400).json({ error: 'Invalid parameters in one of the delivery zones' });
            }

            const { restaurant_id } = req.body;
            const admin = await Admin.findById({ _id: adminId });
            console.log(admin, "admin");
            const restaurant = await Restaurant.findById({ _id: restaurant_id });
            console.log(restaurant, "restaurant");
            if (!admin || !restaurant) {
                return res.status(404).json({ error: 'Admin or Restaurant not found' });
            }

            let deliveryZone;

            switch (shape) {
                case 'circle':
                    deliveryZone = {
                        type: 'circle',
                        userLat: userLat,
                        userLong: userLong,
                        deliveryFee: deliveryFee,
                        minimumOrder: minimumOrder,
                        radius: deliveryFee, // Use deliveryFee directly for radius
                    };
                    break;
                case 'custom':
                    if (!locationPoints || !Array.isArray(locationPoints) || locationPoints.length < 3) {
                        return res.status(400).json({ error: 'Invalid location points for custom shape' });
                    }
                    deliveryZone = {
                        type: 'custom',
                        locationPoints: locationPoints,
                    };
                    break;
                default:
                    return res.status(400).json({ error: 'Invalid shape parameter' });
            }

            // Save the delivery zone data into the database
            const savedZone = await DeliveryZones.create({
                deliveryZones: [deliveryZone],
                admin_id: adminId,
                restaurant_id: restaurant._id,
                radius: deliveryFee,
                superadminId: superAdminId,
            });

            savedDeliveryZones.push(savedZone);
        }

        // Simplify the response structure if you're only saving one zone at a time
        res.json({ savedDeliveryZone: savedDeliveryZones.length === 1 ? savedDeliveryZones[0] : savedDeliveryZones });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

module.exports = {
    setdeliveryzone,
    getalldeliveryzone,
    updateAndDeleteDeliveryZones,
    setdeliveryzonebyadmin,
}