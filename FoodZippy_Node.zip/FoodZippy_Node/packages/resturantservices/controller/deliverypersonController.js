const Joi = require("joi");
const delivery = require("../../common/model/deliverypersonSchema")
const deliveryBoySchema = Joi.object({
    name: Joi.string(),
    contact: Joi.object({
        mobileNumber: Joi.string(),
        countryCode: Joi.string(),
    }),
    profileimage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    profileimageURL: Joi.string(),
    IdProofimage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    IdProofimageURL: Joi.string(),
    licenseiemage: Joi.object({
        data: Joi.binary(),
        contentType: Joi.string(),
    }),
    licenseimageURL: Joi.string(),
    is_active: Joi.boolean().default(true),
    otp: Joi.number(),
    restaurant_id: Joi.string(),
    admin_id: Joi.string(),
    location: Joi.object({
        lat: Joi.number(),
        long: Joi.number(),
    }),
    address: Joi.string(),
    city: Joi.string(),
    state: Joi.string(),
    pinCode: Joi.number(),
    createdBy: Joi.string().valid('admin', 'manager').default('admin'),
    updatedBy: Joi.string().valid('admin', 'manager').default('admin'),
    createdat: Joi.date(),
    updatedat: Joi.date(),
    bikeNumber: Joi.string(),
    usertype: Joi.string().valid('delivery').default('delivery'),
    is_deliveryStatus: Joi.boolean().default(true),
    governmentIssuedPhotoIdCard: Joi.string(),
    is_available: Joi.boolean().default(true),
    email: Joi.string(),
});
const createDeliveryperson = async (req, res) => {
    try {
        const adminId = req.user.id; // Assuming req.user.id contains the admin's ID from the token

        const { error, value } = deliveryBoySchema.validate({ ...req.body });
        const restaurantId = req.body.restaurant_id;
        if (error) {
            return res.status(400).json({ message: "Request body error", error });
        }

        // Check if a delivery person with the provided mobile number already exists
        const existingDelivery = await delivery.findOne({ 'contact.mobileNumber': value.contact && value.contact.mobileNumber });

        if (existingDelivery) {
            existingDelivery.set({
                ...value,
                admin_id: adminId // Set admin_id to the new data
            });

            // Handle image uploads
            if (req.files) {
                // Assuming multer has stored the files in req.files
                if (req.files['profileImage']) {
                    existingDelivery.profileImage = {
                        data: req.files['profileImage'][0].buffer,
                        contentType: req.files['profileImage'][0].mimetype,
                    };
                    existingDelivery.profileimageURL = `${req.protocol}://${req.get("host")}/uploads/${req.files['profileImage'][0].filename}`;
                }

                if (req.files['idProofImage']) {
                    existingDelivery.idProofImage = {
                        data: req.files['idProofImage'][0].buffer,
                        contentType: req.files['idProofImage'][0].mimetype,
                    };
                    existingDelivery.IdProofimageURL = `${req.protocol}://${req.get("host")}/uploads/${req.files['idProofImage'][0].filename}`;
                }

                if (req.files['licenseImage']) {
                    existingDelivery.licenseImage = {
                        data: req.files['licenseImage'][0].buffer,
                        contentType: req.files['licenseImage'][0].mimetype,
                    };
                    existingDelivery.licenseimageURL = `${req.protocol}://${req.get("host")}/uploads/${req.files['licenseImage'][0].filename}`;
                }
            }
            const updatedDelivery = await existingDelivery.save();
            const { profileImageUrl, idProofImageUrl, licenseImageUrl, ...deliveryData } = updatedDelivery.toObject();

            return res.status(200).json({
                message: "Delivery person updated",
                delivery: { ...deliveryData, profileImageUrl, idProofImageUrl, licenseImageUrl },
                admin_id: adminId
            });
        }

        // If no existing delivery person found, create a new one
        const newDelivery = new delivery({
            ...value,
            admin_id: adminId,// Set admin_id for the new delivery person
            restaurant_id: restaurantId,
        });

        // Handle image uploads
        if (req.files) {
            // Assuming multer has stored the files in req.files
            if (req.files['profileImage']) {
                newDelivery.profileImage = {
                    data: req.files['profileImage'][0].buffer,
                    contentType: req.files['profileImage'][0].mimetype,
                };
                newDelivery.profileImageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.files['profileImage'][0].filename}`;
            }

            if (req.files['idProofImage']) {
                newDelivery.idProofImage = {
                    data: req.files['idProofImage'][0].buffer,
                    contentType: req.files['idProofImage'][0].mimetype,
                };
                newDelivery.idProofImageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.files['idProofImage'][0].filename}`;
            }

            if (req.files['licenseImage']) {
                newDelivery.licenseImage = {
                    data: req.files['licenseImage'][0].buffer,
                    contentType: req.files['licenseImage'][0].mimetype,
                };
                newDelivery.licenseImageUrl = `${req.protocol}://${req.get("host")}/uploads/${req.files['licenseImage'][0].filename}`;
            }
        }

        const savedDelivery = await newDelivery.save();
        const { profileImageUrl, idProofImageUrl, licenseImageUrl, ...deliveryData } = savedDelivery.toObject();

        return res.status(201).json({
            message: "Delivery person created",
            delivery: { ...deliveryData, profileImageUrl, idProofImageUrl, licenseImageUrl },
            admin_id: adminId,
            restaurant_id: restaurantId,
        });
    } catch (error) {
        console.error("Error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};
const updateDeliveryPerson = async (req, res) => {
    try {
        const adminId = req.user.id; // Assuming req.user.id contains the admin's ID from the token
        const deliveryPersonId = req.params.id; // Assuming the delivery person ID is passed in the request parameters

        const { error, value } = deliveryBoyValidationSchema.validate({ ...req.body });

        if (error) {
            return res.status(400).json({ message: "Request body error", error });
        }

        // Check if the delivery person exists
        const existingDelivery = await delivery.findById(deliveryPersonId);

        if (!existingDelivery) {
            return res.status(404).json({ message: 'Delivery person not found' });
        }

        // Check if the provided mobile number already exists for another delivery person
        const deliveryWithSameMobileNumber = await delivery.findOne({ 'contact.mobileNumber': value.contact.mobileNumber });

        if (deliveryWithSameMobileNumber && deliveryWithSameMobileNumber._id.toString() !== deliveryPersonId) {
            return res.status(409).json({ message: 'Mobile number is already associated with another delivery person' });
        }

        // Update the existing delivery person with the new data
        existingDelivery.set({
            ...value,
            admin_id: adminId // Set admin_id to the new data
        });

        const updatedDelivery = await existingDelivery.save();
        return res.status(200).json({ message: "Delivery person updated", delivery: updatedDelivery, admin_id: adminId });
    } catch (error) {
        console.error("Error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};
const getAllDeliveryPersonsByRestaurantId = async (req, res) => {
    try {
        const restaurantId = req.params.id; // Assuming the restaurant_id is passed as a parameter

        // Retrieve all delivery persons based on the provided restaurant_id
        const deliveryPersons = await delivery.find({ restaurant_id: restaurantId });

        if (!deliveryPersons || deliveryPersons.length === 0) {
            return res.status(404).json({ message: 'No delivery persons found for the restaurant' });
        }

        return res.status(200).json({ message: "Delivery persons found", deliveryPersons });
    } catch (error) {
        console.error("Error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

module.exports = {
    createDeliveryperson,
    updateDeliveryPerson,
    getAllDeliveryPersonsByRestaurantId,
}