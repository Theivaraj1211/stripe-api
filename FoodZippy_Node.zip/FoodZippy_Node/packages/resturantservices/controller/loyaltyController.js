const Joi = require("joi");
const Loyalty = require("../../common/model/loyaltySchema");
const Restaurant = require("../../common/model/restaurantSchema");
const Retention = require("../../common/model/retentionSchema");
const retentionValidationSchema = Joi.object({
  restaurant_id: Joi.string(),
  admin_id: Joi.string(),
  discountCode: Joi.string(),
  amountOfDiscount: Joi.string(),
  voucherValid: Joi.string(),
  campaignEnable: Joi.boolean(),
  deliveryfee: Joi.boolean(),
  automaticOrder: Joi.boolean(),
  is_Active: Joi.boolean(),
  created_by: Joi.string(),
  updated_by: Joi.string(),
});
const loyaltyValidationSchema = Joi.object({
  RestaurantName: Joi.string(),
  admin_id: Joi.string(),
  restaurant_id: Joi.string(),
  freeVoucherAfter: Joi.number(),
  voucherValidFor: Joi.number(),
  typeOfReward: Joi.string(),
  RoundOfVoucher: Joi.string(),
  campaignEnable: Joi.boolean(),
  deliveryFee: Joi.boolean(),
  automaticallyToOrder: Joi.boolean(),
  existingOrder: Joi.boolean(),
  is_Active: Joi.boolean(),
  is_freemeal: Joi.boolean(),
  percentageDiscount: Joi.boolean(),
  percentageDiscountAmount: Joi.number(),
  created_by: Joi.string(),
  updated_by: Joi.string(),
});
const createloyalty = async (req, res) => {
  try {
    const adminId = req.user.id;
    const { restaurant_id } = req.body; // Assuming the restaurant_id is provided in the request body

    // Fetch the ResturentName based on restaurant_id (this can be an asynchronous operation)
    const restaurant = await Restaurant.findById(restaurant_id); // Replace Restaurant with your actual model

    // if (!restaurant) {
    //   return res.status(404).json({ error: "Restaurant not found" });
    // }

    const defaultCreatedBy = "admin"; // Default value for created_by and updated_by fields

    const { error, value } = loyaltyValidationSchema.validate(req.body);

    if (error) {
      return res
        .status(400)
        .json({ error: error.details.map((err) => err.message) });
    }

    // Assign admin_id from token to the value object
    value.admin_id = adminId;
    value.created_by = defaultCreatedBy;
    value.updated_by = defaultCreatedBy;
    value.RestaurantName = restaurant.restaurantName; // Assuming the property name in the Restaurant model is RestaurantName

    // Create new Loyalty instance based on validated data
    const loyalty = new Loyalty(value);

    // Save Loyalty data to the database
    await loyalty.save();

    return res
      .status(201)
      .json({ message: "Loyalty created successfully", loyalty });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};
const createRetention = async (req, res) => {
  try {
    const adminId = req.user.id;
    // const restaurantId = req.body;
    const { error, value } = retentionValidationSchema.validate(req.body, {
      abortEarly: false,
    });
    // const restaurant = await Restaurant.findById(restaurant_id);

    // if (!restaurant) {
    //   return res.status(404).json({ error: "Restaurant not found" });
    // }
    if (error) {
      return res
        .status(400)
        .json({ error: error.details.map((err) => err.message) });
    }
    value.admin_id = adminId;
    //value.restaurant_id = restaurantId;
    // Set default values for created_by and updated_by
    value.created_by = value.created_by || "admin";
    value.updated_by = value.updated_by || "admin";

    const retention = new Retention(value);
    await retention.save();
    return res
      .status(201)
      .json({ message: "Retention created successfully", retention });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};
const getallloyaltyrestaurantId = async (req, res) => {
  try {
    const { restaurant_id } = req.params; // Assuming the restaurant_id is provided as a route parameter
    // Validate restaurant_id using Joi
    const { error: validationError } = loyaltyValidationSchema.validate({
      restaurant_id,
    });

    if (validationError) {
      return res.status(400).json({ error: validationError.details.map(err => err.message) });
    }

    // Fetch all Loyalty instances based on the provided restaurant_id
    const loyaltyData = await Loyalty.find({ restaurant_id });

    if (!loyaltyData || loyaltyData.length === 0) {
      return res.status(404).json({ error: "No loyalty data found for this restaurant" });
    }

    return res.status(200).json({ loyaltyData });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};
const getallretention = async (req, res) => {
  try {
    const { restaurant_id } = req.params; // Assuming the restaurant_id is provided as a route parameter

    // Validate restaurant_id using Joi
    const { error: validationError } = retentionValidationSchema.validate({
      restaurant_id,
    });

    if (validationError) {
      return res.status(400).json({ error: validationError.details.map(err => err.message) });
    }

    // Fetch all retention data based on the provided restaurant_id
    const retentionData = await Retention.find({ restaurant_id });

    if (!retentionData || retentionData.length === 0) {
      return res.status(404).json({ error: "No retention data found for this restaurant" });
    }

    return res.status(200).json({ retentionData });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
};
module.exports = { createloyalty, createRetention, getallloyaltyrestaurantId, getallretention };
