const Joi = require("joi");
const openingHours = require("../../common/model/openinghours");
const Restaurant = require("../../common/model/restaurantSchema");
//joi validation
//opening hours 70
const hoursSchemaJoi = Joi.object({
    startTime: Joi.string(),
    endTime: Joi.string(),
    date: Joi.date(),
    meridiem: Joi.string().valid('AM', 'PM').required()
});

// Joi validation schema for sharedHours
const openinghoursjoi = Joi.object({
    sunday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    monday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    tuesday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    wednesday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    thursday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    friday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    saturday: Joi.object({
        isHoliday: Joi.boolean().default(false),
        openingHours1: hoursSchemaJoi,
        openingHours2: hoursSchemaJoi,
        deliveryHours1: hoursSchemaJoi,
        deliveryHours2: hoursSchemaJoi
    }),
    resturantId: Joi.string(),
    adminId: Joi.string(),
    superadminId: Joi.string(),
});

///////opening hours post/////////////

const openinghour = async (req, res) => {
    const admin_id = req.user.id;
    if (!admin_id) {
        res.status(404).json({ message: "kindly provied json token" });
    }
    try {
        const resturant = await Restaurant.findOne({ admin_id });
        if (!resturant) {
            res
                .status(400)
                .json({ message: "resturnat id not found on specific token" });
        }
        const { error, value } = openinghoursjoi.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        const hours = await openingHours({
            ...req.body,
            adminId: admin_id,
            resturantId: resturant._id,
        });
        const newhours = await openingHours.create(hours);
        newhours.save();
        res.status(200).json({ message: "hours display completed", newhours });
    } catch (error) {
        console.log("error", e);
        res.status(500).json({ message: "interbal server error", e });
    }
};

//////openingHours put ////////

const updateOpeningHours = async (req, res) => {
    const adminid = req.user.id;

    try {
        // Find restaurant by admin_id
        const restaurant = await Restaurant.findOne({ admin_id: adminid });
        if (!restaurant) {
            return res.status(400).json({ message: "Restaurant ID not found." });
        }
        const restaurantId = restaurant._id;

        // Validate the request body using Joi schema
        const { error } = openinghoursjoi.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }

        // Update opening hours
        const updateHours = await openingHours.findByIdAndUpdate(
            req.params.id,
            { ...req.body, adminid, restaurantId: restaurantId },
            { new: true }
        );

        if (!updateHours) {
            return res.status(404).json({ message: "Opening hours not available." });
        }

        res.status(201).json({ message: "Update completed.", updateHours });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal server error." });
    }
};

const openinghourbyadmin = async (req, res) => {
    try {
        const superAdminId = req.user; // Assuming the token is passed in the Authorization header
        const adminId = req.body.adminId;

        if (!adminId) {
            res.status(400).json({ message: "Admin ID is required in the request body" });
            return;
        }

        const resturant = await Restaurant.findOne({ admin_id: adminId });
        if (!resturant) {
            res.status(400).json({ message: "Restaurant ID not found for the provided admin ID" });
            return;
        }

        const { error, value } = openinghoursjoi.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }

        const hours = await openingHours({
            ...req.body,
            adminId: adminId,
            resturantId: resturant._id,
            superadminId: superAdminId,
        });

        const newhours = await openingHours.create(hours);
        await newhours.save();

        res.status(200).json({ message: "Hours display completed", newhours });
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal server error", error: error.message });
    }
};



module.exports = {
    openinghour,
    updateOpeningHours,
    openinghourbyadmin,
}