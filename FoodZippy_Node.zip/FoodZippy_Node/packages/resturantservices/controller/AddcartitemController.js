const Joi = require("joi");
const Menu = require("../../common/model/menuSchema");
const voucherCode = require("../../common/model/vochureSchema");
const cart = require("../../common/model/addcartitemSchema");
const Restaurant = require('../../common/model/restaurantSchema');
const ServicesCharge = require('../../common/model/serviceschargeSchema');
const Address = require("../../common/model/addressSchema");
const User = require("../../common/model/userSchema");
const deliveryzone = require("../../common/model/deliveryzoneSchema");
const addcartjoi = Joi.object({
  userId: Joi.string(),
  vouchercode_id: Joi.string().allow(null, ""),
  vouchercode: Joi.string().allow(null, ""),
  addcartitem: Joi.array().items(
    Joi.object({
      menu_item_id: Joi.string().required(),
      quantity: Joi.number().required().min(1),
      addons: Joi.array().items(Joi.string()),
      additemvariant_id: Joi.array().items(Joi.string()),
    })
  ),
  packingCharge: Joi.number(),
  vat_tax: Joi.number(),
  cookingInstruction: Joi.string().default("None"),
  is_active: Joi.boolean().default(true),
  restaurant_id: Joi.string(),
  tax_pack_totalamount: Joi.number(),
  deliveryfee: Joi.number(),
  address_id: Joi.string(),
  takeawaye: Joi.boolean(),
  delivery: Joi.boolean(),
});
const createAddToCartItem = async (req, res) => {
  const userId = req.user.id;
  let filteredCartItems;
  let totalPackingCharge = 0;

  try {
    // Validate request body using Joi
    const { error } = addcartjoi.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { vouchercode_id, vouchercode, addcartitem } = req.body;
    console.log("dfghjkl")
    const restaurantId = req.body.restaurant_id;
    //const { delivery, takeawaye } = req.body
    // Find user by ID
    const user = await User.findById({ _id: userId });
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Find default address for the user
    const defaultAddress = await Address.findOne({ user: userId, is_default: true });
    if (!defaultAddress) {
      return res.status(404).json({ error: "Default address not found for the user" });
    }
    console.log(restaurantId, "restaurant");
    let restaurantInfo = null;

    // Check if restaurantId is defined before fetching restaurant information
    if (restaurantId) {
      // Fetch restaurant information based on restaurantId
      restaurantInfo = await Restaurant.findOne({ _id: restaurantId });

      if (!restaurantInfo) {
        return res.status(404).json({ error: "Restaurant not found for the provided ID" });
      }
    }

    // Fetch packing charge and VAT tax from the services charge table based on the restaurant ID
    const servicesCharge = await ServicesCharge.findOne({ restaurant_id: restaurantId });
    console.log(servicesCharge, "servicescharge");
    const vatTax = servicesCharge.vat_tax || 0;
    let voucherDiscount = 0;

    // Process voucher if either vouchercode_id or vouchercode is provided and not empty
    if ((vouchercode_id && vouchercode_id !== "") || (vouchercode && vouchercode !== "")) {
      const voucher = await validateAndRetrieveVoucher(vouchercode_id, vouchercode);

      if (!voucher) {
        return res.status(400).json({ error: "Invalid voucher code" });
      }

      // Remove items with quantity zero from the cart
      filteredCartItems = addcartitem.filter(item => item.quantity > 0);

      const overallSubtotal = await calculateSubtotalIncludingAddonsAndVariants(filteredCartItems);

      // Check if the overall subtotal meets the minimum order value of the voucher
      if (overallSubtotal < voucher.minimumOrderValue) {
        return res.status(400).json({
          error: `Minimum order value of ${voucher.minimumOrderValue} not met.`,
        });
      }

      // Logic to calculate the voucher discount based on voucher type
      if (voucher.createDiscount === "Percentage") {
        voucherDiscount = (voucher.discountPercentage / 100) * overallSubtotal;
      } else if (voucher.createDiscount === "LumpAmount") {
        voucherDiscount = parseFloat(voucher.lumpAmount);
      }

      // Check if voucher can be used only once
      if (voucher.theVoucherCanBeUser === "onlyOnce") {
        // Here, you may want to add logic to mark the voucher as used in your database
      }
    } else {
      // If voucher is not applied or no valid voucher is found
      // Use the original cart items without filtering
      filteredCartItems = addcartitem;
      // You may add additional processing here if needed
    }

    // Calculate overall subtotal without applying voucher discount
    const overallSubtotalWithoutDiscount = await calculateSubtotalIncludingAddonsAndVariants(filteredCartItems);

    // Calculate total amount after applying voucher discount
    const totalAmount = overallSubtotalWithoutDiscount - voucherDiscount;
    // Calculate tax amount based on percentage
    const taxAmount = (vatTax / 100) * totalAmount;
    console.log(taxAmount, "pppp");
    // Calculate tax_pack_totalamount
    const Tax_pack_totalamount = totalAmount + taxAmount;
    console.log(Tax_pack_totalamount, "lokomo");
    // Calculate delivery fee based on user and restaurant locations
    const userlocation = defaultAddress.location;
    console.log(userlocation, "userlocation");
    const restaurantlocation = restaurantInfo.mapLocation;
    console.log(restaurantlocation, "restaurantlocation");
    // Fetch the delivery fee based on the user's location
    let deliveryFee = 0;
    let deliveryZoneId = null;  // Add this variable to store the ID of the applicable delivery zone

    if (restaurantInfo && Array.isArray(restaurantInfo.deliveryzone)) {
      const deliveryZone = restaurantInfo.deliveryzone.find((zone) => {
        return (
          zone.type === "circle" &&
          calculateDistance(userlocation, { latitude: zone.userLat, longitude: zone.userLong }) <= zone.radius
        );
      });
      console.log(deliveryZone, "deliveryzone")
      if (deliveryZone) {
        deliveryFee = deliveryZone.deliveryFee || 0;
        deliveryZoneId = deliveryZone._id;
      }
    }
    // Construct the response
    const response = {
      userId: userId,
      totalAmount,
      overallSubtotalWithoutDiscount,
      cookingInstruction: req.body.cookingInstruction,
      voucherDiscount,
      restaurantInfo,
      items: await Promise.all(
        filteredCartItems.map(async (item) => {
          const { menu_item_id, quantity, additemvariant_id, addons } = item;
          const menuItem = await Menu.findById(menu_item_id);
          if (!menuItem || !menuItem.is_active) {
            return null;
          }

          const additemvariant = menuItem.additemvariant.filter((variant) =>
            additemvariant_id.includes(String(variant._id))
          );
          const addonsDetails = menuItem.addons.filter((addon) =>
            addons.includes(String(addon._id))
          );

          const subtotal = calculateItemSubtotal(
            menuItem.itemPrice,
            quantity,
            additemvariant,
            addonsDetails
          );

          let packingChargePerItem = 0;
          // Check if the menu item has a packing charge
          if (menuItem.packingCharge && menuItem.packingCharge > 0) {
            packingChargePerItem = menuItem.packingCharge;
            totalPackingCharge += menuItem.packingCharge * quantity;
          }

          return {
            menu_item_id,
            menu_item_name: menuItem.itemName,
            menu_item_price: menuItem.itemPrice,
            quantity,
            additemvariant,
            addons: addonsDetails,
            subtotal,
            packingCharge: packingChargePerItem,
          };
        })
      ),
      packingCharge: totalPackingCharge,
      vat_tax: vatTax,
      tax_pack_totalamount: Tax_pack_totalamount,
      restaurant_id: servicesCharge.restaurant_id,
      vouchercode,
      vouchercode_id,
      deliveryfee: deliveryFee,
      address_id: defaultAddress,
      takeawaye: req.body.takeawaye,
      delivery: req.body.delivery,
    };

    // Save the cart response
    const newCartResponse = new cart(response);
    const savedResponse = await newCartResponse.save();

    // Send the response to the client
    res.status(200).json({ message: "cart item ctreate successfully", savedResponse, user, defaultAddress });
  } catch (error) {
    console.error("Error processing cart items:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
const calculateDistance = (location1, location2) => {
  const toRadians = (angle) => (angle * Math.PI) / 180;

  const { latitude: lat1, longitude: lon1 } = location1;
  const { latitude: lat2, longitude: lon2 } = location2;

  const R = 6371; // Radius of the Earth in kilometers

  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in kilometers

  return distance;
};


// Function to validate voucher code and retrieve voucher information
const validateAndRetrieveVoucher = async (vouchercode_id, vouchercode) => {
  let voucher;
  if (vouchercode_id) {
    voucher = await voucherCode.findById(vouchercode_id);
  } else {
    voucher = await voucherCode.findOne({ voucherCodes: vouchercode });
  }

  if (!voucher || !voucher.is_Active) {
    return null;
  }

  return voucher;
};

// Function to get menu and restaurant information based on menu_item_id
// const getMenuAndRestaurantInfo = async (menu_item_id) => {
//   const menuItem = await Menu.findById(menu_item_id);
//   if (!menuItem || !menuItem.is_active) {
//     return null;
//   }

//   // Assuming restaurant information is available in the menuItem object, modify this based on your actual schema
//   const restaurantInfo = {
//     restaurantName: menuItem.restaurantName,
//     // Include other restaurant information as needed
//   };

//   return { menuItem, restaurantInfo };
// };

const getMenuAndRestaurantInfo = async (menu_item_id) => {
  try {
    const menuItem = await Menu.findById(menu_item_id);
    if (!menuItem || !menuItem.is_active) {
      return null;
    }

    // Retrieve restaurant information from the 'restaurant' table
    const restaurantInfo = await Restaurant.findById(menuItem.restaurant_id);
    if (!restaurantInfo || !restaurantInfo.is_active) {
      return null;
    }

    // Modify this based on your actual schema and the structure of the 'restaurant' table
    const formattedRestaurantInfo = {
      restaurantName: restaurantInfo.restaurantName,
      // Include other restaurant information as needed
    };

    return { menuItem, restaurantInfo: formattedRestaurantInfo };
  } catch (error) {
    console.error('Error fetching menu and restaurant information:', error);
    return null;
  }
};


const calculateSubtotalIncludingAddonsAndVariants = async (items) => {
  try {
    // Check if 'items' is an array and has a length greater than 0
    if (!Array.isArray(items) || items.length === 0) {
      return 0; // Return a default value or handle the empty case as needed
    }

    const promises = items.map(async (item) => {
      const { menu_item_id, quantity, additemvariant_id, addons } = item;
      const menuItem = await Menu.findById(menu_item_id);
      if (menuItem && menuItem.is_active) {
        const additemvariant = menuItem.additemvariant.filter((variant) =>
          additemvariant_id.includes(String(variant._id))
        );
        const addonsDetails = menuItem.addons.filter((addon) =>
          addons.includes(String(addon._id))
        );
        return calculateItemSubtotal(
          menuItem.itemPrice,
          quantity,
          additemvariant,
          addonsDetails
        );
      }
      return 0;
    });

    const results = await Promise.all(promises);
    return results.reduce((acc, curr) => acc + curr, 0);
  } catch (error) {
    console.error(
      "Error calculating subtotal including addons and variants:",
      error
    );
    throw error;
  }
};


// const calculateSubtotalIncludingAddonsAndVariants = async (items) => {
//   try {
//     const promises = items.map(async (item) => {
//       const { menu_item_id, quantity, additemvariant_id, addons } = item;
//       const menuItem = await Menu.findById(menu_item_id);
//       if (menuItem && menuItem.is_active) {
//         const additemvariant = menuItem.additemvariant.filter((variant) =>
//           additemvariant_id.includes(String(variant._id))
//         );
//         const addonsDetails = menuItem.addons.filter((addon) =>
//           addons.includes(String(addon._id))
//         );
//         return calculateItemSubtotal(
//           menuItem.itemPrice,
//           quantity,
//           additemvariant,
//           addonsDetails
//         );
//       }
//       return 0;
//     });

//     const results = await Promise.all(promises);
//     return results.reduce((acc, curr) => acc + curr, 0);
//   } catch (error) {
//     console.error(
//       "Error calculating subtotal including addons and variants:",
//       error
//     );
//     throw error;
//   }
// };

// Helper function to calculate item subtotal
const calculateItemSubtotal = (basePrice, quantity, variants, addons) => {
  const variantPrice = variants.reduce(
    (acc, variant) => acc + variant.price,
    0
  );
  const addonPrice = addons.reduce((acc, addon) => acc + addon.addonPrice, 0);
  return (basePrice + variantPrice + addonPrice) * quantity;
};

const getallcartbyuserId = async (req, res) => {
  const userId = req.user.id;
  try {
    // **Fetch active user carts with populated fields:**
    const carts = await cart.find({ userId: userId, is_active: true })
      .populate('address_id') // Populate address
      .populate('restaurant_id'); // Populate restaurant
    const activecart = carts.map((cart) => ({
      cartId: cart._id, // Add cart ID
      cartItems: cart.cartItems,
      address: cart.address_id, // Extract address details
      restaurant: cart.restaurant_id, // Extract restaurant details
      user: req.user, // Include user information from the controller
    }));
    res.status(200).json({ message: "get cart successfully", activecart, carts })
  } catch (error) {
    console.error("Error fetching active user carts:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
const calculateTotalAmount = (items) => {
  return items.reduce((total, item) => total + item.subtotal, 0);
};
const updateCart = async (req, res) => {
  const cartId = req.params.cart_id; // Accessing cart_id from params
  const userId = req.user.id; // Assuming you're using passport for authentication

  try {
    // Validate request body using Joi or other validation library
    // (You may want to replace the following validation with your actual validation)
    // const { error } = validateCartUpdate(req.body);
    // if (error) {
    //   return res.status(400).json({ error: error.details[0].message });
    // }

    const { vouchercode_id, vouchercode, addcartitem } = req.body;
    const restaurantId = req.body.restaurant_id;
    // Find user by ID
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Find default address for the user
    const defaultAddress = await Address.findOne({ user: userId, is_default: true });
    if (!defaultAddress) {
      return res.status(404).json({ error: "Default address not found for the user" });
    }

    // Extract unique restaurant IDs from menu items in the cart
    // const uniqueRestaurantIds = [...new Set(addcartitem.map(item => item.restaurant_id))];
    // if (uniqueRestaurantIds.length !== 1) {
    //   return res.status(400).json({ error: "Cart items should belong to the same restaurant." });
    // }

    //const restaurantId = uniqueRestaurantIds[0];
    let restaurantInfo = null;

    //Check if restaurantId is defined before fetching restaurant information
    if (restaurantId) {
      // Fetch restaurant information based on restaurantId
      restaurantInfo = await Restaurant.findById({ _id: restaurantId });
      if (!restaurantInfo) {
        return res.status(404).json({ error: "Restaurant not found for the provided ID" });
      }
    }

    // Fetch packing charge and VAT tax from the services charge table based on the restaurant ID
    const servicesCharge = await ServicesCharge.findOne({ restaurant_id: restaurantId });
    console.log(servicesCharge, "servicescharge");
    const vatTax = servicesCharge.vat_tax || 0;

    let voucherDiscount = 0;
    let totalPackingCharge = 0;
    let filteredCartItems;

    // Process voucher if either vouchercode_id or vouchercode is provided and not empty
    if ((vouchercode_id && vouchercode_id !== "") || (vouchercode && vouchercode !== "")) {
      const voucher = await validateAndRetrieveVoucher(vouchercode_id, vouchercode);

      if (!voucher) {
        return res.status(400).json({ error: "Invalid voucher code" });
      }

      // Remove items with quantity zero from the cart
      filteredCartItems = addcartitem.filter(item => item.quantity >= 0);

      const overallSubtotal = await calculateSubtotalIncludingAddonsAndVariant(filteredCartItems);

      // Check if the overall subtotal meets the minimum order value of the voucher
      if (overallSubtotal < voucher.minimumOrderValue) {
        return res.status(400).json({
          error: `Minimum order value of ${voucher.minimumOrderValue} not met.`,
        });
      }

      // Logic to calculate the voucher discount based on voucher type
      if (voucher.createDiscount === "Percentage") {
        voucherDiscount = (voucher.discountPercentage / 100) * overallSubtotal;
      } else if (voucher.createDiscount === "LumpAmount") {
        voucherDiscount = parseFloat(voucher.lumpAmount);
      }

      // Check if voucher can be used only once
      if (voucher.theVoucherCanBeUser === "onlyOnce") {
        // Here, you may want to add logic to mark the voucher as used in your database
      }
    } else {
      // If voucher is not applied or no valid voucher is found
      // Use the original cart items without filtering
      filteredCartItems = addcartitem.slice().map(item => (item.quantity > 0 ? item : null));
      filteredCartItems = filteredCartItems.filter(item => item !== null);
      // filteredCartItems = addcartitem;
      // You may add additional processing here if needed
    }

    // Iterate through each item in the request payload
    for (const updatedItem of filteredCartItems) {
      const { _id: itemId, quantity, additemvariant_id, addons } = updatedItem;

      // Check if additemvariant_id is present in the item
      if (additemvariant_id) {
        // Update each item in the cart based on its _id
        const updateOperation = quantity > 0
          ? {
            $set: {
              "items.$.quantity": quantity,
              "items.$.additemvariant_id": additemvariant_id,
              //"items.$.addons": addons,
              // You may need to update other fields as needed
            },
          }
          : {
            $pull: {
              items: { _id: itemId },
            },
          };

        await cart.updateOne(
          { _id: cartId, "items._id": itemId },
          updateOperation
        );
      } else {
        // Handle the case where additemvariant_id is not present in the item
        console.error("additemvariant is missing in the item:", updatedItem);
        // You may want to handle this case based on your application's requirements
      }
    }

    // Calculate overall subtotal without applying voucher discount
    const overallSubtotalWithoutDiscount = await calculateSubtotalIncludingAddonsAndVariant(filteredCartItems);

    // Calculate total amount after applying voucher discount
    const totalAmount = overallSubtotalWithoutDiscount - voucherDiscount;

    // Calculate tax amount based on percentage
    const taxAmount = (vatTax / 100) * totalAmount;

    // Calculate tax_pack_totalamount
    const Tax_pack_totalamount = totalAmount + taxAmount;
    // Fetch the delivery fee based on the user's location
    let deliveryFee = 0;
    let deliveryZoneId = null;  // Add this variable to store the ID of the applicable delivery zone

    if (restaurantInfo && Array.isArray(restaurantInfo.deliveryzone)) {
      const deliveryZone = restaurantInfo.deliveryzone.find((zone) => {
        return (
          zone.type === "circle" &&
          calculateDistance(userlocation, { latitude: zone.userLat, longitude: zone.userLong }) <= zone.radius
        );
      });

      if (deliveryZone) {
        deliveryFee = deliveryZone.deliveryFee || 0;
        deliveryZoneId = deliveryZone._id;
      }
    }

    // Construct the response
    const response = {
      userId: userId,
      totalAmount,
      overallSubtotalWithoutDiscount,
      cookingInstruction: req.body.cookingInstruction,
      voucherDiscount,
      restaurantInfo,
      items: await Promise.all(
        filteredCartItems.map(async (item) => {
          const { menu_item_id, quantity, additemvariant_id, addons } = item;
          const menuItem = await Menu.findById(menu_item_id);

          if (!menuItem || !menuItem.is_active) {
            return null;
          }

          const additemvariant = additemvariant_id && menuItem.additemvariant
            ? menuItem.additemvariant.filter((variant) =>
              additemvariant_id.includes(String(variant._id))
            )
            : [];

          const addonsDetails = addons && menuItem.addons
            ? menuItem.addons.filter((addon) => addons.includes(String(addon._id)))
            : [];

          const subtotal = calculateItemSubtotal(
            menuItem.itemPrice,
            quantity,
            additemvariant,
            addonsDetails
          );

          let packingChargePerItem = 0;

          // Check if the menu item has a packing charge
          if (menuItem.packingCharge && menuItem.packingCharge > 0) {
            packingChargePerItem = menuItem.packingCharge;
            totalPackingCharge += menuItem.packingCharge * quantity;
          }

          return {
            menu_item_id,
            menu_item_name: menuItem.itemName,
            menu_item_price: menuItem.itemPrice,
            quantity,
            additemvariant,
            addons: addonsDetails,
            subtotal,
            packingCharge: packingChargePerItem,
          };
        })
      ),
      packingCharge: totalPackingCharge,
      vat_tax: vatTax,
      tax_pack_totalamount: Tax_pack_totalamount,
      restaurant_id: servicesCharge.restaurant_id,
      deliveryfee: deliveryFee,
      takeawaye: req.body.takeawaye,
      delivery: req.body.delivery,
    };

    // Update the existing cart using findByIdAndUpdate
    const updatedCart = await cart.findByIdAndUpdate(cartId, response, { new: true });

    // Send the response to the client
    res.status(200).json({ message: "Cart item updated successfully", updatedCart, user, defaultAddress });
  } catch (error) {
    console.error("Error updating cart item:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
const calculateSubtotalIncludingAddonsAndVariant = async (items) => {
  try {
    const subtotalPromises = items.map(async (item) => {
      const { menu_item_id, quantity, additemvariant_id, addons } = item;

      // Fetch the menu item based on menu_item_id
      const menuItem = await Menu.findById(menu_item_id);

      if (!menuItem || !menuItem.is_active) {
        return 0;  // Return 0 if the menu item is not found or not active
      }

      // Fetch additemvariant based on additemvariant_id
      const additemvariant = additemvariant_id && menuItem.additemvariant
        ? menuItem.additemvariant.filter((variant) =>
          variant && variant._id && additemvariant_id.includes(String(variant._id))
        )
        : [];

      // Fetch addonsDetails based on addons
      const addonsDetails = addons && menuItem.addons
        ? menuItem.addons.filter((addon) => addon && addon._id && addons.includes(String(addon._id)))
        : [];

      // Calculate subtotal for the item
      const itemSubtotal = calculateItemSubtotal(
        menuItem.itemPrice,
        quantity,
        additemvariant,
        addonsDetails
      );

      return itemSubtotal;
    });

    const subtotalArray = await Promise.all(subtotalPromises);

    // Sum up the subtotals to get the overall subtotal
    const overallSubtotal = subtotalArray.reduce((acc, subtotal) => acc + subtotal, 0);

    return overallSubtotal;
  } catch (error) {
    console.error("Error calculating subtotal including addons and variants:", error);
    throw error;
  }
};
module.exports = {
  createAddToCartItem,
  getallcartbyuserId,
  updateCart,
};
