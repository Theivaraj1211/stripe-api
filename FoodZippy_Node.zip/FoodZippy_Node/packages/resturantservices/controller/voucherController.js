const Joi = require("joi");
const VoucherCode = require("../../common/model/vochureSchema");
const Restaurant = require("../../common/model/restaurantSchema");
// Joi schema for validation
const voucherCodeSchema = Joi.object({
  createDiscount: Joi.string().valid("Percentage", "lump"),
  voucherCodes: Joi.string().regex(/^[A-Z0-9]{6}$/),
  expirationDate: Joi.date().default(
    () => new Date(new Date().setFullYear(new Date().getFullYear() + 1))
  ),
  is_Active: Joi.boolean().default(true),
  restaurantName: Joi.string(),
  admin_id: Joi.string(), // Validation for admin_id from token
  restaurantId: Joi.string(),
  minimumOrderValue: Joi.number(),
  minimumOrderValue_active: Joi.boolean().default(true),
  theVoucherCanBeUser: Joi.string().valid("onlyOnce"),
  discountPercentage: Joi.number(),
  created_by: Joi.string(),
  updated_by: Joi.string(),
  lumpAmount: Joi.number(),
  validDateFrom: Joi.date().default(Date.now),
  validDateTo: Joi.date().default(Date.now),
  validTimeFrom: Joi.date().default(Date.now),
  validTimeTo: Joi.date().default(Date.now),
});

// Controller for creating a voucher code
const createVoucherCode = async (req, res) => {
  try {
    // Get admin_id from req.user and restaurantId from req.body
    const adminId = req.user.id;
    const { restaurantId } = req.body;

    // Validate request body against the schema
    const { error, value } = voucherCodeSchema.validate(
      { ...req.body },
      { abortEarly: false }
    );

    if (error) {
      return res
        .status(400)
        .json({ error: error.details.map((err) => err.message) });
    }

    // Check if voucherCodes already exist in the database
    const existingVoucher = await VoucherCode.findOne({
      voucherCodes: voucherData.voucherCodes,
    });

    if (existingVoucher) {
      return res.status(400).json({ error: "Voucher code already exists" });
    }
    // Set default values for created_by and updated_by
    const { created_by, updated_by, ...validatedData } = value;
    const defaultCreatedBy = adminId; // Use admin_id from token
    const defaultUpdatedBy = adminId; // Use admin_id from token
    const voucherData = {
      ...validatedData,
      created_by: created_by || defaultCreatedBy,
      updated_by: updated_by || defaultUpdatedBy,
      admin_id: adminId, // Include admin_id in voucher data
      restaurantId,
    };
    // Create voucher code with validated data
    const voucher = await VoucherCode.create(voucherData);
    res
      .status(201)
      .json({ message: "Voucher code created successfully", voucher });
  } catch (err) {
    console.error("Error creating voucher code:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};
// Controller to get all vouchers
const getAllVouchers = async (req, res) => {
  try {
    // Fetch all vouchers from the database
    const vouchers = await VoucherCode.find();

    res.status(200).json({ vouchers });
  } catch (err) {
    console.error("Error fetching vouchers:", err);
    res.status(500).json({ error: "Internal server error" });
  }
};
const getallvoucherrestaurantId = async (req, res) => {
  try {
    const restaurant_id = req.params.id; // Assuming restaurantId is a parameter in the URL

    // Find the restaurant by its ID to ensure it exists
    const restaurant = await Restaurant.find({ restaurantId: restaurant_id });

    if (!restaurant) {
      return res.status(404).json({ error: "Restaurant not found" });
    }

    // Fetch all voucher codes associated with the restaurantId
    const voucherCodes = await VoucherCode.find({ restaurantId: restaurant_id });

    res.status(200).json({ voucherCodes: voucherCodes });
  } catch (error) {
    console.error("Error fetching voucher codes by restaurant ID:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
module.exports = {
  createVoucherCode,
  getAllVouchers,
  getallvoucherrestaurantId,
};
