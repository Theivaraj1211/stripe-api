# `resturantservices`

> TODO: description

## Usage

```
const resturantservices = require('resturantservices');

// TODO: DEMONSTRATE API
```
