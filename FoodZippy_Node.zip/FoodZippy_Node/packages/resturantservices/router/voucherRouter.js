const express = require("express");
const router = express.Router();
const {
  createVoucherCode,
  getAllVouchers,
  getallvoucherrestaurantId,
} = require("../controller/voucherController");
const {
  requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
// Define routes
router.post("/", requireAdminAuth, createVoucherCode);
router.get("/", getAllVouchers);
router.get("/:id", getallvoucherrestaurantId);
module.exports = router;
