const express = require("express");
const router = express.Router();
const {
    createManager, updatepassword, getallactivemanager
} = require("../controller/managerController");

const {
    requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");

router.post("/", requireAdminAuth, createManager);
router.put("/password/:id", updatepassword);
router.get("/:restaurant_id", getallactivemanager);

module.exports = router;