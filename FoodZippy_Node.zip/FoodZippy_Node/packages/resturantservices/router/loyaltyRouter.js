const express = require("express");
const router = express.Router();
const {
  createloyalty,
  createRetention,
  getallloyaltyrestaurantId,
  getallretention,
} = require("../controller/loyaltyController");
const {
  requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
// Define routes
router.post("/loyalty", requireAdminAuth, createloyalty);
router.post("/retention", requireAdminAuth, createRetention);
router.get("/loyalty/:restaurant_id/admin", getallloyaltyrestaurantId);
router.get("/retention/:restaurant_id", getallretention);
module.exports = router;
