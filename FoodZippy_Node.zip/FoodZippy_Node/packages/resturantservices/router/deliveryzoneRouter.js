const express = require("express");
const router = express.Router();
const {
    requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
const { requiresuperAdminAuth } = require('../../userservices/middleware/vaildateSuperAdminToken');
const { setdeliveryzone, getalldeliveryzone, setdeliveryzonebyadmin } = require("../controller/deliveryzoneController");
router.post("/", requireAdminAuth, setdeliveryzone);
router.get("/:restaurant_id", getalldeliveryzone)
router.post('/admin', requiresuperAdminAuth, setdeliveryzonebyadmin)
module.exports = router;