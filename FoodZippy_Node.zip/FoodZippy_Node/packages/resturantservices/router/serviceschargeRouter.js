const express = require('express');
const router = express.Router();
const { createOrUpdateServiceCharge, getServiceChargeByAdminId, setServiceCharge } = require('../controller/serviceschargeController');
const { requireAdminAuth } = require('../../userservices/middleware/vaildateAdminToken');
const { requiresuperAdminAuth } = require('../../userservices/middleware/vaildateSuperAdminToken');

// Route to create or update service charge settings
router.post('/', requireAdminAuth, createOrUpdateServiceCharge);
router.get("/:restaurant_id", requireAdminAuth, getServiceChargeByAdminId);
router.post('/admin', requiresuperAdminAuth, setServiceCharge);
module.exports = router;
