const express = require("express");
const router = express.Router();
const {
  createRestaurant,
  getAllRestaurantsByAdminId,
  basicinfo,
  updateRestaurant,
  getRestaurantById,
  updateRestaurantBySuperadmin,
} = require("../controller/restaurantController");
//const { requireUserAuth } = require('../../userservices/middleware/vaildateAdminToken')
const { openinghour, updateOpeningHours, openinghourbyadmin } = require("../controller/hourssettingController");
const {
  requireAdminAuth,
} = require("../../userservices/middleware/vaildateAdminToken");
// const multer = require('multer');
const { requiresuperAdminAuth } = require('../../userservices/middleware/vaildateSuperAdminToken')
// const storage = multer.memoryStorage(); // Use memory storage for uploading files
const upload = require("../../userservices/middleware/multerConfig");
const {
  getallvoucherrestaurantId,
} = require("../controller/voucherController");
// Define routes
//router.route('/').put(requireUserAuth,updateUserWithImage)
router.post(
  "/",
  requireAdminAuth,
  upload.single("logoImage"),
  createRestaurant
);
router.get("/", requireAdminAuth, getAllRestaurantsByAdminId);
router.get("/basic/information", requireAdminAuth, basicinfo);
router.put("/:restaurant_id", requireAdminAuth, updateRestaurant);
router.get("/user/information/:restaurantId", getRestaurantById);
router.get("/:restaurant_id", getallvoucherrestaurantId);
router.put('/admin/:restaurant_id', requiresuperAdminAuth, updateRestaurantBySuperadmin)
//routes
router.post('/admin/openinghours', requiresuperAdminAuth, openinghourbyadmin);
router.post("/openinghours", requireAdminAuth, openinghour);
router.put("/updateopeninghours/:id", requireAdminAuth, updateOpeningHours);
module.exports = router;
